/*

	Retrieves info from xml file, then shows audio in a lightbox.

	Relies on CSS.

	Author: Michael Koderisch 2010-12-01

*/

function SoundLightbox(args) {
	this.panel = null; // store the panel
	this.width_add_px = 48; // add this to avoid scrollbars in IE6
	this.title_text = 'History - ' + args['ph_unit_title'];
	this.xml_path = args['topic_path'] + 'includes/resources/sounds/';

	this.ns_links = glow.dom.get(args['sound-links']); // get links
	this.n_items = this.ns_links.length;
	this.init(this.ns_links);
}
//-----

SoundLightbox.prototype.init = function() {

// MAINTAINED VARIABLES:
	var that = this;

	this.ns_links.each(function(i) {
		var ns_link = glow.dom.get(this);
		glow.events.addListener(ns_link, 'click', function() { show_sound_clip(i); return false; });
	});
	
// INNER FUNCTIONS:

	function show_sound_clip(i) {
		if (i < 0 || i >= that.n_items)
			return;
		
		that.ph_index = i; // record the current sound in the lightbox
		var ns_link = glow.dom.get(that.ns_links[i]);
		var xml_file_name = ns_link.parent().attr('id').substr(5);				// get the xml file name from list item
		var clip_title = ns_link.text();	// get the clip title from the link text
		get_and_show_sound(xml_file_name,clip_title);
	}
	//-----

	function get_and_show_sound(xml_file_name,clip_title) {

		var xml_file_url = that.xml_path + xml_file_name + '.xml';

		glow.net.get(xml_file_url, {
			useCache: true,
			onLoad: function(response) {
				var title = that.title_text;
				var subtitle = clip_title;
				
				var res_xml = response.xml();
				var res_nl = glow.dom.get(res_xml);
				var playlist = res_nl.get('playlist').text();
				var clip_type = res_nl.get('type').text();
				var desc = res_nl.get('description').text();
				
				show_sound(title, subtitle, desc, playlist, clip_type);
			},
			onError: function(response) {
				alert("Error getting data from: " + xml_file_url + "\n\n" + response.statusText());
			}
		});
	}
	//-----

	function show_sound(title, subtitle, desc, playlist, clip_type) {
		var ns_panel = null // content for panel
			, ns_close = null // text added to close button
			, emp = null  // BBC Emp
			;

		if (!that.panel) {
			ns_panel = glow.dom.create(
				  '<div id="sound-panel">'
					+ '<h2 class="hd">' + title + '</h2>'
					+ '<div id="embed-sound"></div>'
					+ '<h3>' + subtitle + '</h3>'
					+ '<p>' + desc + '</p>'
					+ '<p class="ft">'
						+ '<a class="prev" href="#">Previous</a>'
						+ '<a class="next" href="#">Next</a>'
					+ '</p>'
				  + '</div>'
				);

			that.panel = new glow.widgets.Panel(ns_panel, {
				"closeOnMaskClick": false
				, width: (512 + 50) + "px"
			});

			that.panel.container.addClass("ph-panel-container");
			that.panel.content.addClass("ph-panel-content");
			that.panel.body.addClass("ph-panel-body");
			that.panel.header.addClass("ph-panel-header");

			ns_close = glow.dom.create('<span class="close-text">Close</span>');
			that.panel.content.get("a.panel-close").addClass("close-btn");
			that.panel.content.get("a.panel-close").after(ns_close);

			// add navigation from within lightbox
			glow.events.addListener(that.panel.footer.get('a.prev'), 'click', function() { 
				show_sound_clip(that.ph_index - 1); return false;
			});

			glow.events.addListener(that.panel.footer.get('a.next'), 'click', function() { 
				show_sound_clip(that.ph_index + 1); return false;
			});

			glow.dom.get("#embed-sound").css("display", "block");   
		}

		that.panel.header.get('h2').text(title);
		that.panel.body.get('h3').text(subtitle);
		that.panel.body.get('p').text(desc);

		that.panel.show();
		set_buttons();
		
		// link to non-flash version for users without Flash
		that.panel.body.get("#embed-sound").html('<p>You are trying to listen to Flash content, but you have no Flash plugin installed. To find out how to install a Flash plugin, go to the <a href="http://www.bbc.co.uk/webwise/guides/about-flash">WebWise Flash install guide</a>.</p>');

		emp = new bbc.Emp();
		emp.setDomId("embed-sound");    
		emp.setWidth("512");   
		
		if (clip_type == 'video') {
			emp.setHeight("323");
		} else {
			emp.setHeight("100");
		}
		emp.setPlaylist(playlist);
		emp.set("config_settings_skin", "black");   
		emp.write();  
		that.panel.setPosition();
	}

	// enable/disable buttons
	function set_buttons() {

		var ns_footer = that.panel.footer;
		
		ns_footer.get('a.next').removeClass('no-next');
		ns_footer.get('a.prev').removeClass('no-prev');

		if (that.ph_index == 0) {
			ns_footer.get('a.prev').addClass('no-prev');
		}
		else if (that.ph_index == that.n_items - 1) {
			ns_footer.get('a.next').addClass('no-next');
		}
	}
	//-----

	
	
	
}
//-----


// end of script