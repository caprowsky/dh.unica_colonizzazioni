// declare the glossary array

// declare the glossary array
var aGloss = new Array();
aGloss['consectetuer'] = 'Sought - the passive subjunctive.';
aGloss['dapibus'] = 'The dative, ablative or locative plural. This is also to test whether these tooltips will work if you have two identical definition terms.';
aGloss['bibendum'] = 'About to be drunk - a gerundive.';
aGloss['archaeologists'] = 'An archaeologists investigates the past using all kinds of evidence, often gleaned from digging up ancient sites.';
aGloss['legend'] = 'An ancient tale, often passed down the generations through word of mouth. Legends often contain a grain or more of truth, though they may be complete fantasy.';