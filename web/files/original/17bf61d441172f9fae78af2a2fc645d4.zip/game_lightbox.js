/*

	Shows game in Glow lightbox.

	requires ph_game_from_id which is hash
		game_name => { src, title, height-px, width-px, min-flash-ver }

	Author: <a href="mailto:Michael.Taylor1@bbc.co.uk">Mike Taylor</a> 2008-11-13
*/
glow.ready(function() {

	var ns_link = glow.dom.get("a.game-link");
	
	this.ns_links = glow.dom.get("a.game-link");
	this.n_items = this.ns_links.length; // total items in lightbox list
	this.a_spec = new Array(this.n_items); // store spec for each lightbox
	this.a_ns_body = new Array(this.n_items); // store each panel body
	
	var game_div = glow.dom.get("#game-panel");
	
	// if there isn't a container div on the page already, we create one...
	if (game_div[0] == undefined) {
		game_wrapper = glow.dom.create(
			  '<div id="game-panel"></div>');
		glow.dom.get("body").append(game_wrapper);
	}

	ns_link.attr("href", "#");

	// attach lightbox link to each flash link
	//glow.events.addListener(ns_link, "click", function(ge) { 
	//	show_game(ph_game_from_id[ns_link.attr("id")]); 
		//return false 
	//});
	
	/*
	* copied code from image lightbox js	
	*/
	
	var that = this;
	
	// add listeners first, but don't create bodies until needed.
	this.ns_links.each(function(i) {

		var ns_link = that.ns_links.slice(i,i+1);
		
		// show_game(ph_game_from_id[ns_link.attr("id")]); 

		glow.events.addListener(ns_link, "click", function() { show_game(ph_game_from_id[ns_link.attr("id")]); return false; });

		if (that.dbg) alert('listener added to link: ' + ns_link.attr('href'));
		if (that.dbg) alert('title for that link is: ' + ns_link.attr('title'));

	});
	
	/*
	* end of copied code from image lightbox js	
	*/

	// testing
//	show_game(game_from_id[ns_link.attr("id")]); 

	function show_game(game)
	{
		var ns_content = [] // content for lightbox
			, panel = [] // Glow lightbox panel object
			, ns_close = [] // text to add before 'Close' button
			, flash_game = null // Glow Flash embed object
			;

		ns_content = glow.dom.create(
			  '<h2 class="hd">' + game['title'] + '</h2>'
			+ '<div id="embed-game"></div>');

		glow.dom.get("#game-panel").append(ns_content);

		glow.dom.get("#embed-game")
			.css('height', (game['height-px'] + 1) + "px")
			;

		panel = new glow.widgets.Panel("#game-panel", {
			"closeOnMaskClick": false
			, width: (50 + game['width-px'] + "px")
		});

		panel.container.addClass("ph-panel-container");
		panel.content.addClass("game-panel-content");
		panel.body.addClass("game-panel-body");
		panel.header.addClass("game-panel-header");

		ns_close = glow.dom.create('<span class="close-text"><a href="#">Close</a></span>');
		panel.content.get("a.panel-close").addClass("close-btn");
		panel.content.get("a.panel-close").after(ns_close);
		
		glow.events.addListener(ns_close, "click", function() { panel.hide(); return false; });

		panel.show();

		flash_game = new glow.embed.Flash(game['src'], "#embed-game", game['min-flash-ver'], {
			'attributes': {},
			'height': game['height-px'],
			'width': game['width-px'],
			'id': 'game-object',
			'message': 'You are trying to view Flash content, but you have no Flash plugin installed.To find out how to install a Flash plugin, go to the <a href=http://www.bbc.co.uk/webwise/askbruce/articles/download/howdoidownloadflashplayer_1.shtml>WebWise Flash install guide.</a> ',
			'params': {
				'base': game['src'].replace(/[^\/]*$/, ""),
				'flashVars': game['theflashvars']
			} 
		});

		flash_game.embed();
	}
	//-----

});

// end of script