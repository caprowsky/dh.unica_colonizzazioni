/* 

Rotate visibility of a list of content items using "Prev", "Next" buttons or similar.

Requires Glow 1.x.x with modules glow.dom, glow.events, and CSS to hide elements, e.g.:

	.glow-supported body .boxModuleInner ul#itemsFunFacts li.hidden { display:none }
	.glow-supported body .boxModuleInner ul#itemsFunFacts li p { display:block }

Class "glow-supported" must be added to document.documentElement if Glow is supported, e.g. using

	<!--#include virtual="/schools/primaryhistory/includes/console-glow.sssi" -->

Adds to global namespace:

	ContentRotator

Include as:
	<script type="text/javascript" src="/schools/primaryhistory/scripts/content_rotator.js"></script>

Call using glow.ready as:
	new ContentRotator(arguments)
	
where
	argument.nav-items = selector of items containing anchors (only one anchor per list item)
	argument.items = selector of individual target items themselves

example:
	<script type="text/javascript"> //<![CDATA[
		glow.ready(function() {
			new ContentRotator({ 
				"nav-prev": "#navFunFacts .navPrev", 
				"nav-next": "#navFunFacts .navNext", 
				"items": "#itemsFunFacts > li" 
			});
		});
	//]]>
	</script>

*/

function ContentRotator(args) {

	this.dbg = false;

	this.ns_nav_prev = glow.dom.get(args["nav-prev"]);
	this.ns_nav_next = glow.dom.get(args["nav-next"]);
	this.ns_items = glow.dom.get(args["items"]);

	if (this.ns_items.length < 2)
		return;

	if (this.dbg)
	{
		alert("Found " + this.ns_nav_prev.length + " link items (" + args["nav-prev"] + ")"
			+ "\nFound " + this.ns_nav_next.length + " link items (" + args["nav-next"] + ")"
			+ "\nFound " + this.ns_items.length + " items (" + args["items"] + ")");
	}

	this.init();

// MAINTAINED VARIABLES

}
//-----

ContentRotator.prototype.init = function() {

	var that = this // for use in inner functions
		, n_items = this.ns_items.length // number of target items
		, next_href = "#" + this.ns_items.slice(1,2).attr("id") // initial href for "next" button
		, prev_href= "#" + this.ns_items.slice(n_items-1,n_items).attr("id") // initial href for "prev" button
		, ns_a_prev = this.ns_nav_prev.get("a") // "next" anchor
		, ns_a_next = this.ns_nav_next.get("a") // "prev" anchor		
		;

	glow.events.addListener(ns_a_prev, "click", function() { return on_link_click(this, -1) }, this.ns_nav_prev);
	glow.events.addListener(ns_a_next, "click", function() { return on_link_click(this, +1) }, this.ns_nav_next);

	// assume the first item is the default one to show.
	this.ns_items.each(function(i) {
		if (i > 0)
			glow.dom.get(this).addClass("hidden");
	});

	// and set the button targets appropriately:

	ns_a_next.attr("href", next_href);
	ns_a_prev.attr("href", prev_href);

	return this;

// FUNCTIONS

	// given a nav link container, show the item pointed to and hide the rest.
	// return true on success
	function open_item(ns_nav_item, n_inc) { // n_inc = (-1 | 0 | +1)

		var re_target_id = /(#[^#]+)$/ // get target id
			, a_matches = null // will hold matched target id
			, ns_target_item = [] // target item to be shown
			, ns_next_target = [] // new target for "next" link
			, ns_prev_target = [] // new target for "prev" link
			, n_items = that.ns_items.length // number of target items
			;

		a_matches = re_target_id.exec(ns_nav_item.get("a").attr("href"));
		if (!a_matches) 
			return false;

		ns_target_item = glow.dom.get(a_matches[1]);
		ns_target_item.removeClass("hidden");

		that.ns_items.each(function(i) {

			if (this != ns_target_item[0])
			{
				if (that.dbg) alert("Hiding item "+this.className + " : " + this.id);
				glow.dom.get(this).addClass("hidden");
			}
		});

		// advance or retreat button anchor targets
		if (n_inc == 1)
		{
			var ns_next_target = ns_target_item.next();
			if (ns_next_target.length < 1) // no more ...
				ns_next_target = that.ns_items.slice(0,1); // ... so take first item
			that.ns_nav_next.get("a").attr("href", "#"+ns_next_target.attr("id"));
						
			var ns_prev_target = ns_target_item.prev();
			if (ns_prev_target.length < 1) // no prev ...
				ns_prev_target = that.ns_items.slice(n_items-1,n_items); // ... so take last item
			that.ns_nav_prev.get("a").attr("href", "#"+ns_prev_target.attr("id"));
		}
		else
		{
			var ns_prev_target = ns_target_item.prev();
			if (ns_prev_target.length < 1) // no prev ...
				ns_prev_target = that.ns_items.slice(n_items-1,n_items); // ... so take last item
			that.ns_nav_prev.get("a").attr("href", "#"+ns_prev_target.attr("id"));

			var ns_next_target = ns_target_item.next();
			if (ns_next_target.length < 1) // no more ...
				ns_next_target = that.ns_items.slice(0,1); // ... so take first item
			that.ns_nav_next.get("a").attr("href", "#"+ns_next_target.attr("id"));
		}

		return true;

	}
	//-----

	function on_link_click(ns_nav_item, n_inc) { // n_inc = (-1 | +1)

		if (!open_item(ns_nav_item, n_inc))
			return true; // allow default link action

		return false; // disable link
	}
	//-----

}
//-----


// end of script
