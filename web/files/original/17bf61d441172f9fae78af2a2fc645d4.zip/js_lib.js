/*bbcjs.addOnLoadItem(function() {
	OneShowLightbox.initLightboxes();
	OneShowGalleries.init();
	if (window.buttonHoverIE) {
		buttonHoverIE();
	}
});*/

glow.ready(function() {
	var ext_links = glow.dom.get('a.external');
	ext_links.each(function(i) {
		var ext_link = glow.dom.get(this);
		glow.events.addListener(ext_link, 'click', function() { openExternalLink(ext_link); return false; });
	});
});

function openExternalLink(ext_link) {
	window.open(ext_link.attr('href'));
	return false;
}

function handleClickTogShowHide(e) {
	if(this.className == 'hide')
	{
		alert('hidden');
	}
	else
	{
		alert('not hidden');
	}
	return false;
}	
function togShowHide(elemClickable) 
{
	bbcjs.dom.addEventListener( elemClickable, 'click',  handleClickTogShowHide);
}

function initClassName(elemId,tagName,classNameToSet) 
{
	$(elemId).getElementsByTagName(tagName)[0].className = classNameToSet;
}

function $q(selector, container) {
	container = container || document;
	var aReturn = [];
	var aParams = selector.split(".");
	if (aParams[0] == "") {
		aParams[0] = "*";
	}
	var aElements = container.getElementsByTagName(aParams[0]);
	
	if (!aParams[1]) {
		return aElements;
	}
	for (var n = 0; n < aElements.length; n++) {
		if (bbcjs.dom.hasClassName(aElements[n], aParams[1])) {
			aReturn[aReturn.length] = aElements[n];
		}
	}
	return aReturn;
}

function isWithin(oInner, oOuter) {
	if (!oInner || !oOuter) return false;
	while ((oInner = oInner.parentNode) && oInner != oOuter);
	return oInner == oOuter;
}

/*TOOLTIP OBJECT*/

var Tooltip = function(oOpts) {
	this.element;
	this.opts = {
		offsetX: 5,
		offsetY: 20,
		followMouse: true,
		delay: 300,
		delayWhileStatic: false,
		className: ""
	}
	this.showInterval; //holds delay interval
	this.moveEventId = null;
	this.overEventId = null;
	this.isShown = false;
	this.isActive = false;
	
	//set options
	if (oOpts) {
		this.opts = Object.extend(this.opts, oOpts);
	}
	//create element
	var tmpElement = document.createElement("div");
	tmpElement.innerHTML = '<div class="uiTooltip ' + this.opts.className + '"></div>';
	this.element = tmpElement.childNodes[0];
	document.body.appendChild(this.element);
	//add to array
	Tooltip.tooltips[Tooltip.tooltips.length] = this;
}
Tooltip.tooltips = []; //stores all tooltips
Tooltip.hideAll = function() {
	for (var n = 0; n < Tooltip.tooltips.length; n++) {
		Tooltip.tooltips[n].hide();
	}
}
Tooltip.prototype = {
	setContent: function(newContent) {
		this.element.innerHTML = newContent;
	},
	
	activate: function() {
		if (this.isActive) {
			return;
		}
		this.isActive = true;
		this.addMoveEvent();
		var currentInstance = this;
		window.clearInterval(this.showInterval);
		this.showInterval = window.setInterval(function() {
			currentInstance.show();
		}, this.opts.delay);
	},
	
	show: function() {
		this.element.style.display = "block";
		window.clearInterval(this.showInterval);
		this.isShown = true;
		if (!this.opts.followMouse) {
			this.addOverEvent();
		}
	},
	
	hide: function() {
		window.clearInterval(this.showInterval);
		this.element.style.display = "";
		this.isShown = false;
		this.isActive = false;
		this.removeMoveEvent();
		this.removeOverEvent();
	},
	
	addMoveEvent: function() {
		this.moveEventId = bbcjs.dom.addEventListener(document, 'mousemove', this.moveEvent, this);
	},
	
	removeMoveEvent: function() {
		if (this.moveEventId !== null) {
			bbcjs.dom.removeEventListener(this.moveEventId);
			this.moveEventId = null;
		}
	},
	
	addOverEvent: function() {
		this.overEventId = bbcjs.dom.addEventListener(this.element, 'mouseover', this.hide, this);
	},
	
	removeOverEvent: function() {
		if (this.overEventId !== null) {
			bbcjs.dom.removeEventListener(this.overEventId);
			this.overEventId = null;
		}
	},
	
	moveEvent: function(e) {
		if (!this.opts.followMouse && this.isShown) {
			this.removeMoveEvent();
			if (this.opts.delay > 0) return;
		}
		
		this.element.style.left = (e.pageX || (e.clientX + (document.documentElement.scrollLeft || document.body.scrollLeft))) + this.opts.offsetX + "px";
		this.element.style.top = (e.pageY || (e.clientY + (document.documentElement.scrollTop || document.body.scrollTop))) + this.opts.offsetY + "px";
		
		//move off the right hand side
		var difference;
		if ((difference = (e.clientX + this.element.offsetWidth + this.opts.offsetX) - document.body.clientWidth) > 0) {
			this.element.style.left = (this.element.style.left.substr(0, this.element.style.left.length - 2) - difference) + "px";
		}
		
		if (!this.isShown && this.opts.delayWhileStatic) {
			window.clearInterval(this.showInterval);
			var currentInstance = this;
			this.showInterval = window.setInterval(function() {
				currentInstance.show();
			}, this.opts.delay);
		}
	}
};

/*add gallery mouseovers*/
var OneShowGalleries = {
	init: function() {
		var aGalleries = $q("ul.gallery");
		
		for (var n = 0; n < aGalleries.length; n++) {
			OneShowGalleries.initGallery(aGalleries[n]);
		}
	},
	
	initGallery: function(oGallery) {
		var aImages = $q("div.boxThumb", oGallery);
		var tooltipNode;
		
		for (var n = 0; n < aImages.length; n++) {
			tooltipNode = $q("img", aImages[n])[0];
			aImages[n].oTooltip = new Tooltip();
			aImages[n].oTooltip.setContent('<div class="shadow"></div><div class="inner">' + tooltipNode.alt + '</div>');
			
			aImages[n].onmouseover = function(e) {
				e = e || window.event;
				var relatedTarget = e.relatedTarget || e.fromElement;
				if (this != relatedTarget && !isWithin(relatedTarget, this)) {
					this.oTooltip.activate();
				}
			}
			aImages[n].onmouseout = function(e) {
				e = e || window.event;
				var relatedTarget = e.relatedTarget || e.toElement;
				if (this != relatedTarget && !isWithin(relatedTarget, this)) {
					this.oTooltip.hide();
				}
			}
		}
	}
}