/*

	Retrieves info from link, loads in lightbox version of writing page, then shows writing in a lightbox.

	Relies on CSS.

	Author: Michael Koderisch 2010-12-07

*/

function WritingLightbox(args) {
	this.panel = null; // store the panel

	this.ns_links = glow.dom.get(args['writing-links']); // get all links
	this.n_items = this.ns_links.length;
	this.init(this.ns_links);
}
//-----

WritingLightbox.prototype.init = function() {

// MAINTAINED VARIABLES:
	var that = this;

	this.ns_links.each(function(i) {
		var ns_link = glow.dom.get(this);
		glow.events.addListener(ns_link, 'click', function() { show_writing(i); return false; });
	});
	
// INNER FUNCTIONS:

	function show_writing(i) {
		if (i < 0 || i >= that.n_items)
			return;
		
		that.ph_index = i; // record the current writing in the lightbox
		var ns_link = glow.dom.get(that.ns_links[i]);

		var writing_file_path = ns_link.attr('href')+'?lightbox';	// get the file name from link tag url
		var writing_title = ns_link.attr('title');						// get title from link tag
		get_and_show_writing(writing_file_path,writing_title);
	}
	//-----

	function get_and_show_writing(writing_file_path,writing_title) {

		glow.net.get(writing_file_path, {
			useCache: true,
			onLoad: function(response) {
				var title = writing_title;
				var res_text = response.text();
				show_writing_panel(title, res_text);
			},
			onError: function(response) {
				alert("Error getting data from: " + writing_file_path + "\n\n" + response.statusText());
			}
		});
	}
	//-----

	function show_writing_panel(title, res_text) {
		var ns_panel = null // content for panel
			, ns_close = null // text added to close button
			;
		if (!that.panel) {
			ns_panel = glow.dom.create(
				  '<div id="writing-panel">'
					+ '<h2 class="hd">' + title + '</h2>'
					+ '<div id="wrt_p_text"></div>'
					+ '<p class="ft">'
						+ '<a class="prev" href="#">Previous</a>'
						+ '<a class="next" href="#">Next</a>'
					+ '</p>'
				  + '</div>'
				);

			that.panel = new glow.widgets.Panel(ns_panel, {
				"closeOnMaskClick": false
				, width: "786px"
			});

			that.panel.container.addClass("ph-panel-container");
			that.panel.content.addClass("ph-panel-content");
			that.panel.body.addClass("ph-panel-body");
			that.panel.header.addClass("ph-panel-header");

			ns_close = glow.dom.create('<span class="close-text">Close</span>');
			that.panel.content.get("a.panel-close").addClass("close-btn");
			that.panel.content.get("a.panel-close").after(ns_close);

			// add navigation from within lightbox
			glow.events.addListener(that.panel.footer.get('a.prev'), 'click', function() { 
				show_writing(that.ph_index - 2); return false;
			});

			glow.events.addListener(that.panel.footer.get('a.next'), 'click', function() { 
				show_writing(that.ph_index + 2); return false;
			});
		}

		that.panel.header.get('h2').text(title);
		that.panel.body.get('#wrt_p_text').html(res_text);

		//make print button open new window
		var ext_link = that.panel.body.get('#wrt_p_text').get('a.external');
		glow.events.addListener(ext_link, 'click', function() { openExternalLink(ext_link); return false; });
		
		that.panel.show();
		set_buttons();
		
		that.panel.setPosition();
	}

	// enable/disable buttons
	function set_buttons() {

		var ns_footer = that.panel.footer;
		
		ns_footer.get('a.next').removeClass('no-next');
		ns_footer.get('a.prev').removeClass('no-prev');

		if (that.ph_index == 0 || that.ph_index == 1) {
			ns_footer.get('a.prev').addClass('no-prev');
		}
		else if (that.ph_index >= that.n_items - 2) {
			ns_footer.get('a.next').addClass('no-next');
		}
	}
	//-----

	
}
//-----


// end of script