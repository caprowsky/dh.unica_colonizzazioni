function appendArticleNav(elRef,linkHref)
{
	var navContainer = document.createElement("div");
	navContainer.setAttribute("class","articleNav");
	var navLink = document.createElement("a");
	navLink.setAttribute("href",linkHref);
	var navLinkImg = document.createElement("img");
	navLinkImg.setAttribute("src","/schools/primaryhistory/images/btn-article_next.gif");
	navLinkImg.setAttribute("border","0");
	navLinkImg.setAttribute("width","74");
	navLinkImg.setAttribute("height","28");
	navLinkImg.setAttribute("alt","next");
	navLink.appendChild(navLinkImg);
	navContainer.appendChild(navLink);

	elRef.appendChild(navContainer);
	
}

function initModuleTabsStyles(tabsClassname)
{
	var aNavTabs = bbcjs.dom.getElementsByClassName(tabsClassname);
	
	for (i=0;i<aNavTabs.length;i++) // go through the collection of all lists on the page with 'tabs' className.
	{
		var aListItems = aNavTabs[i][0]; 
		aListItems = aNavTabs[i].getElementsByTagName('LI');
		//alert(aListItems.length);

		for (j=0;j<aListItems.length;j++)
		{
			//alert(aListItems[j].firstChild.href.split('#')[1]);
			//alert(aListItems[j].firstChild.nodeName);
		}
		
		aListItems[0].className += ' selected';
		
		if ((aListItems.length < 2) && (aListItems[0].firstChild.nodeName == 'A'))
		{
			/*
			var tabLinkTitle = aListItems[0].firstChild.firstChild.nodeValue.toString();
			var tabPlainLabel = document.createTextNode(tabLinkTitle);
			aListItems[0].removeChild(aListItems[0].firstChild);
			aListItems[0].appendChild(tabPlainLabel);
			*/
			
			{
				aListItems[0].firstChild.href = '#';
				aListItems[0].firstChild.style.textDecoration = 'none';
			}
			//alert(aListItems[0].firstChild.nodeName);
			
		}
		
	}
	
	//alert("aNavTabs.length: " + aNavTabs.length);
	
	// create a new style element in the head and append rules as required
	/*var styleElem = document.createElement('style');
	var styleElemRule;
	var selector;
	
	styleElemRule = document.createTextNode('.js #boxPageContent{border:1px solid red;}');
	styleElem.appendChild(styleElemRule);
	
	
	
	headTag = document.getElementsByTagName('HEAD')[0];
	headTag.appendChild(styleElem);*/
}

/*
	moduletabs.js
	============================
	ifl/alistaird
	16/08/2007

	Class for creating Module Tabs*  functionality - hiding and displaying content within a page
	* http://developer.yahoo.com/ypatterns/pattern.php?pattern=moduletabs
*/

function ModuleTabs(element, argThing)
{
	if (argThing) 
	{
		alert (argThing);
	}
	
	if(!(element = $(element))) //make 'element' a node, even if a string ID is passed in as the parameter
	{
		eval("throw new Error('ModuleTabs: element is not a valid element')") //throws a  helpful error message if the element can't be found. "throw" is invalid syntax in earlier browsers, wrapping it in an eval prevents it causing a parse error until it comes to execute it
	}
		
	this.aTabs = element.getElementsByTagName('a');
	this.aModules = [];
	
	for (var i = 0; i < this.aTabs.length; i++){
		
		// get references to modules
		var sAnchor = this.aTabs[i].hash;
		var sId = sAnchor.slice(1,sAnchor.length);
		this.aModules.push ($(sId));
		
		// assign onclick function to tabs
		var oThis = this;
		this.aTabs[i].associatedTagIndex = i;
		this.aTabs[i].onclick = function() {
			oThis.showTab(this.associatedTagIndex);
			return !oThis._isCssOn(); // return false if css is on, true if off
		};
		
		// insert 'next' nav link (only for Article area, first section - and only if there's more than one section:)
		if (bbcjs.dom.parent( this.aModules[i] ).id == 'boxArticle'){
			if((i == 0) & (i != (this.aTabs.length -1)))
			{
				appendArticleNav(this.aModules[i],this.aTabs[(i+1)].href);
			}
		}
	}
}

ModuleTabs.prototype.showTab = function(selected){
	// hightlight selected tab
	for (var i = 0; i < this.aTabs.length; i++)
	{
		var elTab = bbcjs.dom.parent( this.aTabs[i] );
		var elTabA = this.aTabs[i];
		var elModule = this.aModules[i];
		
		
	
		//appendArticleNav(elModule,this.aTabs[(i+1)].href);
		
		// For article sections, append a link to the next section:

			/*
			
			alert(this.aTabs.length + " " + i);
			if(i == (this.aTabs.length - 1))
			{
				alert("end position");
			}

			navlink.onclick = function()
			{
				if()
				{
					
				} 
				else
				{
					
				}
				return false;
			}

			*/
		
		//
		
		if (i == selected){
			bbcjs.dom.addClassName( elTab, 'selected' );
			bbcjs.dom.addClassName( elModule, 'selected' );
			bbcjs.dom.removeClassName( elModule, 'hidden' );
		}
		else {
			bbcjs.dom.removeClassName( elTab, 'selected' );
			bbcjs.dom.removeClassName( elModule, 'selected' );
			bbcjs.dom.addClassName( elModule, 'hidden' );
		}
	}
}

ModuleTabs.prototype._isCssOn = function(){
	var blockCount = 0;
	
	bbcjs.forEach(this.aModules, function(elModule){
		if (bbcjs.dom.getStyle( elModule, 'display' ) == "block"){
			blockCount += 1;
		}
	});
	
	if(blockCount == this.aModules.length) // if all modules are display:block then assume css is off
	{
		return false;
	}
	else if (blockCount == 0) // if no styles set also assume that css is off (happens in IE 5 on MAC)
	{
		return false;
	}
	else
	{
		return true;
	}
}