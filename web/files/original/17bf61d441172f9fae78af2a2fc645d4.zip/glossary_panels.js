/*

	Uses included (but hidden) glossary to create InfoPanels for each glossary link on page.

	To use:

	(1) on outer page containing links ("containing page"), disable any code including older versions of Glow, e.g.
		<!--#include virtual="/schools/primaryhistory/${ph-unit}/includes/glow.sssi" -->

	(2) include Glow 1.x.x via Gloader on on containing page:
		<script type="text/javascript" src="http://www.bbc.co.uk/glow/gloader.js"></script>
		<script type="text/javascript">
		  gloader.load(["glow", "1", "glow.dom", "glow.widgets.InfoPanel"]);
		</script>

	(3) include link to this script on containing page, after glow statement.

	(4) include glossary via SSI on containing page inside <div class="glossary-hidden"></div>, e.g. just before </body>.

	(5) at top of content section with links (e.g. top of content include), set a variable for glossary page URL, e.g.
		<!--#set var="glossary_url" value="/schools/primaryhistory/${ph-unit}/${ph-topic}/glossary/index.shtml" -->

	(6) create each glossary link as e.g.
		<a class="glossaryTerm" href="<!--#echo var="glossary_url" -->#Senate">Senate</a>

	(7) ensure glossary include page has term and definition for each linked term in form:
		<dt id="#Senate>TERM</dt>
		<dd>DEFINITION</dd>

	Author: <a href="mailto:Michael.Taylor1@bbc.co.uk">Mike Taylor</a> 2008-11-11
*/
glow.ready(function() {
	var dbg = false
		, b_warn_if_missing = true // set true to show warning alert if glossary term or definition are missing
		, re_id = /#([^#]+)$/ // match for bookmarks into glossary
		, ns_glossary_links = glow.dom.get(".glossaryTerm")
		, ns_genericInfoPanel = glow.dom.create(
			'<div class="phInfoPanel">'
			+ '<h2 class="hd"></h2>'
			+ '<p></p>'
			+ '</div>'
			)
		;

	if (dbg) alert("Regexp for glossary ids: [" + re_id + "]");

	// collect links, look up matching glossary items and create infopanels
	ns_glossary_links.each(function(i) {

		var ns_link = glow.dom.get(this) // the link to the glossary
			, ns_info = [] // clone of empty info panel
			, ns_term = [] // text of term captured from included glossary 
			, ns_define = [] // text of definition " " " "
			, glossary_id = '' // id taken from bookmark in glossary link
			; 

		if (dbg) alert("Processing link: [" + ns_link.attr("href") + "]");

		a_matches = re_id.exec(ns_link.attr("href"));
		if (!a_matches) 
			return false;

		glossary_id = a_matches[1];

		if (dbg) alert("Glossary id: [" + glossary_id + "]");

		// collect the glossary term & definition and put into a panel:
		ns_term = glow.dom.get("#" + glossary_id);
		ns_define = glow.dom.get("#" + glossary_id).next();

		if (b_warn_if_missing && (ns_term.length < 1 || !ns_term.is("dt"))) {
			alert('Warning - reference to glossary item "' + glossary_id + '" but no matching glossary entry found.');
			return false;
		}
		if (b_warn_if_missing && (ns_define.length < 1 || !ns_define.is("dd"))) {
			alert('Warning - reference to glossary item "' + glossary_id + '" - entry found without definition.');
			return false;
		}

		ns_info = ns_genericInfoPanel.clone();

		// change a tag to span tag
		ns_span = glow.dom.create("<span>"+ns_link.text()+"</span>").addClass("glossaryTerm");
		ns_link.after(ns_span);
		ns_link.destroy();
		
		// override the default info panel content, then create it:
		//alert('wanting to set to: '+ns_term.text());
		ns_info.get('h2').text(ns_term.text());
		ns_info.get('p').text(ns_define.text());
		ns_infopanel = new glow.widgets.InfoPanel(ns_info, { hideWindowedFlash:false, context: ns_span });

		ns_infopanel.content.addClass("phInfoPanelContent");


		
		
		// simple event handling:
		glow.events.addListener(ns_span, 'mouseover', function(glow_evt) { this.show(); return false }, ns_infopanel);
		glow.events.addListener(ns_span, 'click', function(glow_evt) { this.show(); return false }, ns_infopanel);
		glow.events.addListener(ns_span, 'mouseout', function(glow_evt) { this.hide(); return false }, ns_infopanel);

	});


});

/* end of script */