/*
	List of game specs.

	To add a new game, copy and paste the sample object at the end of the list.

	Use literal characters in titles (e.g. use " & " not " &amp; ").

	Author: <a href="mailto:Michael.Taylor1@bbc.co.uk">Mike Taylor</a> 2008-11-13
*/

/*

flashVars: {navColour: "red", username: "Frankie"}

*/

var ph_game_from_id = {

	// Ancient Greeks
	// Activity test
	"g_mytilene": {
		  "src": "/schools/primaryhistory/flash/mytilene/slideshow.swf"
		, "title": "BBC Primary History - Mytilene"
		, "height-px": 375
		, "width-px": 420
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ancient_greece/mytilene/slideshow.xml"}
	},
	
	// Activity test
	"g_olympics": {
		  "src": "/schools/primaryhistory/flash/olympics/slideshow.swf"
		, "title": "BBC Primary History - The Olympic Games"
		, "height-px": 349
		, "width-px": 497
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ancient_greece/olympics/slideshow.xml"}
	},
	
	// Activity test
	"g_theatre": {
		  "src": "/schools/primaryhistory/flash/theatre/slideshow.swf"
		, "title": "BBC Primary History - The theatre"
		, "height-px": 349
		, "width-px": 497
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ancient_greece/theatre/slideshow.xml"}
	},
	
	// Victorians
	// Activity test
	"v_workschoolplay": {
		  "src": "/schools/primaryhistory/flash/victorianchildren/slideshow.swf"
		, "title": "BBC Primary History - Victorian Britain"
		, "height-px": 458
		, "width-px": 641
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/victorians/slideshow.xml"}
	},
	
	"v_muckbrass": {
		  "src": "/history/interactive/games/victorian_muckbrass/muckbrass.swf"
		, "title": "BBC Primary History - Muck and Brass"
		, "height-px": 371
		, "width-px": 600
		, "min-flash-ver": "7.0.0"
		, "theflashvars": {xmlconfig: "xml/ancient_greece/olympics/slideshow.xml"}
	},
	
	// WW2
	// Activity test
	"ww2_letters": {
		  "src": "/schools/primaryhistory/flash/ww2children/letters/slideshow.swf"
		, "title": "BBC Primary History - Evacuees' letters"
		, "height-px": 485
		, "width-px": 780
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ww2/letters/slideshow.xml"}
	},
	// Activity test
	"ww2_rationing": {
		  "src": "/schools/primaryhistory/flash/ww2children/ration/slideshow.swf"
		, "title": "BBC Primary History - Rationing"
		, "height-px": 485
		, "width-px": 780
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ww2/rationing/slideshow.xml"}
	},
	// Activity test
	"ww2_house": {
		  "src": "/schools/primaryhistory/flash/ww2children/warhome/slideshow.swf"
		, "title": "BBC Primary History - A wartime home"
		, "height-px": 485
		, "width-px": 780
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ww2/house/slideshow.xml"}
	},
	
	// Indus Valley
	// Activity test
	"indus_valley": {
		  "src": "/schools/primaryhistory/flash/indus_valley/iv_master.swf"
		, "title": "BBC Primary History - Indus Valley"
		, "height-px": 485
		, "width-px": 780
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ww2/letters/slideshow.xml"}
	},
	
	
	// Ancient Britain
	// History Activity
	
	"ab_stonehenge": {
		"src": "/history/interactive/virtual_tours/stonehenge/panorama.swf"
		,"title": "BBC History - 360&deg; panoramic view of Stonehenge"
		,"height-px": 475
		,"width-px": 770
		,"min-flash-ver": "7.0.0"
		},
	

	
	
	// Quizengine test
	"g_arts_and_theatre": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Arts and Theatre"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ancient_greece/g_artsandtheatre.xml"}
	},
	// Quizengine test
	"g_athens": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Athens"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ancient_greece/g_athens.xml"}
	},
	// Quizengine test
	"g_godsandheroes": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Gods and Heroes"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ancient_greece/g_godsandheroes.xml"}
	},
	// Quizengine test
	"g_greeksatwar": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Greeks at War"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ancient_greece/g_greeksatwar.xml"}
	},
	// Quizengine test
	"g_growingupingreece": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Growing Up in Greece"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ancient_greece/g_growingupingreece.xml"}
	},
	// Quizengine test
	"g_homelife": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Home Life"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ancient_greece/g_homelife.xml"}
	},
	// Quizengine test
	"g_seaandships": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Sea and Ships"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ancient_greece/g_seaandships.xml"}
	},
	// Quizengine test
	"g_sparta": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Sparta"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ancient_greece/g_sparta.xml"}
	},
	// Quizengine test
	"g_thegreekworld": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - The Greek World"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ancient_greece/g_thegreekworld.xml"}
	},
	// Quizengine test
	"g_theolympicgames": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - The Olympic Games"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ancient_greece/g_theolympicgames.xml"}
	},
	
	// Anglos
	// Quizengine test
	"a_alfredthegreat": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Alfred the Great"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/anglos/a_alfredthegreat.xml"}
	},
	"a_anglosaxonlife": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Anglo-Saxon Life"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/anglos/a_anglosaxonlife.xml"}
	},
	"a_beliefs": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Anglo-Saxon Beliefs"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/anglos/a_beliefs.xml"}
	},
	"a_growingup": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Growing Up"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/anglos/a_growingup.xml"}
	},
	"a_invasionandsettlement": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Invasion and Settlement"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/anglos/a_invasionandsettlement.xml"}
	},
	"a_kingsandlaws": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Kings and Laws"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/anglos/a_kingsandlaws.xml"}
	},
	"a_storiesandpastimes": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Stories and Pastimes"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/anglos/a_storiesandpastimes.xml"}
	},
	"a_whathappenedtothem": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - What Happened to Them?"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/anglos/a_whathappenedtothem.xml"}
	},
	"a_whoweretheanglos": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Who were the Anglo-Saxons?"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/anglos/a_whoweretheanglos.xml"}
	},
	
	"a_atwar": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Anglo-Saxons at War"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/anglos/a_atwar.xml"}
	},
	
	"a_normans": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - The Normans"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/anglos/a_normans.xml"}
	},
	
	// Romans
	// Quizengine test
	"r_cityofrome": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - City of Rome"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/romans/r_cityofrome.xml"}
	},
	"r_familiesandchildren": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Families and Children"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/romans/r_familiesandchildren.xml"}
	},
	"r_invasion": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Invasion"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/romans/r_invasion.xml"}
	},
	"r_leisure": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Leisure"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/romans/r_leisure.xml"}
	},
	"r_rebellion": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Rebellion"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/romans/r_rebellion.xml"}
	},
	"r_religion": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Religion"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/romans/r_religion.xml"}
	},
	"r_roadsandplaces": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Roads and Places"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/romans/r_roadsandplaces.xml"}
	},
	"r_romandefenceofbritain": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Roman Defence of Britain"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/romans/r_romandefenceofbritain.xml"}
	},
	"r_romanremains": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Roman Remains"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/romans/r_romanremains.xml"}
	},
	"r_technology": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Technology"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/romans/r_technology.xml"}
	},
	"r_theromanarmy": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - The Roman Army"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/romans/r_theromanarmy.xml"}
	},
	"r_romansinscotland": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Romans in Scotland"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/romans/r_romansinscotland.xml"}
	},	
	
	
		// Victorians
	// Quizengine test
	
	"v_childrenatplay": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Children at Play"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/victorians/v_childrenatplay.xml"}
	},
	"v_childrenatschool": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Children at School"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/victorians/v_childrenatschool.xml"}
	},
	"v_childrenatwork": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Children at Work"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/victorians/v_childrenatwork.xml"}
	},
	"v_childrenincoalmines": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Children in Coal Mines"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/victorians/v_childrenincoalmines.xml"}
	},
	"v_childreninfactories": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Children at Factories"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/victorians/v_childreninfactories.xml"}
	},
	"v_introduction": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - An Introduction"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/victorians/v_introduction.xml"}
	},
	"v_leisure": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Leisure"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/victorians/v_leisure.xml"}
	},
	"v_otherjobs": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Other Jobs Children Did"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/victorians/v_otherjobs.xml"}
	},
	"v_richandpoorfamilies": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Children at Play"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/victorians/v_richandpoorfamilies.xml"}
	},
	"v_schools": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Victorian Schools"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/victorians/v_schools.xml"}
	},
	"v_toysandgames": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Toys and Games"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/victorians/v_toysandgames.xml"}
	},
	"v_highland_clearances": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Highland Clearances"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/victorians/v_highlandclearances.xml"}
	},
	"v_victorianscotland": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Victorian Scotland"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/victorians/v_victorianscotland.xml"}
	},
	"v_famine_and_emigration": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Famine and Emigration"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/victorians/v_famineandemigration.xml"}
	},
	
			// Vikings
	// Quizengine test
	
	"vk_athome": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Vikings at Home"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/vikings/vk_athome.xml"}
	},
	"vk_atsea": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Vikings at Sea"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/vikings/vk_atsea.xml"}
	},
	"vk_beliefsandstories": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Beliefs and Stories"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/vikings/vk_beliefsandstories.xml"}
	},
	"vk_familylife": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Family Life"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/vikings/vk_familylife.xml"}
	},
	"vk_raiders": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Viking Raiders"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/vikings/vk_raiders.xml"}
	},
	"vk_settlements": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Settlements"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/vikings/vk_settlements.xml"}
	},
	"vk_towns": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Viking Towns"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/vikings/vk_towns.xml"}
	},
	"vk_tradeandexploration": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Trade and Exploration"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/vikings/vk_tradeandexploration.xml"}
	},
	"vk_whathappenedtothevikings": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - What Happened to the Vikings?"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/vikings/vk_whathappenedtothevikings.xml"}
	},
	"vk_whowerethevikings": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Who were the Vikings?"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/vikings/vk_whowerethevikings.xml"}
	},
	
	
	
	
				// World War 2
	// Quizengine test

	"ww2_airraids": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Air Raids"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ww2/ww2_airraids.xml"}
	},
	"ww2_childrenatwar": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Children at War"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ww2/ww2_childrenatwar.xml"}
	},
	"ww2_dailylife": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Daily Life"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ww2/ww2_dailylife.xml"}
	},
	"ww2_evacuation": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Evacuation"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ww2/ww2_evacuation.xml"}
	},
	"ww2_foodandshopping": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Food and Shopping"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ww2/ww2_foodandshopping.xml"}
	},
	"ww2_growingupinwartime": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Growing Up in Wartime"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ww2/ww2_growingupinwartime.xml"}
	},
	"ww2_thewareffort": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - The War Effort"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ww2/ww2_thewareffort.xml"}
	},
	"ww2_thewarends": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - The War Ends"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ww2/ww2_thewarends.xml"}
	},
	"ww2_wartimehomes": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Wartime Homes"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ww2/ww2_wartimehomes.xml"}
	},
	"ww2_worldatwar": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - World at War"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ww2/ww2_worldatwar.xml"}
	},
	"ww2_scotlandsblitz": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Scotland's Blitz"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ww2/ww2_scotlandsblitz.xml"}
	},
	
	
				// Indus Valley
	// Quizengine test

	"i_land_of_the_indus": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Land of the Indus"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/indus_valley/i_land_of_the_indus.xml"}
	},
	"i_discovery": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Discovery"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/indus_valley/i_discovery.xml"}
	},
	"i_way_of_life": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Way of Life"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/indus_valley/i_way_of_life.xml"}
	},
	"i_home_life": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Home Life"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/indus_valley/i_home_life.xml"}
	},
	"i_trade_and_travel": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Trade and Travel"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/indus_valley/i_trade_and_travel.xml"}
	},
	"i_art_and_writing": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Art and Writing"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/indus_valley/i_art_and_writing.xml"}
	},
	"i_technology_and_jobs": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Technology and Jobs"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/indus_valley/i_technology_and_jobs.xml"}
	},
	"i_food_and_farming": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Food and Farming"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/indus_valley/i_food_and_farming.xml"}
	},
	"i_games_and_toys": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Games and Toys"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/indus_valley/i_games_and_toys.xml"}
	},
	"i_the_end_of_the_indus": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - The End of the Indus"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/indus_valley/i_the_end_of_the_indus.xml"}
	},
	"i_what_they_did_for_us": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - What They Did For Us"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/indus_valley/i_what_they_did_for_us.xml"}
	},
	
	
	
	// A History of the World
	
	"ahotw_beninbronze": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC - World History: Benin plaque"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/worldhistory/benin_bronze.xml"}
	},
	
	"ahotw_doubleheadedserpent": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC - World History: Double Headed Serpent"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/worldhistory/double_headed_serpent.xml"}
	},
	
	"ahotw_rosettastone": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC - World History: Rosetta Stone"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/worldhistory/rosetta_stone.xml"}
	},
	
	"ahotw_suttonhoohelmet": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC - World History: Sutton Hoo Helmet"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/worldhistory/sutton_hoo_helmet.xml"}
	},
	
	"ahotw_gameofur": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC - World History: The Royal Game of Ur"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/worldhistory/royal_game_of_ur.xml"}
	},
	
	"ahotw_emperoraugustus": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC - World History: Head of Emperor Augustus"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/worldhistory/emperor_augustus.xml"}
	},
	
	"ahotw_hornedjitef": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC - World History: Mummy of Hornedjitef"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/worldhistory/mummy_hornedjitef.xml"}
	},
	
	"ahotw_easterisland": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC - World History: Easter Island Statue"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/worldhistory/easter_island_statue.xml"}
	},
	
	"ahotw_ramesses": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC - World History: Ramesses II"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/worldhistory/ramesses.xml"}
	},
	
		"ahotw_tangtombfigures": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC - World History: Tang Tomb Figures"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/worldhistory/tang_tomb_figures.xml"}
	},
	
	"ahotw_piecesofeight": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC - World History: Pieces of Eight"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/worldhistory/pieces_of_eight.xml"}
	},
	
	"ahotw_hoxnehoard": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC - World History: Hoxne Hoard"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/worldhistory/hoxne_hoard.xml"}
	},
	
	"ahotw_rhino": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC - World History: D&uuml;rer's Rhinocerous"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/worldhistory/durer_rhino.xml"}
	},
	
		// UK History
		// Quizengine test
	"uk_jacobites": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Jacobites"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ukhistory/uk_jacobites.xml"}
	},
	"uk_robert_burns": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Robert Burns cravat pin"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ukhistory/uk_robert_burns.xml"}
	},	
	"uk_iolaire_disaster": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Iolaire Disaster"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ukhistory/uk_iolaire_disaster.xml"}
	},	
	"uk_marianne_grants_trunk": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Marianne Grant's Trunk"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ukhistory/uk_marianne_grants_trunk.xml"}
	},
	"uk_bangor_bell": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Bangor Bell"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ukhistory/uk_bangor_bell.xml"}
	},
	"uk_famine_tokens": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Famine relief tokens"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ukhistory/uk_famine_tokens.xml"}
	},
	"uk_titanic_ticket": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Titanic launch ticket"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ukhistory/uk_titanic_ticket.xml"}
	},
	"uk_ejection_seat": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Ejection Seat ticket"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ukhistory/uk_ejection_seat.xml"}
	},
	"uk_pithead_baths": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Pithead Baths"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ukhistory/uk_pithead_baths.xml"}
	},
	"uk_roman_gemstones": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Roman Gemstones from Caerleon"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ukhistory/uk_roman_gemstones.xml"}
	},
	"uk_waterlilies": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Waterlilies by Monet"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ukhistory/uk_waterlilies.xml"}
	},
	"uk_muslim_prayer_compass": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Muslim Prayer Compass"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ukhistory/uk_muslim_prayer_compass.xml"}
	},
	"uk_draft_peace_treaty": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Draft Peace Treaty"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ukhistory/uk_draft_peace_treaty.xml"}
	},
	"uk_cytundeb_drafft_heddwch": {
		  "src": "/schools/primaryhistory/flash/w_quizengine.swf"
		, "title": "BBC Hanes Prydain - Cytundeb Drafft Heddwch"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ukhistory/uk_cytundeb_drafft_heddwch.xml"}
	},
	"uk_baddondai_pen_pwll": {
		  "src": "/schools/primaryhistory/flash/w_quizengine.swf"
		, "title": "BBC Hanes Prydain - Baddondai Pen Pwll"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ukhistory/uk_baddondai_pen_pwll.xml"}
	},
	"uk_tlysau_rhufeinig": {
		  "src": "/schools/primaryhistory/flash/w_quizengine.swf"
		, "title": "BBC Hanes Prydain - Tlysau Rhufeinig"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ukhistory/uk_tlysau_rhufeinig.xml"}
	},
	"uk_liliau_dwr": {
		  "src": "/schools/primaryhistory/flash/w_quizengine.swf"
		, "title": "BBC Hanes Prydain - Lil&iuml;au D&#373;r gan Monet"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ukhistory/uk_liliau_dwr.xml"}
	},
	"uk_cwmpawd_gweddio_mwslimaidd": {
		  "src": "/schools/primaryhistory/flash/w_quizengine.swf"
		, "title": "BBC Hanes Prydain - Cwmpawd Gwedd&iuml;o Mwslimaidd"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ukhistory/uk_cwmpawd_gweddio_mwslemaidd.xml"}
	},
	"uk_communication": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Trans-Atlantic Cable"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ukhistory/uk_communication.xml"}
	},
	"uk_industrialisation": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Wedgwood Plate"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ukhistory/uk_industrialisation.xml"}
	},
	"uk_political": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - The Magna Carta"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/ukhistory/uk_political.xml"}
	},
	
	
	// Quizengine test
	"quizengine-test3": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Quizengine 3"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/quizexample3.xml"}
	},

	
	
	
	
	// Sub-index games
	
	// Romans
	"offas-ford": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/games/digitup/romans/digitup.swf"
		, "title": "BBC Primary History - Dig It Up: Romans"
		, "height-px": 450
		, "width-px": 760
		, "min-flash-ver": "8.0.0"
	},
	
	// Anglos
	"hild_game": {
		  "src": "/schools/primaryhistory/anglo_saxons/anglo-saxon_life/includes/activities/swf/activity.swf"
		, "title": "BBC Primary History - Hild and the village feast"
		, "height-px": 460
		, "width-px": 550
		, "min-flash-ver": "8.0.0"
	},

	// Vikings
	"thorkel_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/activities/vikings/activity.swf"
		, "title": "BBC Primary History - Thorkel and the trading voyage"
		, "height-px": 460
		, "width-px": 550
		, "min-flash-ver": "8.0.0"
	},
	
	// Anglos
	"anglos_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/games/digitup/saxons/digitup.swf"
		, "title": "BBC Primary History - Dig It Up: Anglo-Saxons"
		, "height-px": 450	/* height of game in pixels */
		, "width-px": 760
		, "min-flash-ver": "8.0.0" /* minimum Flash version required by this game */
	},

	// Vikings
	"vikings_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/games/digitup/vikings/digitup.swf"
		, "title": "BBC Primary History - Dig It Up: Vikings"
		, "height-px": 450	/* height of game in pixels */
		, "width-px": 760
		, "min-flash-ver": "8.0.0" /* minimum Flash version required by this game */
	},

	// Ancient Greece
		"greece_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/games/greece/greekhero.swf"
		, "title": "BBC Primary History - Greek Hero"
		, "height-px": 450	/* height of game in pixels */
		, "width-px": 760
		, "min-flash-ver": "8.0.0" /* minimum Flash version required by this game */
	},
	
	"romans-source_analysis": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/games/source_analysis/romans/shell.swf"
		, "title": "BBC Primary History - Cabinet of Curiosities"
		, "height-px": 450
		, "width-px": 760
		, "min-flash-ver": "8.0.0"
	},
	
	
	// Victorians
	"victorians_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/games/time_capsule/victorians/timecapsules.swf"
		, "title": "BBC Primary History - Time Capsules: Victorians"
		, "height-px": 450	/* height of game in pixels */
		, "width-px": 760
		, "min-flash-ver": "8.0.0" /* minimum Flash version required by this game */
	},
	
		
	// WW2
	"ww2_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/games/time_capsule/wwtwo/timecapsulesww2.swf"
		, "title": "BBC Primary History - Time Capsules: World War 2"
		, "height-px": 450	/* height of game in pixels */
		, "width-px": 760
		, "min-flash-ver": "8.0.0" /* minimum Flash version required by this game */
	},
	
	
	//Indus Valley
	"indus_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/games/indus_trader/indus_valley.swf"
		, "title": "BBC Primary History - Indus Trader"
		, "height-px": 450	/* height of game in pixels */
		, "width-px": 760
		, "min-flash-ver": "8.0.0" /* minimum Flash version required by this game */
	},
	
	//Famous People
	
	// GAMES
	// Henry VIII
	"henry_viii_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/henry/engine.swf"
		, "title": "BBC Primary History - Famous People - Henry VIII"
		, "height-px": 577
		, "width-px": 944
		, "min-flash-ver": "10.0.0"
		, "theflashvars": {gameConfigPath: "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/henry/config.xml"}
	},
	
	// Shakespeare
	"shakespeare_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/shakespeare/engine.swf"
		, "title": "BBC Primary History - Famous People - William Shakespeare"
		, "height-px": 577
		, "width-px": 944
		, "min-flash-ver": "10.0.0"
		, "theflashvars": {gameConfigPath: "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/shakespeare/config.xml"}
	},
	
	// Charles Dickens
	"dickens_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/dickens/engine.swf"
		, "title": "BBC Primary History - Famous People - Charles Dickens"
		, "height-px": 577
		, "width-px": 944
		, "min-flash-ver": "10.0.0"
		, "theflashvars": {gameConfigPath: "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/dickens/config.xml"}
	},
	
	// Mary Anning	
	"anning_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/anning/engine.swf"
		, "title": "BBC Primary History - Famous People - Mary Anning"
		, "height-px": 577
		, "width-px": 944
		, "min-flash-ver": "10.0.0"
		, "theflashvars": {gameConfigPath: "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/anning/config.xml"}
	},

	// Florence Nightingale	
	"nightingale_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/nightingale/engine.swf"
		, "title": "BBC Primary History - Famous People - Florence Nightingale"
		, "height-px": 577
		, "width-px": 944
		, "min-flash-ver": "10.0.0"
		, "theflashvars": {gameConfigPath: "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/nightingale/config.xml"}
	},	
	
	// Sebastian Coe	
	"seb_coe_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/seb_coe/engine.swf"
		, "title": "BBC Primary History - Famous People - Sebastian Coe"
		, "height-px": 577
		, "width-px": 944
		, "min-flash-ver": "10.0.0"
		, "theflashvars": {gameConfigPath: "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/seb_coe/config.xml"}
	},	
	
	// Tanni Grey-Thompson	
	"thompson_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/thompson/engine.swf"
		, "title": "BBC Primary History - Famous People - Tanni Grey-Thompson"
		, "height-px": 577
		, "width-px": 944
		, "min-flash-ver": "10.0.0"
		, "theflashvars": {gameConfigPath: "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/thompson/config.xml"}
	},
	
	// Christopher Columbus	
	"columbus_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/columbus/engine.swf"
		, "title": "BBC Primary History - Famous People - Christopher Columbus"
		, "height-px": 577
		, "width-px": 944
		, "min-flash-ver": "10.0.0"
		, "theflashvars": {gameConfigPath: "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/columbus/config.xml"}
	},
	
	// Dylan Thomas	
	"dylan_thomas_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/dylan_thomas/engine.swf"
		, "title": "BBC Primary History - Famous People - Dylan Thomas"
		, "height-px": 577
		, "width-px": 944
		, "min-flash-ver": "10.0.0"
		, "theflashvars": {gameConfigPath: "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/dylan_thomas/config.xml"}
	},
	
	// Elizabeth Fry	
	"elizabeth_fry_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/elizabeth_fry/engine.swf"
		, "title": "BBC Primary History - Famous People - Elizabeth Fry"
		, "height-px": 577
		, "width-px": 944
		, "min-flash-ver": "10.0.0"
		, "theflashvars": {gameConfigPath: "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/elizabeth_fry/config.xml"}
	},
	
	// Mary Seacole	
	"mary_seacole_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/mary_seacole/engine.swf"
		, "title": "BBC Primary History - Famous People - Mary Seacole"
		, "height-px": 577
		, "width-px": 944
		, "min-flash-ver": "10.0.0"
		, "theflashvars": {gameConfigPath: "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/mary_seacole/config.xml"}
	},
	
	// Nelson Mandela	
	"nelson_mandela_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/nelson_mandela/engine.swf"
		, "title": "BBC Primary History - Famous People - Nelson Mandela"
		, "height-px": 577
		, "width-px": 944
		, "min-flash-ver": "10.0.0"
		, "theflashvars": {gameConfigPath: "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/nelson_mandela/config.xml"}
	},
	
	// Samuel Pepys	
	"samuel_pepys_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/samuel_pepys/engine.swf"
		, "title": "BBC Primary History - Famous People - Samuel Pepys"
		, "height-px": 577
		, "width-px": 944
		, "min-flash-ver": "10.0.0"
		, "theflashvars": {gameConfigPath: "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/samuel_pepys/config.xml"}
	},
	
	// Brunel	
	"brunel_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/brunel/engine.swf"
		, "title": "BBC Primary History - Famous People - Isambard Kingdom Brunel"
		, "height-px": 577
		, "width-px": 944
		, "min-flash-ver": "10.0.0"
		, "theflashvars": {gameConfigPath: "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/brunel/config.xml"}
	},
	
	// Mary Queen of Scots	
	"mary_queen_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/mary_queen/engine.swf"
		, "title": "BBC Primary History - Famous People - Mary Queen of Scots"
		, "height-px": 577
		, "width-px": 944
		, "min-flash-ver": "10.0.0"
		, "theflashvars": {gameConfigPath: "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/mary_queen/config.xml"}
	},
	
	// George Stephenson	
	"stephenson_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/stephenson/engine.swf"
		, "title": "BBC Primary History - Famous People - George Stephenson"
		, "height-px": 577
		, "width-px": 944
		, "min-flash-ver": "10.0.0"
		, "theflashvars": {gameConfigPath: "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/stephenson/config.xml"}
	},
	
	// Edward Jenner
	"jenner_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/jenner/engine.swf"
		, "title": "BBC Primary History - Famous People - Edward Jenner"
		, "height-px": 577
		, "width-px": 944
		, "min-flash-ver": "10.0.0"
		, "theflashvars": {gameConfigPath: "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/jenner/config.xml"}
	},

	// John Logie Baird
	"baird_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/baird/engine.swf"
		, "title": "BBC Primary History - Famous People - John Logie Baird"
		, "height-px": 577
		, "width-px": 944
		, "min-flash-ver": "10.0.0"
		, "theflashvars": {gameConfigPath: "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/baird/config.xml"}
	},	

	// Mozart
	"mozart_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/mozart/engine.swf"
		, "title": "BBC Primary History - Famous People - Wolfgang Amadeus Mozart"
		, "height-px": 577
		, "width-px": 944
		, "min-flash-ver": "10.0.0"
		, "theflashvars": {gameConfigPath: "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/mozart/config.xml"}
	},	
	
	// Churchill
	"churchill_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/churchill/engine.swf"
		, "title": "BBC Primary History - Famous People - Winston Churchill"
		, "height-px": 577
		, "width-px": 944
		, "min-flash-ver": "10.0.0"
		, "theflashvars": {gameConfigPath: "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/churchill/config.xml"}
	},		
	
	// Pocahontas
	"pocahontas_game": {
		  "src": "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/pocahontas/engine.swf"
		, "title": "BBC Primary History - Famous People - Pocahontas"
		, "height-px": 577
		, "width-px": 944
		, "min-flash-ver": "10.0.0"
		, "theflashvars": {gameConfigPath: "http://downloads.bbc.co.uk/schools/primaryhistory/famouspeople/games/pocahontas/config.xml"}
	},	
	// Florence Nightingale
	// Quizengine
	"florence_nightingale": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Florence Nightingale"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/florence_nightingale.xml"}
	},
	
	// Queen Elizabeth I
	// Quizengine
	"elizabeth_i": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Queen Elizabeth I"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/queen_elizabeth_i.xml"}
	},
	
	// Queen Elizabeth II
	// Quizengine
	"elizabeth_ii": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Queen Elizabeth II"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/queen_elizabeth_ii.xml"}
	},
		
	// Queen Victoria
	// Quizengine
	"victoria": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Queen Victoria"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/queen_victoria.xml"}
	},
	
	// Christopher Columbus
	// Quizengine
	"christopher_columbus": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Christopher Columbus"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/christopher_columbus.xml"}
	},
	
	// Wolfgang Amadeus Mozart
	// Quizengine
	"wolfgang_amadeus_mozart": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Wolfgang Amadeus Mozart"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/wolfgang_amadeus_mozart.xml"}
	},
	
	// Winston Churchill
	// Quizengine
	"winston_churchill": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Winston Churchill"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/winston_churchill.xml"}
	},
	
	// William Shakespeare
	// Quizengine
	"william_shakespeare": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - William Shakespeare"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/william_shakespeare.xml"}
	},
	
	// Dylan Thomas
	// Quizengine
	"dylan_thomas": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Dylan Thomas"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/dylan_thomas.xml"}
	},
	
	// CS Lewis
	// Quizengine
	"cs_lewis": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - CS Lewis"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/cs_lewis.xml"}
	},
	
	// Pocahontas
	// Quizengine
	"pocahontas": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Pocahontas"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/pocahontas.xml"}
	},
	
	// Henry VIII
	// Quizengine
	"henry_viii": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Henry VIII"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/henry_viii.xml"}
	},
	
	// Edward Jenner
	// Quizengine
	"edward_jenner": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Edward Jenner"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/edward_jenner.xml"}
	},
	
	// Mary Anning
	// Quizengine
	"mary_anning": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Mary Anning"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/mary_anning.xml"}
	},
	
	// John Logie Baird
	// Quizengine
	"john_logie_baird": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - John Logie Baird"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/john_logie_baird.xml"}
	},
	
	// Isambard Kingdom Brunel
	// Quizengine
	"isambard_kingdom_brunel": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Isambard Kingdom Brunel"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/isambard_kingdom_brunel.xml"}
	},
	
	// Sebastian Coe
	// Quizengine
	"sebastian_coe": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Sebastian Coe"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/sebastian_coe.xml"}
	},
	
	// Tanni Grey-Thompson
	// Quizengine
	"tanni_grey_thompson": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Tanni Grey-Thompson"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/tanni_grey_thompson.xml"}
	},
	
	// Samuel Pepys
	// Quizengine
	"samuel_pepys": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Samuel Pepys"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/samuel_pepys.xml"}
	},
	
	// Mary Queen of Scots
	// Quizengine
	"mary_queen_of_scots": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Mary Queen of Scots"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/mary_queen_of_scots.xml"}
	},
	
	// Elizabeth Fry
	// Quizengine
	"elizabeth_fry": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Elizabeth Fry"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/elizabeth_fry.xml"}
	},
	
	// Nelson Mandela
	// Quizengine
	"nelson_mandela": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Nelson Mandela"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/nelson_mandela.xml"}
	},
	
	// Mary Seacole
	// Quizengine
	"mary_seacole": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Mary Seacole"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/mary_seacole.xml"}
	},
	
	// George Stephenson
	// Quizengine
	"george_stephenson": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - George Stephenson"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/george_stephenson.xml"}
	},
	
	
// Charles Dickens
	// Quizengine
	"charles_dickens": {
		  "src": "/schools/primaryhistory/flash/quizengine.swf"
		, "title": "BBC Primary History - Charles Dickens"
		, "height-px": 485
		, "width-px": 720
		, "min-flash-ver": "8.0.0"
		, "theflashvars": {xmlconfig: "xml/famous_people/charles_dickens.xml"}
	},
	
	
// to add a new game, copy the entry below, paste *above* this line, then edit each value as required.
	"id-to-use-in-link-to-game": {
		  "src": "/url/to/game.swf"
		, "title": "Title of game to be displayed"
		, "height-px": 688	/* height of game in pixels */
		, "width-px": 823
		, "min-flash-ver": "8.0.0" /* minimum Flash version required by this game */
	},
	
	"dummy": {} // dummy so each game item can end in ","
};

// end of script