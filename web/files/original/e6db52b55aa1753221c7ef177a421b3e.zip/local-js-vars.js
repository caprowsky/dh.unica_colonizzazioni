
/* 
################################################################## 
## 
##   THIS IS A GENERATED FILE. 
## 
##   ANY CHANGES YOU MAKE DIRECTLY TO THIS FILE WILL BE OVERWRITTEN 
##   AND LOST THE NEXT TIME THIS FILE IS GENERATED. 
## 
##  (This file last generated: Nov 14, 2013, 11:21 A.M.) 
## 
################################################################## 
 */

/* ##### BELOW added by: file:/highwire/webapps/holgen/resources/publisher/build/local-js-vars.base.xml ##### */



var gJournalVars = {};



var gJournalVars = {  
  jnlID: 'holgen',
   copy: "United States Holocaust Memorial Museum",
   issn: '8756-6583',
  eissn: '1476-7937',
  oupcode: 'holgen',
  urlPrefix: 'hgs'
};
 





    var manuscript = false;



 



	var CollapsibleTocs = false;






/* ##### END OF ADDED BLOCK ##### */
