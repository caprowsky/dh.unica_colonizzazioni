// Provide a default path to dwr.engine
if (dwr == null) var dwr = {};
if (dwr.engine == null) dwr.engine = {};
if (DWREngine == null) var DWREngine = dwr.engine;
if (ArticleService == null) var ArticleService = {};
ArticleService._path = '/dwr';
ArticleService.getMessage = function(p0, p1, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getMessage', p0, p1, callback);
}
ArticleService.getTextContent = function(p0, p2, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getTextContent', p0, false, p2, callback);
}
ArticleService.getSummary = function(p0, p1, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getSummary', p0, p1, callback);
}
ArticleService.getNodeId = function(p0, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getNodeId', p0, callback);
}
ArticleService.getPeriod = function(p0, p1, p2, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getPeriod', p0, p1, p2, callback);
}
ArticleService.getSummaryIssue = function(p0, p1, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getSummaryIssue', p0, p1, callback);
}
ArticleService.getPageSequence = function(p0, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getPageSequence', p0, callback);
}
ArticleService.getCopyPasteTerms = function(p0, p1, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getCopyPasteTerms', p0, p1, callback);
}
ArticleService.getContextualTagsPool = function(p0, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getContextualTagsPool', p0, callback);
}
ArticleService.markAsRead = function(p0, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'markAsRead', p0, callback);
}
ArticleService.markAsUnRead = function(p0, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'markAsUnRead', p0, callback);
}
ArticleService.isReaded = function(p0, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'isReaded', p0, callback);
}
ArticleService.getTableOfContent = function(p0, p1, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getTableOfContent', p0, p1, callback);
}
ArticleService.getMonoTableOfContent = function(p0, p1, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getMonoTableOfContent', p0, p1, callback);
}
ArticleService.getTableOfContentSearchResults = function(p0, p1, p2, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getTableOfContentSearchResults', p0, p1, p2, callback);
}
ArticleService.getMonoTableOfContentSearchResults = function(p0, p1, p2, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getMonoTableOfContentSearchResults', p0, p1, p2, callback);
}
ArticleService.getNodeDepth = function(p0, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getNodeDepth', p0, callback);
}
ArticleService.hasChildList = function(p0, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'hasChildList', p0, callback);
}
ArticleService.getTocRefUrl = function(p0, p1, p2, p3, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getTocRefUrl', p0, p1, p2, p3, callback);
}
ArticleService.getIllustrations = function(p0, p1, p2, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getIllustrations', p0, p1, p2, callback);
}
ArticleService.getIllustrationsSearchResults = function(p0, p1, p2, p3, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getIllustrationsSearchResults', p0, p1, p2, p3, callback);
}
ArticleService.getRefBib = function(p0, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getRefBib', p0, callback);
}
ArticleService.getRefBib = function(p0, p1, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getRefBib', p0, p1, callback);
}
ArticleService.getRefBib = function(p0, p1, p2, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getRefBib', p0, p1, p2, callback);
}
ArticleService.exportRefBib = function(p0, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'exportRefBib', p0, callback);
}
ArticleService.getXRefs = function(p0, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getXRefs', p0, callback);
}
ArticleService.getXRefsContext = function(p0, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getXRefsContext', p0, callback);
}
ArticleService.buildRefMets = function(p0, p1, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'buildRefMets', p0, p1, callback);
}
ArticleService.listWords = function(p0, p1, p2, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'listWords', p0, p1, p2, callback);
}
ArticleService.getBibliographicReference = function(p0, p1, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getBibliographicReference', p0, p1, callback);
}
ArticleService.getMessage = function(p1, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getMessage', false, p1, callback);
}
ArticleService.getTxTemplate = function(callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getTxTemplate', callback);
}
ArticleService.setTxTemplate = function(p0, callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'setTxTemplate', p0, callback);
}
ArticleService.getUserTransaction = function(callback) {
  dwr.engine._execute(ArticleService._path, 'ArticleService', 'getUserTransaction', callback);
}
