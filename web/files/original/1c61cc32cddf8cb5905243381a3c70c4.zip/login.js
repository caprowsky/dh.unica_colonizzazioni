var loginObj = {
	openLogin:function(){
		var loginDiv = '<div id="login" class="modalStd">' +
			'<strong>LOGIN</strong>' +
			'<a class="fbclose" href="javascript:void(0);">Chiudi</a>' +
			'<div class="login-inner">' +
				'<div class="loginsx">' +
					'<input type="text" value="Nome utente" id="cccLoginUser" name="cccLoginUser" class="modal-txt" onfocus="javascript:if(this.value==\'Nome utente\') this.value=\'\';" />' +
					'<input type="text" value="Password" name="loginPlaceholder" class="modal-txt" onfocus="javascript:jQuery(this).hide();jQuery(\'#loginPwd\').show().focus();" />' +
					'<input type="password" value="" id="loginPwd" name="loginPwd" class="modal-txt" style="display:none"/>' +
					'<div class="buttons">' +
						'<p class="loginErr" id="loginWrong">Nome utente o password errati</p>' +
						'<p class="loginErr" id="loginBroken">Servizio momentaneamente non disponibile</p>' +
						'<a class="btn106red" href="javascript:window.top.loginObj.doLogin();">Invia</a>' +
						'<a class="lostPsw" href="/recupero_password.html">Hai dimenticato la password?</a>' +
					'</div><div class="clean"><!-- --></div>' +
				'</div>' +
				'<div class="logindx">' +
					'<p>Non sei registrato? <a href="/community/registrazione.html" title="">Registrati</a></p>' +
				'</div><div class="clean"><!-- --></div>' +
			'</div><div class="clean"><!-- --></div>' +
		'</div>';
		jQuery.fancybox(loginDiv,{
			'titlePosition': 'inside',
			'transitionIn': 'none',
			'transitionOut': 'none',
			'showCloseButton': false,
			'scrolling': 'no'
		});
		jQuery("#fancybox-content").css("background-color","#ffffff").width("750px");
		jQuery(window.top).resize();
		jQuery("#login").keydown(function(e) {
			var ev = e || event;
			if(ev.keyCode == 13) {
				window.top.loginObj.doLogin();
				return false;
			}
		}); 
	},
	doLogout:function(){
		jQuery.ajax({
			type: "POST",
			url: "/system/modules/it.banzai.treccani.portale/elements/login/logout.jsp",
			dataType: "json",
			timeout: 500,
			complete: function(jqXHR, textStatus){
				if(textStatus == "success") {
					window.top.location.href = loginObj.createReloadUrl("logout");
				} else {
					window.top.loginObj.doLogout();
				}
			}
		});
	},
	doLogin:function(){
		jQuery(".loginErr").hide();
		jQuery.ajax({
			type: "POST",
			url: "/system/modules/it.banzai.treccani.portale/elements/login/login.jsp",
			data: "usr=" + jQuery("#cccLoginUser").val() + "&pwd=" + jQuery("#loginPwd").val(),
			dataType: "json",
			success: function(data){
				if(data && data.success){
					window.top.location.href = loginObj.createReloadUrl("login");
				} else {
					jQuery("#loginWrong").show();
				}
			},
			complete: function(jqXHR, textStatus){
				if(textStatus != "success"){
					jQuery("#loginBroken").show();
				}
			}
		});
	},
	createReloadUrl:function(type){
		var currHref = window.top.location.href
		if(currHref.indexOf("?") > 0){
			currHref = currHref + "&";
		} else {
			currHref = currHref + "?";
		}
		return currHref + "reload=" + type;
	}
};
jQuery(document).ready(function(){
	jQuery.get("/system/modules/it.banzai.treccani.portale/elements/login/user-header-box.jsp", function(data) {
		jQuery("#userHeaderBox").html(data).show();
		window.top.jQuery(document).ready(function() {
			jQuery(document).ready(function() {
			jQuery(".login").click(function(){
				window.top.loginObj.openLogin();
			}).show();
			});
		});
	});
});