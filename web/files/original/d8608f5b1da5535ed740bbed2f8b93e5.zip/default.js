(function ($) {
    var enterKeywords;
    $(document).ready(function () {
        enterKeywords =  document.getElementById('ds-header-text-field').value;
        registerClearDefaultItem('ds-header-text-field',enterKeywords);
        registerClearDefaultItem('aspect_discovery_CommunitySearch_field_query',enterKeywords);


    });

    function registerClearDefaultItem(id, DefaultText) {

        try {
            theInput = document.getElementById(id);
            theInput.value = DefaultText;
            addEvent(theInput, 'focus', clearDefaultText, false);
            addEvent(theInput, 'blur', replaceDefaultText, false);

            /* Save the current value */
            if (theInput.value != '') {

                theInput.defaultText = DefaultText;
            }
        } catch (e) { }
    }

    function clearDefaultText(e) {
        var target = window.event ? window.event.srcElement : e ? e.target : null;
        if (!target) return;

        if (target.value == target.defaultText) {
            target.value = '';
        }
    }

    function replaceDefaultText(e) {
        var target = window.event ? window.event.srcElement : e ? e.target : null;
        if (!target) return;

        if (target.value == '' && target.defaultText) {
            target.value = target.defaultText;
        }
    }

    function addEvent(element, eventType, lamdaFunction, useCapture) {
        try {
            if (element.addEventListener) {
                element.addEventListener(eventType, lamdaFunction, useCapture);
                return true;
            } else if (element.attachEvent) {
                var r = element.attachEvent('on' + eventType, lamdaFunction);
                return r;
            } else {
                return false;
            }
        } catch (e) { }
    }

})(jQuery);
