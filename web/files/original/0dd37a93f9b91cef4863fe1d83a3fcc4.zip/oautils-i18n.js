var SUROA_I18N_SHAREPRIORITYFEATURE_DIALOG_TITLE = "Insert all names like: Surname, Name; ...";
var SUROA_I18N_SUBMIT_SPLITCONTRIBUTORS = "The system has detect the following contributors checking the istitutional people directory. Please review the selection, click on the fix button on the right to manually update the single list entries.";
var dataTableI18N = {
		"sProcessing":   "Processing...",
		"sLengthMenu":   "Show _MENU_ entries",
		"sZeroRecords":  "No matching records found",
		"sInfo":         "Showing _START_ to _END_ of _TOTAL_ entries",
		"sInfoEmpty":    "Showing 0 to 0 of 0 entries",
		"sInfoFiltered": "(filtered from _MAX_ total entries)",
		"sInfoPostFix":  "",
		"sSearch":       "Search:",
		"sUrl":          "",
		"oPaginate": {
			"sFirst":    "First",
			"sPrevious": "Previous",
			"sNext":     "Next",
			"sLast":     "Last"
		}
	};
var SUROA_I18N_MYDSPACE_LOADERROR = "An error occurred while retrieving data from the server. Try to refresh the page; if the problem persists, please contact the admin.";
var SUROA_I18N_MYDSPACE_ACTIONTITLE = "Manage record";
var SUROA_I18N_MYDSPACE_ACTIONRESUME = "Resume submission:";
var SUROA_I18N_MYDSPACE_ACTIONRESUMEBN = "Resume";
var SUROA_I18N_MYDSPACE_ACTIONUPDATE = "Rivedi la registrazione, la registrazione corrente rester&agrave; pubblica fino alla pubblicazione delle modifiche richieste:";
var SUROA_I18N_MYDSPACE_ACTIONUPDATEBN = "Modifica/Integra";
var SUROA_I18N_MYDSPACE_ACTIONVIEW = "View the submission in this step:";
var SUROA_I18N_MYDSPACE_ACTIONVIEWBN = "View";
var SUROA_I18N_MYDSPACE_ACTIONREMOVE = "Remove submission:";
var SUROA_I18N_MYDSPACE_ACTIONREMOVEBN = "Remove";
var SUROA_I18N_MYDSPACE_ACTIONPERFORM = "Perform task:";
var SUROA_I18N_MYDSPACE_ACTIONPERFORMBN = "Perform";
var SUROA_I18N_MYDSPACE_ACTIONTOPOOL = "Return task to pool:";
var SUROA_I18N_MYDSPACE_ACTIONTOPOOLBN = "Abandon task";
var SUROA_I18N_MYDSPACE_ACTIONACCEPT = "Accept task:";
var SUROA_I18N_MYDSPACE_ACTIONACCEPTBN = "Accept";
var SUROA_I18N_MYDSPACE_STATUS_0_50 = "in progress";
var SUROA_I18N_MYDSPACE_STATUS_50_100 = "in progress";
var SUROA_I18N_MYDSPACE_STATUS_100_200 = "to be approved";
var SUROA_I18N_MYDSPACE_STATUS_COMPLETED = "published in the repository";
var SUROA_I18N_MYDSPACE_STATUS_UPDATE = "published in the repository, update request in progress";
var SUROA_I18N_MYDSPACE_STATE_POOL1 = 'Step 1 pool: waiting for approval';
var SUROA_I18N_MYDSPACE_STATE_STEP1 = 'Step 1: to be approved';
var SUROA_I18N_MYDSPACE_STATE_POOL2 = 'Step 2 pool: waiting for approval and metadata review';
var SUROA_I18N_MYDSPACE_STATE_STEP2 = 'Step 2: to be approved, metadata review';
var SUROA_I18N_MYDSPACE_STATE_POOL3 = 'Step 3 pool: pending final metadata review';
var SUROA_I18N_MYDSPACE_STATE_STEP3 = 'Step 3: final metadata review';
var SUROA_I18N_MYDSPACE_STATE_UNKNOWN = 'Unknown';
var SUROA_I18N_SITODOCENTE_ACTIONTITLE = "Gestisci il record:";
var SUROA_I18N_SITODOCENTE_ACTIONUPDATE = "Aggiorna immediatamente sul sito docente:";
var SUROA_I18N_SITODOCENTE_ACTIONUPDATEBN = "Aggiorna ora";
var SUROA_I18N_SITODOCENTE_ACTIONVIEW = "Vedi l'esito di dettaglio dell'invio:";
var SUROA_I18N_SITODOCENTE_ACTIONVIEWBN = "Vedi il dettaglio";
var SUROA_I18N_SITODOCENTE_ACTIONRIVISTA = "Richiedi l'inserimento della rivista:";
var SUROA_I18N_SITODOCENTE_ACTIONRIVISTABN = "Richiedi rivista";
var SUROA_I18N_SITODOCENTE_ACTIONSETTINGS = "Vedi e gestisci le preferenze dei docenti:";
var SUROA_I18N_SITODOCENTE_ACTIONSETTINGSBN = "Preferenze docenti";
var SUROA_I18N_SITODOCENTE_ACTIONREMOVE = "Elimina dal sito docente e non inviare piu' il record:";
var SUROA_I18N_SITODOCENTE_ACTIONREMOVEBN = "Non inviare";
var SUROA_I18N_SITODOCENTE_ACTIONRESTORE = "Ripristina l'invio sul sito docente:";
var SUROA_I18N_SITODOCENTE_ACTIONRESTOREBN = "Ripristina invio";
var SUROA_I18N_SITODOCENTE_ACTIONDELETE= "Elimina il record di invio sul sito docente:";
var SUROA_I18N_SITODOCENTE_ACTIONDELETEBN = "Elimina";
var SUROA_I18N_SITODOCENTE_UPDATE_DIALOG_TITLE = "Invio record su sito docente";
var SUROA_I18N_SITODOCENTE_VIEW_DIALOG_TITLE = "Dettaglio esito invio su sito docente";
var SUROA_I18N_SITODOCENTE_NONINVIARE_DIALOG_TITLE = "Disattivazione invio su sito docente";
var SUROA_I18N_SITODOCENTE_RIPRISTINO_DIALOG_TITLE = "Ripristino invio su sito docente";
var SUROA_I18N_SITODOCENTE_RIVISTA_DIALOG_TITLE = "Richiesta inserimento rivista su catalogo ANCE";
var SUROA_I18N_SITODOCENTE_PREVIEW_DIALOG_TITLE = "Generazione XML richiesta SOAP";
var SUROA_I18N_SITODOCENTE_ACTIONPREVIEW= "Genera l'XML della richiesta SOAP:";
var SUROA_I18N_SITODOCENTE_ACTIONPREVIEWBN = "Anteprima";
var SUROA_I18N_SITODOCENTE_ACTIONUPDATEFULLBN = "Aggiorna i fulltext";
var SUROA_I18N_SITODOCENTE_ACTIONREFRESHFULLBN = "Forza cancellazione e reinvio";
var SUROA_I18N_SITODOCENTE_UPDATEFULL_DIALOG_TITLE = "Invio fulltext su sito docente";
var SUROA_I18N_SITODOCENTE_REFRESHFULL_DIALOG_TITLE = "Cancellazione e reinvio fulltext su sito docente";