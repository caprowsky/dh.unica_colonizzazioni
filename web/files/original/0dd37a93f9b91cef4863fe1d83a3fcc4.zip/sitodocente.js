sitodocenteColumnDefs = myColumnDefs;
SITODOCENTE_CODICE = 4;
SITODOCENTE_STATO = 6;
SITODOCENTE_NONINVIARE = 8;
SITODOCENTE_SYNC = 9;
SITODOCENTE_VQR = 10;
SITODOCENTE_DATAOP = 11;
SITODOCENTE_FULLTEXT = 12;
mydspaceData = new Object();
SITODOCENTE_PUBBLICATO_ORDER = [ MYDSPACE_COL_METADATA, MYDSPACE_COL_METADATA+1, MYDSPACE_COL_METADATA+2, MYDSPACE_COL_SUBLN,
   	                          MYDSPACE_COL_COMNAME, MYDSPACE_COL_COLNAME, MYDSPACE_COL_METADATA+3, MYDSPACE_COL_STATUS,
   	                          MYDSPACE_COL_LMOD,   
   	                          // invisible columns
   	                          MYDSPACE_COL_WID,
   	                          MYDSPACE_COL_PPCOMNAME, MYDSPACE_COL_PPCOMHDL, MYDSPACE_COL_PPCOMID, 
   	                          MYDSPACE_COL_PCOMNAME, MYDSPACE_COL_PCOMHDL, MYDSPACE_COL_PCOMID,
   	                          MYDSPACE_COL_COMHDL, MYDSPACE_COL_COMID,
   	                          MYDSPACE_COL_COLHDL, MYDSPACE_COL_COLID,
   	                          MYDSPACE_COL_SUBEMAIL, MYDSPACE_COL_SUBFN, MYDSPACE_COL_SUBID, MYDSPACE_COL_SUBNETID,
   	                          MYDSPACE_COL_OWEMAIL, MYDSPACE_COL_OWFN, MYDSPACE_COL_OWID, MYDSPACE_COL_OWNETID, MYDSPACE_COL_OWLN,
   	                          MYDSPACE_COL_ITEMID,  
   	                          MYDSPACE_COL_STATE, MYDSPACE_COL_HDL, 
   	                          MYDSPACE_COL_METADATA+4,MYDSPACE_COL_METADATA+5,MYDSPACE_COL_METADATA+6,
   	                          MYDSPACE_COL_METADATA+7,MYDSPACE_COL_METADATA+8,MYDSPACE_COL_METADATA+9,
   	                          MYDSPACE_COL_METADATA+10,//sitodocente
   	                          MYDSPACE_COL_METADATA+11 //actions
                                 ];

   	SITODOCENTE_RIMOSSO_ORDER = [ MYDSPACE_COL_METADATA, MYDSPACE_COL_METADATA+1, MYDSPACE_COL_METADATA+2, MYDSPACE_COL_SUBLN,
   		                          MYDSPACE_COL_COMNAME, MYDSPACE_COL_COLNAME, MYDSPACE_COL_METADATA+3, MYDSPACE_COL_STATUS,
   		                          MYDSPACE_COL_LMOD,   
   		                          // invisible columns
   		                          MYDSPACE_COL_WID,
   		                          MYDSPACE_COL_PPCOMNAME, MYDSPACE_COL_PPCOMHDL, MYDSPACE_COL_PPCOMID, 
   		                          MYDSPACE_COL_PCOMNAME, MYDSPACE_COL_PCOMHDL, MYDSPACE_COL_PCOMID,
   		                          MYDSPACE_COL_COMHDL, MYDSPACE_COL_COMID,
   		                          MYDSPACE_COL_COLHDL, MYDSPACE_COL_COLID,
   		                          MYDSPACE_COL_SUBEMAIL, MYDSPACE_COL_SUBFN, MYDSPACE_COL_SUBID, MYDSPACE_COL_SUBNETID,
   		                          MYDSPACE_COL_OWEMAIL, MYDSPACE_COL_OWFN, MYDSPACE_COL_OWID, MYDSPACE_COL_OWNETID, MYDSPACE_COL_OWLN,
   		                          MYDSPACE_COL_ITEMID,  
   		                          MYDSPACE_COL_STATE, MYDSPACE_COL_HDL, 
   		                          MYDSPACE_COL_METADATA+4,MYDSPACE_COL_METADATA+5,MYDSPACE_COL_METADATA+6,
   		                          MYDSPACE_COL_METADATA+7,MYDSPACE_COL_METADATA+8,MYDSPACE_COL_METADATA+9,
   		                          MYDSPACE_COL_METADATA+10, //sitodocente
   		                          MYDSPACE_COL_METADATA+11 //actions
   	                              ];

//global var uploadFulltextFeature
uploadFulltextFeature = true;
var initPubblicatoSD = false;
var initRimossoSD = false;
var pubblicatoSDObj = null;
var rimossoSDObj = null;

var myExportOption = [
			 			{
			 				"sExtends": "copy",
			 				"mColumns": 'visible'
			 			},
			 			{
			 				"sExtends": "xls",
			 				"mColumns": 'visible'
			 			},
			 			{
			 				"sExtends": "csv",
			 				"mColumns": 'visible'
			 			},
			 			{
			 				"sExtends": "print",
			 				"mColumns": 'visible'
			 			},
			 			{
			 				"sExtends": "pdf",
			 				"sPdfOrientation": 'landscape', 
			 				"mColumns": 'visible'
			 			}
			 		];


fnServerObjectToArray = function (tableid)
{
    return function ( sSource, aoData, fnCallback ) {
        j("#"+tableid+" tbody tr td").hide();
    	j.ajax( {
            "dataType": 'json',
            cache: false,
            "type": "POST",
            "url": sSource,
            "data": aoData,
            "error": function(data){
            	if (!mydspaceData.error)
            	{
            		mydspaceData.error = true;
            		alert(SUROA_I18N_MYDSPACE_LOADERROR);
            	}
            },
            "success": function (json) {
            	if (json == null || json.error)
            	{
            		if (!mydspaceData.error)
                	{
            			mydspaceData.error = true;
            			alert(SUROA_I18N_MYDSPACE_LOADERROR);
                	}		
            		json = new Object();
            		json.aaData = [];
	                fnCallback(json);
            		return;
            	}
            	mydspaceData[tableid] = new Object();
               var a = [];
               
                for ( var i=0, iLen=json.data.length ; i<iLen ; i++ ) {
                    mydspaceData[tableid][''+json.data[i]['id']] = json.data[i];
                    var inner = itemDTOtoFlatArray(json.data[i]);
                    a.push( inner );
                }
                json.aaData = a;
                json.iTotalDisplayRecords = json.totalFiltered;
                json.iTotalRecords = json.total;
                json.sEcho = json.reqCount;
                json.sColumns = MYDSPACE_COL_ALIAS[0].sName;
                for (var i=1, sLen=MYDSPACE_COL_ALIAS.length; i < sLen; i++)
				{					
					json.sColumns += ","+MYDSPACE_COL_ALIAS[i].sName;
				}
                fnCallback(json);
            }
        } );
    }
}

detailsSitoDocente = function(dataTableObj){
	j('tbody tr',dataTableObj).live('mouseenter',function () {
		if (!(j(this).hasClass('odd') || j(this).hasClass('even')))
		{
			return;
		}
		
		var settings = dataTableObj.fnSettings();
		var nTr = this;
		var out = mySitoDocenteFormatDetails( dataTableObj, settings, nTr);
		if (out == null)
			return;
		
		if (settings.currOpenRow != undefined)
		{
			dataTableObj.fnClose(dataTableObj.fnGetNodes(settings.currOpenRow));
			j(dataTableObj.fnGetNodes(settings.currOpenRow)).removeClass("ui-state-highlight");
		}
		settings.currOpenRow = dataTableObj.fnGetPosition(nTr);
		dataTableObj.fnOpen( nTr, out, 'actions' );
		j('tbody tr td.actions input:submit',dataTableObj).button();
		j('tbody tr td.actions button',dataTableObj).button();
		j('tbody tr td.actions a[href=#]',dataTableObj).click(
				function(){
				dataTableObj.fnClose(dataTableObj.fnGetNodes(settings.currOpenRow));
				j(dataTableObj.fnGetNodes(settings.currOpenRow)).removeClass("ui-state-highlight");
				return false;}
		);
		j(dataTableObj).mouseleave(function(){
			dataTableObj.fnClose(dataTableObj.fnGetNodes(settings.currOpenRow));
			j(dataTableObj.fnGetNodes(settings.currOpenRow)).removeClass("ui-state-highlight");
			return false;}
		);
		
		var aData = dataTableObj.fnGetData( nTr );	
		var itemid = ''+aData[fnGetColumnIndexBysName(settings, "MYDSPACE_COL_ITEMID")];
		var idtable = dataTableObj[0].id;
		var handle = mydspaceData[idtable][itemid].handle;
		j('#actionupdate').click(function(){actionupdate(handle, dataTableObj);});
		j('#actionupdatefull').click(function(){actionupdatefull(handle, dataTableObj);});
		j('#actionrefreshfull').click(function(){actionrefreshfull(handle, dataTableObj);});
		j('#actionremove').click(function(){actionnoninviare(handle, dataTableObj);});
		//j('#actiondelete').click(function(){alert('delete');});
		j('#actionrivista').click(function(){actionrivista(handle, dataTableObj);});
		j('#actionview').click(function(){actiondetail(handle, dataTableObj);});
		j('#actionpreview').click(function(){actionpreview(handle, dataTableObj);});
		//j('#actionsettings').click(function(){alert('preferenze');});
		j('#actionrestore').click(function(){actionrestore(handle, dataTableObj);});
		j(nTr).addClass("ui-state-highlight");
	
	});
}

actionrivista = function(handle, dataTableObj){
	j("#rivistabox").dialog({modal: true, width: 800, 
		title: SUROA_I18N_SITODOCENTE_RIVISTA_DIALOG_TITLE, close: function(event, ui){j("#rivistabox").html(text);}});			
	var text = j("#rivistabox").html();
	var precompilazione = null;
	j.ajax({url: "json/sitodocente/richiedirivista", 
		dataType: "json", 
		cache: false,
		contentType: "application/x-www-form-urlencoded;charset=UTF-8", 
		data: ({handle: handle}), 
		success: function(esito) {
				precompilazione = esito;
				j("#titoloPrincipale").val(precompilazione.titoloPrincipale);
				j("#issn").val(precompilazione.issn);
				j("#note").html(precompilazione.note);
				j("#emailRisposta").val(precompilazione.emailRisposta);
				j("#publisherName").val(precompilazione.publisherName);
				j("#publisherCountry").val(precompilazione.publisherCountry);
				j("#richiedirivistaresetbn").button();
				j("#richiedirivistabn").button();
				j("#richiedirivistabn").click(
						function(){
							j.ajax({url: "json/sitodocente/richiedirivista", 
								dataType: "json",
								data: ({issn: j("#issn").val(), titoloPrincipale: j("#titoloPrincipale").val(), note: j("#note").val(), 
									emailRisposta:j("#emailRisposta").val(), publisherName:j("#publisherName").val(),publisherCountry:j("#publisherCountry").val()}),
								contentType: "application/x-www-form-urlencoded;charset=UTF-8", 
								success: function(esito) {
										j("#rivistabox").html(
										'<b>Esito:</b> '+esito.esito.stato.value+'<br/>'+
										'<b>Codice:</b> '+esito.esito.codice+'<br/>'+
										'<b>Messaggio:</b> '+esito.esito.messaggio+'<br/>'+
										(esito.invioEMail?(!esito.fallimentoInvioEmail?'<b>Riceverai via email copia della richiesta</b>':'<b>L\'invio della richiesta in copia via email e\' fallito'):'')
										);
								},
								error: function(jqXHR, textStatus, errorThrown)
								{
									j("#rivistabox").html(
											'Si e\' verificato un errore durante l\'elaborazione della richiesta, non sono disponibili ulteriori dettagli. <br/>Aggiornare la pagina principale per verificare che si sia ancora correttamente loggati sul sistema. Se il problema persiste si prega di contattare il supporto tecnico.'
											);
									dataTableObj.fnDraw();
								}
							});
						}
				);
				j("#richiedirivistaresetbn").click(function(){
					j("#titoloPrincipale").val(precompilazione.titoloPrincipale);
					j("#issn").val(precompilazione.issn);
					j("#note").html(precompilazione.note);
					j("#emailRisposta").val(precompilazione.emailRisposta);
					j("#publisherName").val(precompilazione.publisherName);
					j("#publisherCountry").val(precompilazione.publisherCountry);
				});
				j("#rivistabox p").hide();
				j("#rivistabox img").hide();
				j("#richiedirivistaform").show();
		},
		error: function(jqXHR, textStatus, errorThrown)
		{
			j("#rivistabox").html(
					'Si e\' verificato un errore durante la precompilazione del form. <br/>Aggiornare la pagina principale per verificare che si sia ancora correttamente loggati sul sistema. Se il problema persiste si prega di contattare il supporto tecnico.'
					);
		}
	});
	};
actionupdate = function(handle, dataTableObj){
	j("#updatebox").dialog({modal: true, width: 800, 
		title: SUROA_I18N_SITODOCENTE_UPDATE_DIALOG_TITLE, close: function(event, ui){j("#updatebox").html(text);}});			
	var text = j("#updatebox").html(); 
	j.ajax({url: "json/sitodocente/aggiorna", 
		dataType: "json",
		cache: false,
		contentType: "application/x-www-form-urlencoded;charset=UTF-8", 
		data: ({handle: handle}), 
		success: function(esito) {
				var dett = esito.dettagli;
				if (dett == null) dett = 'Nessun dettaglio fornito in risposta';
				j("#updatebox").html(
				'<b>Esito:</b> '+esito.stato.value+'<br/>'+
				'<b>Codice:</b> '+esito.codice+'<br/>'+
				'<b>Messaggio:</b> '+esito.messaggio+'<br/>'+
				'<b>Dettaglio:</b>'+'<pre class="prettyprint"><code class="language-xml">'+
				dett+'</code></pre>'
				);
				prettyPrint();
				dataTableObj.fnDraw();						
		},
		error: function(jqXHR, textStatus, errorThrown)
		{
			j("#updatebox").html(
					'Si e\' verificato un errore durante l\'elaborazione della richiesta, non sono disponibili ulteriori dettagli. <br/>Aggiornare la pagina principale per verificare che si sia ancora correttamente loggati sul sistema. Se il problema persiste si prega di contattare il supporto tecnico.'
					);
			dataTableObj.fnDraw();
		}
	});
	};
	actionupdatefull = function(handle, dataTableObj){
		j("#dettagliobox").dialog({modal: true, width: 800, 
			title: SUROA_I18N_SITODOCENTE_UPDATEFULL_DIALOG_TITLE, close: function(event, ui){j("#dettagliobox").html(text);}});			
		var text = j("#dettagliobox").html(); 
		j.ajax({url: "json/sitodocente/fulltext/update", 
			dataType: "json",
			cache: false,
			"type": "POST",
			contentType: "application/x-www-form-urlencoded;charset=UTF-8", 
			data: ({handle: handle}), 
			success: function(esito) {
					printDetail(esito);
					dataTableObj.fnDraw();						
			},
			error: function(jqXHR, textStatus, errorThrown)
			{
				j("#dettagliobox").html(
						'Si e\' verificato un errore durante l\'elaborazione della richiesta, non sono disponibili ulteriori dettagli. <br/>Aggiornare la pagina principale per verificare che si sia ancora correttamente loggati sul sistema. Se il problema persiste si prega di contattare il supporto tecnico.'
						);
				dataTableObj.fnDraw();
			}
		});
		};
		actionrefreshfull = function(handle, dataTableObj){
			j("#dettagliobox").dialog({modal: true, width: 800, 
				title: SUROA_I18N_SITODOCENTE_REFRESHFULL_DIALOG_TITLE, close: function(event, ui){j("#dettagliobox").html(text);}});			
			var text = j("#dettagliobox").html(); 
			j.ajax({url: "json/sitodocente/fulltext/refresh", 
				dataType: "json", 
				cache: false,
				"type": "POST",
				contentType: "application/x-www-form-urlencoded;charset=UTF-8", 
				data: ({handle: handle}), 
				success: function(esito) {
						printDetail(esito);
						dataTableObj.fnDraw();						
				},
				error: function(jqXHR, textStatus, errorThrown)
				{
					j("#dettagliobox").html(
							'Si e\' verificato un errore durante l\'elaborazione della richiesta, non sono disponibili ulteriori dettagli. <br/>Aggiornare la pagina principale per verificare che si sia ancora correttamente loggati sul sistema. Se il problema persiste si prega di contattare il supporto tecnico.'
							);
					dataTableObj.fnDraw();
				}
			});
			};
actionpreview = function(handle, dataTableObj){
		j("#updatebox").dialog({modal: true, width: 800, 
			title: SUROA_I18N_SITODOCENTE_PREVIEW_DIALOG_TITLE, close: function(event, ui){j("#updatebox").html(text);}});			
		var text = j("#updatebox").html(); 
		j.ajax({url: "json/sitodocente/preview", 
			dataType: "json", 
			cache: false,
			contentType: "application/x-www-form-urlencoded;charset=UTF-8", 
			data: ({handle: handle}), 
			success: function(esito) {
					j("#updatebox").html(
					'<pre class="prettyprint"><code class="language-xml">'+
					esito+
					'</code></pre>'
					);
					prettyPrint();
			},
			error: function(jqXHR, textStatus, errorThrown)
			{
				j("#updatebox").html(
						'Si e\' verificato un errore durante l\'elaborazione della richiesta, non sono disponibili ulteriori dettagli. <br/>Aggiornare la pagina principale per verificare che si sia ancora correttamente loggati sul sistema. Se il problema persiste si prega di contattare il supporto tecnico.'
						);
			}
		});
		};

actionnoninviare= function(handle, dataTableObj){
		j("#invioadminbox").dialog({modal: true, width: 800, 
			title: SUROA_I18N_SITODOCENTE_NONINVIARE_DIALOG_TITLE, close: function(event, ui){j("#invioadminbox").html(text);}});			
		var text = j("#invioadminbox").html(); 
		j.ajax({url: "json/sitodocente/noninviare", 
			dataType: "json", 
			cache: false,
			contentType: "application/x-www-form-urlencoded;charset=UTF-8", 
			data: ({handle: handle}), 
			success: function(esito) {
					j("#invioadminbox").html(
					'<b>Esito:</b> '+esito.stato.value+'<br/>'+
					'<b>Codice:</b> '+esito.codice+'<br/>'+
					'<b>Messaggio:</b> '+esito.messaggio+'<br/>'+
					'<b>La pubblicazione e\' stata esclusa da futuri aggiornamenti sul sito docente. In caso di disattivazione accidentale utilizzare la funzionalita\' di ripristino dell\'invio.</b>'
					);
					dataTableObj.fnDraw();						
			},
			error: function(jqXHR, textStatus, errorThrown)
			{
				j("#invioadminbox").html(
						'Si e\' verificato un errore durante l\'elaborazione della richiesta, non sono disponibili ulteriori dettagli. <br/>Aggiornare la pagina principale per verificare che si sia ancora correttamente loggati sul sistema. Se il problema persiste si prega di contattare il supporto tecnico.'
						);
				dataTableObj.fnDraw();
			}
		});
		};

actionrestore= function(handle, dataTableObj){
			j("#invioadminbox").dialog({modal: true, width: 800, 
				title: SUROA_I18N_SITODOCENTE_RIPRISTINO_DIALOG_TITLE, close: function(event, ui){j("#invioadminbox").html(text);}});			
			var text = j("#invioadminbox").html(); 
			j.ajax({url: "json/sitodocente/ripristina", 
				dataType: "json", 
				cache: false,
				contentType: "application/x-www-form-urlencoded;charset=UTF-8", 
				data: ({handle: handle}), 
				success: function(esito) {
						j("#invioadminbox").html(
						'<b>Esito:</b> '+esito.stato.value+'<br/>'+
						'<b>Codice:</b> '+esito.codice+'<br/>'+
						'<b>Messaggio:</b> '+esito.messaggio+'<br/>'+
						'<b>L\'aggiornamento sul sito docente delle modifiche effettuate alla pubblicazione e\' stato ripristinato.</b>'
						);
						dataTableObj.fnDraw();						
				},
				error: function(jqXHR, textStatus, errorThrown)
				{
					j("#invioadminbox").html(
							'Si e\' verificato un errore durante l\'elaborazione della richiesta, non sono disponibili ulteriori dettagli. <br/>Aggiornare la pagina principale per verificare che si sia ancora correttamente loggati sul sistema. Se il problema persiste si prega di contattare il supporto tecnico.'
							);
					dataTableObj.fnDraw();
				}
			});
			};
	
actiondetail = function(handle, dataTableObj){
	j("#dettagliobox").dialog({modal: true, width: 800, 
		title: SUROA_I18N_SITODOCENTE_VIEW_DIALOG_TITLE, close: function(event, ui){j("#dettagliobox").html(text);}});			
	var text = j("#dettagliobox").html(); 
	j.ajax({url: "json/sitodocente/dettaglio", 
		dataType: "json", 
		cache: false,
		contentType: "application/x-www-form-urlencoded;charset=UTF-8", 
		data: ({handle: handle}), 
		success: function(esito) {
			printDetail(esito);
		},
		error: function(jqXHR, textStatus, errorThrown)
		{
			j("#dettagliobox").html(
					'Si e\' verificato un errore durante l\'elaborazione della richiesta, non sono disponibili ulteriori dettagli. <br/>Aggiornare la pagina principale per verificare che si sia ancora correttamente loggati sul sistema. Se il problema persiste si prega di contattare il supporto tecnico.'
					);
		}
	});
	
	};

printDetail = function (esito){
		var currentTime = new Date(parseInt(esito.data));
		if (currentTime != null && esito.data != null)
		{
			var month = currentTime.getMonth() + 1;
			var day = currentTime.getDate();
			var year = currentTime.getFullYear();		
			var hr = currentTime.getHours();
			var min = currentTime.getMinutes(); 
			currentTime = (day + "/" + month + "/" + year + " "+(hr<10?"0"+hr:hr)+":"+(min<10?"0"+min:min));
		}
		else
			currentTime = 'N/A';

		var lastTime = new Date(parseInt(esito.lastRicezione));
		if (lastTime != null && esito.lastRicezione != null)
		{
			var month = lastTime.getMonth() + 1;
			var day = lastTime.getDate();
			var year = lastTime.getFullYear();		
			var hr = lastTime.getHours();
			var min = lastTime.getMinutes(); 
			lastTime = (day + "/" + month + "/" + year + " "+(hr<10?"0"+hr:hr)+":"+(min<10?"0"+min:min));
		}
		else
		{
			lastTime = 'N/A';
		}
		var dett = esito.dettaglio;
		if (dett == null) dett = 'Nessun dettaglio fornito in risposta';
		var ldett = esito.lastRicezioneDettaglio;
		if (ldett == null) ldett = 'Nessun dettaglio fornito in risposta';
		var htmlout =
		'<b>Stato ultimo invio ['+currentTime+']:</b> '+esito.stato+'<br/>'+
		'<b>Codice:</b> '+esito.codice+'<br/>'+
		'<b>Messaggio:</b> '+esito.messaggio+'<br/><br/>'+
		'<b>Docenti a cui e\' stata assegnata la pubblicazione:</b> '+esito.docenti+'<br/><br/>';
		
		if (uploadFulltextFeature && esito.statoFulltext != '' && esito.statoFulltext != null)
		{
			
			htmlout += '<b>Stato invio fulltext:</b> ';
			if (esito.statoFulltext == '1OK')
			{
				htmlout += 'Fulltext inviato(i) con successo';
			}
			else if (esito.statoFulltext == '2TOUPDATE')
			{
				htmlout += 'Fulltext da inviare/aggiornare';
			}
			else if (esito.statoFulltext == '3NONE')
			{
				htmlout += 'Nessun Fulltext presente/selezionato per l\'invio';	
			}
			else if (esito.statoFulltext == '4ERROR')
			{
				htmlout += 'Errore durante l\'ultima operazione di invio';
			}
			htmlout += '<br/><br/>';
			htmlout += '<div class="accordation"><h3><a href="#">Log ultime 10 operazioni sui fulltext:</a></h3><div>';
			if (esito.msgFulltext != null && esito.msgFulltext.size() > 0)
			{
				for (ih = 0; ih < esito.msgFulltext.size();ih++)
				{
					var histTime = new Date(parseInt(esito.msgFulltext[ih][0]));
					if (histTime != null)
					{
						var month = histTime.getMonth() + 1;
						var day = histTime.getDate();
						var year = histTime.getFullYear();		
						var hr = histTime.getHours();
						var min = histTime.getMinutes(); 
						histTime = (day + "/" + month + "/" + year + " "+(hr<10?"0"+hr:hr)+":"+(min<10?"0"+min:min));
					}
					else
					{
						histTime = 'N/A';
					}
					htmlout += '<p><b>['+histTime+']</b><br/> '+esito.msgFulltext[ih][1].replace(/\n/g,'<br/>')+'</p>';
				}
			}
			else
			{
				htmlout += 'Nessun dato disponibile';
				
			}
			htmlout += '</div>';
		}
		else
		{
			htmlout += '<div class="accordation">';	
		}
		htmlout += '<h3><a href="#">Dettaglio risposta Sito Docente:</a></h3><div><pre class="prettyprint"><code class="language-xml">'+dett+'</code></pre></div></div>';
		if (esito.stato == 'SUCCESSO' || esito.stato == 'AVVERTIMENTO' || esito.stato == 'CANCELLATO')
		{}
		else{
			htmlout += 
		'<br/><br/><b>Ultima modifica accetta su sito docente ['+esito.lastStato+': '+esito.lastCodice+']:</b> '+lastTime+'<br/>'+
		'<b>Ultimo messaggio in accettazione su sito docente:</b> '+esito.lastMessaggio+'<br/><br/>'+
		'<b>Docenti a cui e\' stata assegnata la pubblicazione:</b> '+esito.docenti+'<br/><br/>'+
		'<div class="accordation"><h3><a href="#">Dettaglio ultima modifica accettata su Sito Docente:</a></h3><div><pre class="prettyprint"><code class="language-xml">'+ldett+'</code></pre></div></div>';
		}
		j("#dettagliobox").html(htmlout);
		j(".accordation").accordion({ collapsible: true , active: false});
		prettyPrint();
};	
actionremove = function(){
		
	};
		
mySitoDocenteFormatDetails = function ( dataTableObj, settings, nTr)
{
	var aData = dataTableObj.fnGetData( nTr );
	var idtable = dataTableObj[0].id;
	var sOut = '<div style="position: relative; width: 100%;" class="ui-dialog ui-widget-content ui-dialog">';
	sOut += '<div class="ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix">';
	sOut += '<span class="ui-dialog-title" id="ui-dialog-title-dialog">'+SUROA_I18N_SITODOCENTE_ACTIONTITLE+'</span><a class="ui-dialog-titlebar-close ui-corner-all" href="#" role="button">';
	sOut += '<span class="ui-icon ui-icon-closethick">close</span></a></div>';
	var itemid = ''+aData[fnGetColumnIndexBysName(settings, "MYDSPACE_COL_ITEMID")];
	var codice = mydspaceData[idtable][itemid].metadataColumns[SITODOCENTE_CODICE] ;
	var noninviare = mydspaceData[idtable][itemid].metadataColumns[SITODOCENTE_NONINVIARE];
	if (idtable == 'pubblicatositodocente')
	{				
		sOut += '<div class="ui-dialog-content ui-widget-content"><table><tr><td>'+SUROA_I18N_SITODOCENTE_ACTIONUPDATE+'</td><td align="left">';
		sOut += '    <button id="actionupdate" name="actionupdate">'+SUROA_I18N_SITODOCENTE_ACTIONUPDATEBN+'</button>';
		if (uploadFulltextFeature && codice != '' && codice != null && mydspaceData[idtable][itemid].metadataColumns[SITODOCENTE_FULLTEXT] != '')
		{
			sOut += '    <button id="actionupdatefull" name="actionupdatefull">'+SUROA_I18N_SITODOCENTE_ACTIONUPDATEFULLBN+'</button>';
			sOut += '    <button id="actionrefreshfull" name="actionrefreshfull">'+SUROA_I18N_SITODOCENTE_ACTIONREFRESHFULLBN+'</button>';
		}
		sOut += '</td></tr>';

		sOut += '<tr><td>'+SUROA_I18N_SITODOCENTE_ACTIONPREVIEW+'</td><td align="left">';
		sOut += '    <button id="actionpreview" name="actionpreview">'+SUROA_I18N_SITODOCENTE_ACTIONPREVIEWBN+'</button>';
		sOut += '</td></tr>';
		
		if (codice == '20504')
		{
			sOut += '<tr><td>'+SUROA_I18N_SITODOCENTE_ACTIONRIVISTA+'</td><td align="left">';
			sOut += '    <button id="actionrivista" name="actionrivista">'+SUROA_I18N_SITODOCENTE_ACTIONRIVISTABN+'</button>';
			sOut += '</td></tr>';
		}
		if (codice != '' && codice != null)
		{
			sOut += '<tr><td>'+SUROA_I18N_SITODOCENTE_ACTIONVIEW+'</td><td align="left">';
			sOut += '    <button id="actionview" name="actionview">'+SUROA_I18N_SITODOCENTE_ACTIONVIEWBN+'</button>';
			sOut += '</td></tr>';
		}
		
//		sOut += '<tr><td>'+SUROA_I18N_SITODOCENTE_ACTIONSETTINGS+'</td><td align="left">';
//		sOut += '    <button id="actionsettings" name="actionsettings">'+SUROA_I18N_SITODOCENTE_ACTIONSETTINGSBN+'</button>';
//		sOut += '</td></tr>';
		
		if (noninviare)
		{
			sOut += '<tr><td>'+SUROA_I18N_SITODOCENTE_ACTIONRESTORE+'</td><td align="left">';
			sOut += '    <button id="actionrestore" name="actionrestore">'+SUROA_I18N_SITODOCENTE_ACTIONRESTOREBN+'</button>';
			sOut += '</td></tr>';	
		}
		else
		{
			sOut += '<tr><td>'+SUROA_I18N_SITODOCENTE_ACTIONREMOVE+'</td><td align="left">';
			sOut += '    <button id="actionremove" name="actionremove">'+SUROA_I18N_SITODOCENTE_ACTIONREMOVEBN+'</button>';
			sOut += '</td></tr>';	
		}
		sOut += '</table>';
	}
	else
	{
		sOut += '<div class="ui-dialog-content ui-widget-content"><table>';
		sOut += '<tr><td>'+SUROA_I18N_SITODOCENTE_ACTIONUPDATE+'</td><td align="left">';
		sOut += '    <button id="actionupdate" name="actionupdate">'+SUROA_I18N_SITODOCENTE_ACTIONUPDATEBN+'</button>';
		sOut += '</td></tr>';
		sOut += '<div class="ui-dialog-content ui-widget-content"><tr><td>'+SUROA_I18N_SITODOCENTE_ACTIONPREVIEW+'</td><td align="left">';
		sOut += '    <button id="actionpreview" name="actionpreview">'+SUROA_I18N_SITODOCENTE_ACTIONPREVIEWBN+'</button>';
		sOut += '</td></tr>';
//		sOut += '<tr><td>'+SUROA_I18N_SITODOCENTE_ACTIONDELETE+'</td><td align="left">';
//		sOut += '    <button id="actiondelete" name="actiondelete">'+SUROA_I18N_SITODOCENTE_ACTIONDELETEBN+'</button>';
//		sOut += '</td></tr>';
		sOut += '</table>';
	}
	
	if(aData[fnGetColumnIndexBysName(settings, "MYDSPACE_COL_HDL")] != null)
		sOut += '<div class="ui-dialog-content ui-widget-content"><table><tr><td>Handle: <b>'+aData[fnGetColumnIndexBysName(settings, "MYDSPACE_COL_HDL")]+'</b></td></tr></table></div>';
		
	if(aData[fnGetColumnIndexBysName(settings, "MYDSPACE_COL_METADATA12")] != null)
		sOut += '<div class="ui-dialog-content ui-widget-content"><table><tr><td>Citazione: <b>'+aData[fnGetColumnIndexBysName(settings, "MYDSPACE_COL_METADATA12")]+'</b></td></tr></table></div>';
	
	sOut += '</div></div>';
	return sOut;
}

enableSitoDocenteTabs = function()
{
	j("#tabs ul li").toggleClass("loading");
	if (rimossoSDObj.fnSettings().fnRecordsTotal() == 0)
	{
		j("#tabs ul li").has('a[href="#tabs-2"]').addClass("loading");
	}
	j("#tabs ul li").not(".loading").first().children().click();
}

fnDraCallback = function(){}
pubblicatoSDSort = [ MYDSPACE_COL_METADATA+SITODOCENTE_DATAOP, "desc" ];
rimossoSDSort = [ MYDSPACE_COL_METADATA+SITODOCENTE_DATAOP, "desc" ];

initializeSitoDocente = function(){
	j(document).ready(function() {
		j("#tabs").tabs( {
			"show": function(event, ui) {
				var dtable = j('table.display', ui.panel);
				for (idx = 0; idx < dtable.length; idx++)
				{
					var tt = TableTools.fnGetInstance(dtable[idx]); 
					if (tt.fnResizeRequired() )
					{
						tt.fnResizeButtons();
					}
				}
				j("input:submit").button();
				j("input:button").button();
			}
		});
		pubblicatoSDObj = j('#pubblicatositodocente').dataTable( {
			"aaSorting": [pubblicatoSDSort],
			"fnDrawCallback": function() {fnDraCallback();},
			"oLanguage": dataTableI18N,
			"sDom": 'R<"H"<T><"clear">lfr>t<"F"<"clear">ip>',
			"oTableTools": {
				"sSwfPath": dspaceContextPath+"/swf/copy_cvs_xls_pdf.swf",
				"aButtons": myExportOption
			},
			"fnInitComplete": function () {
				initPubblicatoSD = true;
				if (initRimossoSD)
				{
					enableSitoDocenteTabs();
				}
			},
			"bAutoWidth" : false,
			"bJQueryUI": true,
			"aLengthMenu": [[5, 10, 25, 50, 100, 5000], [5, 10, 25, 50, 100, 5000]],
			"oColReorder": {
				"aiOrder": SITODOCENTE_PUBBLICATO_ORDER
			},
			"bProcessing": true,
			"sPaginationType": "full_numbers",
			"bServerSide": true,
			"sAjaxSource": dspaceContextPath+"/json/sitodocente/pubblicato",
			"fnServerData": fnServerObjectToArray("pubblicatositodocente"),
			"aoColumns": MYDSPACE_COL_ALIAS.concat([{"sName":"actions"}]),
			"aoColumnDefs": pubblicatoSDColumnDefs
		} ).fnFilterOnReturn();
	
		rimossoSDObj = j('#rimossositodocente').dataTable( {
			"aaSorting": [rimossoSDSort], 
			"oLanguage": dataTableI18N,
			"sDom": 'R<"H"<T><"clear">lfr>t<"F"<"clear">ip>',
			"oTableTools": {
				"sSwfPath": dspaceContextPath+"/swf/copy_cvs_xls_pdf.swf",
				"aButtons": myExportOption},
			"fnInitComplete": function () {
				initRimossoSD = true;
				if (initPubblicatoSD)
				{
					enableSitoDocenteTabs();
				}
			},
			"bAutoWidth" : false,
			"bJQueryUI": true,
			"aLengthMenu": [[5, 10, 25, 50, 100, 200], [5, 10, 25, 50, 100, 200]],
			"oColReorder": {
				"aiOrder": SITODOCENTE_RIMOSSO_ORDER
			},
			"bProcessing": true,
			"sPaginationType": "full_numbers",
			"bServerSide": true,
			"sAjaxSource": dspaceContextPath+"/json/sitodocente/rimosso",
			"fnServerData": fnServerObjectToArray("rimossositodocente"),
			"aoColumns": MYDSPACE_COL_ALIAS.concat([{"sName":"actions"}]),
			"aoColumnDefs": rimossoSDColumnDefs
		} ).fnFilterOnReturn();
		
		detailsSitoDocente(pubblicatoSDObj);
		detailsSitoDocente(rimossoSDObj);
		j('#solovqrcheckbox').change(function(){
			var val = '';
			if (j('#solovqrcheckbox').is(':checked'))
			{
				val = j('#solovqrcheckbox').val();
			}
			pubblicatoSDObj.fnFilter(val,MYDSPACE_COL_METADATA+SITODOCENTE_VQR);
		});
		j('#synccheckbox').change(function(){
			var val = '';
			if (j('#synccheckbox').is(':checked'))
			{
				val = j('#synccheckbox').val();
			}
			pubblicatoSDObj.fnFilter(val,MYDSPACE_COL_METADATA+SITODOCENTE_SYNC);
		});
		j('#noninviarecheckbox').change(function(){
			var val = '';
			if (j('#noninviarecheckbox').is(':checked'))
			{
				val = j('#noninviarecheckbox').val();
			}
			pubblicatoSDObj.fnFilter(val,MYDSPACE_COL_METADATA+SITODOCENTE_NONINVIARE);
		});
		j('#statoselect').change(function(){
			pubblicatoSDObj.fnFilter(j('#statoselect').val(),MYDSPACE_COL_METADATA+SITODOCENTE_STATO);
		});
		j('#codiceselect').change(function(){
			pubblicatoSDObj.fnFilter(j('#codiceselect').val(),MYDSPACE_COL_METADATA+SITODOCENTE_CODICE);
		});
		j('#fullselect').change(function(){
			pubblicatoSDObj.fnFilter(j('#fullselect').val(),MYDSPACE_COL_METADATA+SITODOCENTE_FULLTEXT);
		});
		
		j('#wsolovqrcheckbox').change(function(){
			var val = '';
			if (j('#wsolovqrcheckbox').is(':checked'))
			{
				val = j('#wsolovqrcheckbox').val();
			}
			rimossoSDObj.fnFilter(val,MYDSPACE_COL_METADATA+SITODOCENTE_VQR);
		});
		j('#wsynccheckbox').change(function(){
			var val = '';
			if (j('#wsynccheckbox').is(':checked'))
			{
				val = j('#wsynccheckbox').val();
			}
			rimossoSDObj.fnFilter(val,MYDSPACE_COL_METADATA+SITODOCENTE_SYNC);
		});
		j('#wnoninviarecheckbox').change(function(){
			var val = '';
			if (j('#wnoninviarecheckbox').is(':checked'))
			{
				val = j('#wnoninviarecheckbox').val();
			}
			rimossoSDObj.fnFilter(val,MYDSPACE_COL_METADATA+SITODOCENTE_NONINVIARE);
		});
		j('#wstatoselect').change(function(){
			rimossoSDObj.fnFilter(j('#wstatoselect').val(),MYDSPACE_COL_METADATA+SITODOCENTE_STATO);
		});
		j('#wcodiceselect').change(function(){
			rimossoSDObj.fnFilter(j('#wcodiceselect').val(),MYDSPACE_COL_METADATA+SITODOCENTE_CODICE);
		});
		j('#wfullselect').change(function(){
			rimossoSDObj.fnFilter(j('#wfullselect').val(),MYDSPACE_COL_METADATA+SITODOCENTE_FULLTEXT);
		});		
	} );
}