var SUROA_I18N_SHAREPRIORITYFEATURE_DIALOG_TITLE = "Inserisci tutti i nominativi da individuare: Cognome, Nome; ...";
var SUROA_I18N_SUBMIT_SPLITCONTRIBUTORS = "Il sistema ha aggiornato la lista dei singoli autori. Laddove l'anagrafica di ateneo prevede una o pi&ugrave; corrispondenze il sistema presenta una tendina di scelta.<br/>Utilizzare il pulsante \"Modifica\" per correggere i singoli nominativi.";
var dataTableI18N = {
		"sProcessing":   "Caricamento...",
		"sLengthMenu":   "Visualizza _MENU_ elementi",
		"sZeroRecords":  "La ricerca non ha portato alcun risultato.",
		"sInfo":         "Vista da _START_ a _END_ di _TOTAL_ elementi",
		"sInfoEmpty":    "Vista da 0 a 0 di 0 elementi",
		"sInfoFiltered": "(filtrati da _MAX_ elementi totali)",
		"sInfoPostFix":  "",
		"sSearch":       "Cerca:",
		"sUrl":          "",
		"oPaginate": {
			"sFirst":    "Inizio",
			"sPrevious": "Precedente",
			"sNext":     "Successivo",
			"sLast":     "Fine"
		}
	};
var SUROA_I18N_MYDSPACE_LOADERROR = "Si e' verificato un errore nel recupero dei dati dal server. Prova a ricaricare la pagina se il problema persiste contatta l'ammistratore";
var SUROA_I18N_MYDSPACE_ACTIONTITLE = "Gestisci il record";
var SUROA_I18N_MYDSPACE_ACTIONRESUME = "Completa la registrazione:";
var SUROA_I18N_MYDSPACE_ACTIONRESUMEBN = "Completa";
var SUROA_I18N_MYDSPACE_ACTIONUPDATE = "Rivedi la registrazione, la registrazione corrente rester&agrave; pubblica fino alla pubblicazione delle modifiche richieste:";
var SUROA_I18N_MYDSPACE_ACTIONUPDATEBN = "Modifica/Integra";
var SUROA_I18N_MYDSPACE_ACTIONVIEW = "Visualizza la registrazione cos&igrave; com&egrave; in questa fase dell'inserimento:";
var SUROA_I18N_MYDSPACE_ACTIONVIEWBN = "Visualizza";
var SUROA_I18N_MYDSPACE_ACTIONREMOVE = "Elimina la registrazione:";
var SUROA_I18N_MYDSPACE_ACTIONREMOVEBN = "Elimina";
var SUROA_I18N_MYDSPACE_ACTIONPERFORM = "Esegui l'incarico:";
var SUROA_I18N_MYDSPACE_ACTIONPERFORMBN = "Esegui";
var SUROA_I18N_MYDSPACE_ACTIONTOPOOL = "Riponi l'incarico nella lista dei compiti in attesa. Altri operatori potranno accettare l'incarico:";
var SUROA_I18N_MYDSPACE_ACTIONTOPOOLBN = "Rinuncia all'incarico";
var SUROA_I18N_MYDSPACE_ACTIONACCEPT = "Accetta l'incarico:";
var SUROA_I18N_MYDSPACE_ACTIONACCEPTBN = "Accetta";
var SUROA_I18N_MYDSPACE_STATUS_0_50 = "da completare";
var SUROA_I18N_MYDSPACE_STATUS_50_100 = "da completare";
var SUROA_I18N_MYDSPACE_STATUS_100_200 = "in corso di verifica";
var SUROA_I18N_MYDSPACE_STATUS_COMPLETED = "verificata ed inserita in archivio";
var SUROA_I18N_MYDSPACE_STATUS_UPDATE = "verificata ed inserita in archivio, attualmente in corso di aggiornamento";
var SUROA_I18N_MYDSPACE_STATE_POOL1 = 'Step 1 pool: in attesa di validazione';
var SUROA_I18N_MYDSPACE_STATE_STEP1 = 'Step 1: da validare';
var SUROA_I18N_MYDSPACE_STATE_POOL2 = 'Step 2 pool: in attesa di validazione e verifica dei metadati';
var SUROA_I18N_MYDSPACE_STATE_STEP2 = 'Step 2: da validare, verificare i metadati';
var SUROA_I18N_MYDSPACE_STATE_POOL3 = 'Step 3 pool: in attesa della verifica finale dei metadati';
var SUROA_I18N_MYDSPACE_STATE_STEP3 = 'Step 3: verifica finale dei metadati';
var SUROA_I18N_MYDSPACE_STATE_UNKNOWN = 'Sconosciuto';