var SUROA_I18N_DEDUP_DIALOG_TITLE = "Found potential duplicates!";
var SUROA_I18N_DEDUP_IGNORE_DIALOG_MESSAGE = "Please explain why this duplicate should be allowed. Your comment will be available to users allowed to edit the duplicate item. If this is not a duplicate please click 'cancel' and use the appropriate option";
var SUROA_I18N_DEDUP_IGNORE_DIALOG_PROMPT = "";	
var SUROA_I18N_DEDUP_FAKE_BUTTON = "Not a duplicate";
var SUROA_I18N_DEDUP_IGNORE_BUTTON = "Make a duplicate!";