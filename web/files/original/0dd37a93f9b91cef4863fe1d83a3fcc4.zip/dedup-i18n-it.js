var SUROA_I18N_DEDUP_DIALOG_TITLE = "Individuati potenziali duplicati!";
var SUROA_I18N_DEDUP_IGNORE_DIALOG_MESSAGE = "Motiva la richiesta di ignorare il duplicato. Il testo inserito sar\u00E0 visibile agli utenti abilitati all'editing dell'item segnalato come duplicato. Se non si tratta di un duplicato premi annulla e seleziona l'opzione specifica";
var SUROA_I18N_DEDUP_IGNORE_DIALOG_PROMPT = "";	
var SUROA_I18N_DEDUP_FAKE_BUTTON = "Non &egrave; un duplicato";
var SUROA_I18N_DEDUP_IGNORE_BUTTON = "Crea Duplicato";