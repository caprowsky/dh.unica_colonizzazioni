glow.ready(function(){
	
	// SET SOME GLOW SHORTCUTS 
	var dom = glow.dom,
		$ = glow.dom.get,
		anim = glow.anim,
		events = glow.events;
	
	//SET SOME FUNCTIONS AND VARIABLES
	//COUNT THE ACCORDIONS
	accordionCount = $("div.accordion h2").length;
	// EXPAND ALL FUNCTION
	function expandAll() {
		$("div.accordion_content").css("height","auto");
		$("div.accordion h2").addClass("open");
		accordionControls = $("#accordion_controls").html(collapseControl);
		$("p.collapse").css("display", "block");
		collapseListener = events.addListener("p.collapse", "click", collapseAll);
		return false;
	}
	// COLLAPSE ALL FUNCTION
	function collapseAll() {
		$("div.accordion_content").css("height",0);
		$("div.accordion h2").removeClass("open");
		accordionControls = $("#accordion_controls").html(expandControl);
		$("p.expand").css("display", "block");
		expandListener = events.addListener(".expand", "click", expandAll);
		return false;
	}
	
	//IF THERE IS MORE THAN ONE ACCORDION PANEL
	if(accordionCount > 1){
		//CREATE THE ACCORDION EXPAND/COLLAPSE LINKS AND SHOW EXPAND BY DEFAULT
		var expandControl = "<p class=\"expand\"><a href=\"#\" title=\"Expand all panels\">expand all</a></p>";
		var collapseControl = "<p class=\"collapse\"><a href=\"#\" title=\"Collapse all panels\">collapse all</a></p>";
		var accordionControls = $("#accordion_controls").html(expandControl);
		$("p.expand").css("display", "block");
			
		// ADD LISTENERS FOR THE EXPAND LINK
		var expandListener = events.addListener(".expand", "click", expandAll);
		// INITIATE VAR FOR COLLAPSE LINK LISTENER
		var collapseListener;
		
		// IF THERE ARE THREE OR FEWER ACCORDIONS, DEFAULT THEM TO OPEN
		if(accordionCount <= 3){
			expandAll();
		}
	//OTHERWISE IF THERE IS ONLY ONE ACCORDION PANEL
	}else{
		//SNAP THE PANEL OPEN AND HIDE THE CONTROLS
		$("div.accordion_content").css("height","auto");
		$("div.accordion h2").addClass("open");
		$("#accordion_controls").css("display","none");
	}

	// ADD A LISTENER FOR EACH HEADING AND CREATE THE SLIDE TOGGLE ANIMATION FOR EACH
	$("div.accordion h2").each(function() {
		events.addListener(this, "click", function(event) {
			anim.slideToggle($(this).next(), 0.4);
			$(this).toggleClass("open");
			return false;
		});
	});
	
	
});