glow.ready(function(){
	
	// SET SOME GLOW SHORTCUTS 
	var dom = glow.dom,
		$ = glow.dom.get,
		anim = glow.anim,
		events = glow.events;
	
	// COLLAPSE ALL TRANSCRIPTS
	$("div.transcript").each(function(){
		$(this).addClass("closed");
	});
	
	// ADD HTML FOR EXPAND TRANSCRIPT LINK
	$("p.expand_trans").each(function(){
		$(this).html("<a href='#' title='Read transcript'>Read transcript</a>");
	});
	
	// ADD A LISTENER FOR EACH EXPAND TRANSCRIPT LINK
	$("p.expand_trans").each(function() {
		events.addListener(this, "click", function(event) {
			anim.slideToggle($(this).next(), 0.4,{
				onComplete: expand_trans_status(this)
			});
			$(this).toggleClass("open");
			return false;
		});
	});
	
	// FIGURE OUT WHAT THE STATE IS FOR THE TRANSCRIPT LINK
	function expand_trans_status(link){
		if(link.__isOpen == true){
			$(link).html("<a href='#' title='Close transcript'>Close transcript</a>");
		}else{
			$(link).html("<a href='#' title='Read transcript'>Read transcript</a>");
		}
	}
});