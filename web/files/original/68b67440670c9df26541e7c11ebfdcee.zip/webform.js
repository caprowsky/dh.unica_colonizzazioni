function handleLoad(request) {
   glow.dom.get("#p-mod-webForm").html(THANKS_MESSAGE);
}

function submitForm(f) {  
	var params = glow.dom.get(f).val();

	var validName = glow.dom.get("#form-1-text-1").val();
	var validEmail = glow.dom.get("#form-1-text-2").val();

	if ('' == validName || null == validName){
    	alert ('Please enter a name');
	} else
		 if ('' == validEmail || null == validEmail) {
    		alert ('Please enter an email address');
		} else
			 if (validate_email(validEmail)){
				var request = glow.net.post('/apps/ifl/apps/vision/formdigest/post2log', params, {onLoad:handleLoad} )
			}
	return false;
}

function validate_email(email) {
	if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)) {
		return true;
	}
	alert("Please make sure you have entered a valid email address.");
	return false;
}
