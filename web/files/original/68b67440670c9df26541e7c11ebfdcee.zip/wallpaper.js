//create Panel instance
if (glow.dom.get("#wpLightbox").length != 0) {
	var wpLightbox = new glow.widgets.Panel("#wpLightbox", {
        width: "666px",
        theme: "dark",
        modal: true,
        anim: "fade"
    });
	glow.dom.get("#glow-panel-hd-bottom").removeClass("hide");
}

function wallpaperLightbox(objID) {
	var wpHref = glow.dom.get('#' + objID).attr("href");
	glow.dom.get('#wallpaper-image').attr("src", wpHref);
//	glow.dom.get('#wallpaper-dl-4x3').attr("href", wpHref + ".zip");
//	glow.dom.get('#wallpaper-dl-16x9').attr("href", wpHref + ".zip");
//	glow.dom.get('#wallpaper-dl-4x3').attr("href", wpHref);
//	glow.dom.get('#wallpaper-dl-16x9').attr("href", wpHref);
	glow.dom.get('#hd').text(glow.dom.get('#title-' + objID).text());
	if (glow.dom.get('#wp-description').length != 0) { glow.dom.get('#wp-description').html(glow.dom.get('#description-' + objID).html()); }	
	
	wpLightbox.show();
	return false; 
}