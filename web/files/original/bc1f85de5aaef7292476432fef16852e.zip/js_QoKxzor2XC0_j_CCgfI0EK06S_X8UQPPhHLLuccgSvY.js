/* console */
(function ($) {
  if (typeof console === "undefined" || typeof console.log === "undefined") {
    console = {};
    console.log = function(message) {
      /* alternative way to display console messages */
      // $("body").append("<div>" + message + "</div>");
    };
  }
  console.log("console.define");
}) (jQuery);

/* site menu */
(function ($) {
  $(document).ready(function() {

    console.log("document.ready.site-menu: " + "start");

    var site_menu = $("#main-menu-wrapper ul.menu:nth-child(1)");
    count = 1;
    $("#main-menu-wrapper ul.menu").each(function() {
      $(this).addClass('child-' + count);
      count++;
    });
    count = 1;
    $("#main-menu-wrapper div").each(function() {
      $(this).addClass('child-' + count);
      count++;
    });

    var site_link = $("#main-menu-wrapper ul.menu:nth-child(1) > li.first a");

    var site_expand = $("#main-menu-wrapper ul.menu:nth-child(1) > li.last .dropdown-menu");

    var site_expand_divider = site_expand.find(".divider");

    site_expand_divider.html(site_link.clone());

    /* open */
    site_link.click(function(event) {
      console.log("site_link.click: " + "start");

      event.preventDefault();
      event.stopPropagation();

      $("#main-menu-wrapper .current").removeClass("current");

      var width = site_menu.width();
      var height = site_menu.height();
      site_menu.css({"width": width, "height": height});

      site_menu.addClass("current");

      console.log("site_link.click: " + "end");
    });

    /* close on blur */
    // $(document).click(function(event) {
    $("body > *, input").bind("click touch focus", function(event) {
      console.log("document.click.site-menu: " + "start");

      site_menu.removeClass("current");
      site_menu.css({"width": "", "height": ""});

      console.log("document.click.site-menu: " + "end");
    });

    /* close on escape */
    $(document).keyup(function(event) {
      console.log("document.keyup.site-menu: " + "start");

      /* escape */
      if (event.which == 27) {
        console.log("document.keyup.site-menu.key.escape: " + "start");

        site_menu.removeClass("current");
        site_menu.css({"width": "", "height": ""});

        console.log("document.keyup.site-menu.key.escape: " + "end");
      }

      console.log("document.keyup.site-menu: " + "end");
    });

    console.log("document.ready.site-menu: " + "end");
  });
}) (jQuery);

/* user menu */
(function ($) {
  $(document).ready(function() {
    console.log("document.ready.user-menu: " + "start");

    var user_menu = $("body.logged-in #main-menu-wrapper ul.nav");

    var user_link = $("body.logged-in #main-menu-wrapper ul.nav > li > a");

    var user_expand = $("body.logged-in #main-menu-wrapper ul.nav > li .dropdown-menu");

    /* open */
    user_link.click(function(event) {
      console.log("user_link.click: " + "start");

      event.preventDefault();
      event.stopPropagation();

      $("#main-menu-wrapper .current").removeClass("current");

      user_menu.addClass("current");

      console.log("user_link.click: " + "end");
    });
    // user_menu.addClass("current");

    /* close on blur */
    // $(document).click(function(event) {
    $("body > *, input").bind("click touch focus", function(event) {
      console.log("document.click.user-menu: " + "start");

      user_menu.removeClass("current");
      user_menu.css({"width": "", "height": ""});

      console.log("document.click.user-menu: " + "end");
    });

    /* close on escape */
    $(document).keyup(function(event) {
      console.log("document.keyup.user-menu: " + "start");

      /* escape */
      if (event.which == 27) {
        console.log("document.keyup.user-menu.key.escape: " + "start");

        user_menu.removeClass("current");
        user_menu.css({"width": "", "height": ""});

        console.log("document.keyup.user-menu.key.escape: " + "end");
      }

      console.log("document.keyup.user-menu: " + "end");
    });

    console.log("document.ready.user-menu: " + "end");
  });
}) (jQuery);;
