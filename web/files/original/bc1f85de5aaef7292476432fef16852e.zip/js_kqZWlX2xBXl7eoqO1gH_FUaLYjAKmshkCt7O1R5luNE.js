// $Id: hint.js 161 2012-01-19 20:30:08Z wayne $
(function ($) {

/**
 * The Drupal behavior to add the $.hint() behavior to elements.
 */
Drupal.behaviors.hint = {};
Drupal.behaviors.hint.attach = function(content) {
  // Even though it's unlikely that another class name would be used, we ensure
  // that the behavior uses the default class names used in the module.
  jQuery('input.hint-enabled:not(input.hint)', content).hint({
    hintClass: 'hint',
    triggerClass: 'hint-enabled'
  });
};

/**
 * The jQuery method $.hint().
 *
 * This method can be used on any text field or password element and is not
 * Drupal-specific. Any elements using hint must have a "title" attribute,
 * which will be used as the hint.
 */
jQuery.fn.hint = function(options) {
  var opts = jQuery.extend(false, jQuery.fn.hint.defaults, options);

  $(this).find('input').andSelf().filter('[type=text], [type=password]').each(function() {
    if (this.title) {
      var $element = $(this);
      // Add hint placeholder if it doesn't exists
      var $placeholder = $('input.' + opts.hintClass, $element.parent());
      if ($placeholder.length == 0) {
        var attributes = opts.keepAttributes;
        $placeholder = $('<input type="textfield" value="" />');
        // Set the attributes on our placeholder.
        for (var key in attributes) {
          var attribute = attributes[key];
          $placeholder.attr(attribute, $element.get(0)[attribute]);
        }
        $placeholder.val($element.get(0).title);
        $placeholder.get(0).autocomplete = false;
        $placeholder.removeClass(opts.triggerClass).addClass(opts.hintClass);
        $element.after($placeholder);
        if ($element.val() == '') {
          $element.hide();
        }
        else {
          $placeholder.hide();
        }
      }
      

      $placeholder.focus(function() {
        $placeholder.hide();
        $element.show().get(0).focus();
      });
      $element.blur(function() {
        if (this.value == '') {
          $element.hide();
          $placeholder.show();
        }
      });
    }
  });
};

jQuery.fn.hint.defaults = {
  // The class given the textfield containing the hint.
  hintClass: 'hint',

  // A class that will trigger the hint if $.hint() is used on multiple
  // elements or the entire page.
  triggerClass: 'hint-enabled',

  // A list of attributes that will be copied to the placeholder element.
  // Usually this list will be sufficient, but a special list may be specified
  // if needing to keep custom or obscure attributes.
  keepAttributes: ['style', 'className', 'title', 'size']
};

})(jQuery);
;
(function($, Drupal, undefined){
  /**
   * When set to enable mediaelement for all audio/video files add it to the page.
   */
  Drupal.behaviors.mediaelement = {
    attach: function(context, settings) {
      if (settings.mediaelement !== undefined) {
        // @todo Remove anonymous function.
        $.each(settings.mediaelement, function(selector, options) {
          var opts;
          $(selector, context).once('mediaelement', function() {
            if (options.controls) {
              $(this).mediaelementplayer(options.opts);
            }
            else {
              $(this).mediaelement();
            }
          });
        });
      }
      // The global option is seperate from the other selectors as it should be
      // run after any other selectors.
      if (settings.mediaelementAll !== undefined) {
        $('video,audio', context).once('mediaelement', function() {
          $(this).mediaelementplayer();
        });
      }
    }
  };
})(jQuery, Drupal);;

(function ($) {
  Drupal.Panels = Drupal.Panels || {};

  Drupal.Panels.autoAttach = function() {
    if ($.browser.msie) {
      // If IE, attach a hover event so we can see our admin links.
      $("div.panel-pane").hover(
        function() {
          $('div.panel-hide', this).addClass("panel-hide-hover"); return true;
        },
        function() {
          $('div.panel-hide', this).removeClass("panel-hide-hover"); return true;
        }
      );
      $("div.admin-links").hover(
        function() {
          $(this).addClass("admin-links-hover"); return true;
        },
        function(){
          $(this).removeClass("admin-links-hover"); return true;
        }
      );
    }
  };

  $(Drupal.Panels.autoAttach);
})(jQuery);
;
(function ($) {

$(document).ready(function() {

  // Expression to check for absolute internal links.
  var isInternal = new RegExp("^(https?):\/\/" + window.location.host, "i");

  // Attach onclick event to document only and catch clicks on all elements.
  $(document.body).click(function(event) {
    // Catch the closest surrounding link of a clicked element.
    $(event.target).closest("a,area").each(function() {

      var ga = Drupal.settings.googleanalytics;
      // Expression to check for special links like gotwo.module /go/* links.
      var isInternalSpecial = new RegExp("(\/go\/.*)$", "i");
      // Expression to check for download links.
      var isDownload = new RegExp("\\.(" + ga.trackDownloadExtensions + ")$", "i");

      // Is the clicked URL internal?
      if (isInternal.test(this.href)) {
        // Skip 'click' tracking, if custom tracking events are bound.
        if ($(this).is('.colorbox')) {
          // Do nothing here. The custom event will handle all tracking.
        }
        // Is download tracking activated and the file extension configured for download tracking?
        else if (ga.trackDownload && isDownload.test(this.href)) {
          // Download link clicked.
          var extension = isDownload.exec(this.href);
          _gaq.push(["_trackEvent", "Downloads", extension[1].toUpperCase(), this.href.replace(isInternal, '')]);
        }
        else if (isInternalSpecial.test(this.href)) {
          // Keep the internal URL for Google Analytics website overlay intact.
          _gaq.push(["_trackPageview", this.href.replace(isInternal, '')]);
        }
      }
      else {
        if (ga.trackMailto && $(this).is("a[href^='mailto:'],area[href^='mailto:']")) {
          // Mailto link clicked.
          _gaq.push(["_trackEvent", "Mails", "Click", this.href.substring(7)]);
        }
        else if (ga.trackOutbound && this.href.match(/^\w+:\/\//i)) {
          if (ga.trackDomainMode == 2 && isCrossDomain(this.hostname, ga.trackCrossDomains)) {
            // Top-level cross domain clicked. document.location is handled by _link internally.
            event.preventDefault();
            _gaq.push(["_link", this.href]);
          }
          else {
            // External link clicked.
            _gaq.push(["_trackEvent", "Outbound links", "Click", this.href]);
          }
        }
      }
    });
  });

  // Colorbox: This event triggers when the transition has completed and the
  // newly loaded content has been revealed.
  $(document).bind("cbox_complete", function() {
    var href = $.colorbox.element().attr("href");
    if (href) {
      _gaq.push(["_trackPageview", href.replace(isInternal, '')]);
    }
  });

});

/**
 * Check whether the hostname is part of the cross domains or not.
 *
 * @param string hostname
 *   The hostname of the clicked URL.
 * @param array crossDomains
 *   All cross domain hostnames as JS array.
 *
 * @return boolean
 */
function isCrossDomain(hostname, crossDomains) {
  /**
   * jQuery < 1.6.3 bug: $.inArray crushes IE6 and Chrome if second argument is
   * `null` or `undefined`, http://bugs.jquery.com/ticket/10076,
   * https://github.com/jquery/jquery/commit/a839af034db2bd934e4d4fa6758a3fed8de74174
   *
   * @todo: Remove/Refactor in D8
   */
  if (!crossDomains) {
    return false;
  }
  else {
    return $.inArray(hostname, crossDomains) > -1 ? true : false;
  }
}

})(jQuery);
;
