jQuery(document).ready(function(){
	var shopUrl = window.location.href;
	var protUrl = window.location.protocol;
	
	jQuery('a').each(function (){
		var url = jQuery(this).attr("href");
		if(typeof(url) != "undefined") {
			var pageAnchor = '';
			var slash='';sessIdTag='?';
			var parent = jQuery(this).parent().parent().parent().attr("id");
		
			if(url.indexOf("p_session_id") > -1) jQuery(this).click(updateSession);
			
			if((shopUrl.indexOf('shoppingPayment') != -1 && protUrl.indexOf('https') != -1) || (url.indexOf('displayFulltext') == -1 && url.indexOf('downloadEpub') == -1 && url.indexOf('displayBackIssues') == -1 && url.indexOf('publishCommentDetails') == -1 && url.indexOf('displayAbstract') == -1 && url.indexOf('displayJournal') == -1 && 
				url.indexOf('displayIssue') == -1 && url.indexOf('displaySpecialArticle') == -1 && url.indexOf('fulltext_content')== -1 && url.indexOf('/downloadsup.php?') == -1 &&
				url.indexOf('messageLink.jsp') == -1 && url.indexOf('/data/KBART') && url.indexOf('fulltext_')== -1 && url.indexOf('ftp://') && url.indexOf('/data/specialPage')) || 
				(shopUrl.indexOf('memServShoppingPayment') != -1 && protUrl.indexOf('https') != -1)) {
				if(parent != 'h-menu-rl1-box' && parent != 'h-menu-rl3-box' && parent!= 'h-menu-r15-box') {
					if(url.indexOf('javascript') < 0 && url.indexOf('http') < 0 && url.indexOf('#') != 0 && url.indexOf('mailto') != 0) {
						if (url.indexOf('#') > 0) {
							// PID 83148 & 83008:: fmergano - 04/12/2012
							if(url.indexOf('stream') > -1 || url.indexOf('contactUs') > -1){
								pageAnchor = url.substring(url.indexOf('#'), url.length);
							}
							url = url.substring(0, url.indexOf('#'));
						}
						if (url.indexOf('/action/')<0) slash='/action/';
						if (url.indexOf('?')>-1) sessIdTag='&';
						// PID 83148 & 83008:: fmergano - 04/12/2012 - Added pageAnchor
						jQuery(this).attr("href",cjo_url+slash+url+sessIdTag+'sessionId='+globalSession+pageAnchor);
					}
				}
			}
			
			if(url.indexOf('mrs.org') != -1 && url.indexOf('journalBannerLink') == -1){

				var addCustToURL = 'Y';

				if (url.indexOf(mrs_url) != -1) {

					addCustToURL = 'N';

				}

				var hashCode = jQuery("input[name='mrsSessionHashCode']").val();

				var custId = jQuery("input[name='mrsCustId']").val();

				var mrs = "https://online.mrs.org/mrsssa/ssaauthmain.authenticated_redirect?p_add_cust_to_url="+addCustToURL+"&p_cust_id="+custId+"&p_session_id="+hashCode+"&p_target_url="+url+"/?auth=yes";

				if(typeof(custId) != "undefined"){

					jQuery(this).attr("href",mrs);

				}

			}
		}
	});	
	
	//JOU-10076 My CJO for MRS users
	mrsPop();
});

jQuery(".year-row-item-nonexistent").click(function(){
	var e=jQuery(this).hasClass("icon-row-f");
	var d=jQuery(this).hasClass("icon-row-s");
	var b=jQuery(this).hasClass("icon-row-t");
	var g=jQuery(this).hasClass("icon-row-p");
	var h=jQuery(this).hasClass("icon-row-o");
	var k=jQuery(this).hasClass("icon-row-c");
	var a=jQuery(this).hasClass("icon-row-i");
	var j=jQuery(this).hasClass("icon-row-op");
	if(e){jQuery(this).toggleClass("active-expanded-f")}
		else{if(d){jQuery(this).toggleClass("active-expanded-s")}
			else{if(b){jQuery(this).toggleClass("active-expanded-t")}
				else{if(g){jQuery(this).toggleClass("active-expanded-p")}
					else{if(h){jQuery(this).toggleClass("active-expanded-o")}
						else{if(k){jQuery(this).toggleClass("active-expanded-c")}
						}
					}
				}
			}
	}
	if(a){jQuery(this).toggleClass("active-expanded-i")}
	else{if(j){jQuery(this).toggleClass("active-expanded-op")}
		else{jQuery(this).toggleClass("active-expanded")}
	}
	jQuery("#"+this.id+"box").slideToggle();return false});

/* sliding the recent actions */
jQuery('.close').click(function () { 
	jQuery(this).toggleClass("active");	
	jQuery('#'+this.id+'box').slideToggle();
	return false; 	
});

jQuery('#contentsubmit').hover(
        function(){ // Change the input image's source when we "roll on"
            jQuery(this).attr({ src : '/images/buttons/submit_hover.gif'});
        },
        function(){ // Change the input image's source back to the default on "roll off"
            jQuery(this).attr({ src : '/images/buttons/submit_normal.gif'});             }
    );

/*my favourite  journals page*/
jQuery('.favJournal-page-row').click(function () {
	jQuery(this).toggleClass("inactive");
	jQuery('#'+this.id+"inner").slideToggle();
	return false; 	
});

/*saved Trials page*/
jQuery('.savedTrials-page-row').click(function () {
	jQuery(this).toggleClass("inactive");
	jQuery('#'+this.id+"inner").slideToggle();
	return false; 	
});


/*search Help pages page*/
jQuery('.searchHelp-page-row').click(function () {
	jQuery(this).toggleClass("inactive");
	jQuery('#'+this.id+"inner").slideToggle();
	return false; 	
});


/* sliding the sidebars boxes */
jQuery('.s-menu a').click(function () {
	jQuery(this).toggleClass("active");
	jQuery('#'+this.id+'-box').slideToggle();

	if(jQuery(this).parent().parent().attr("id") == 'flm'){
		jQuery(this).parent().parent().toggleClass("hidden");
		jQuery(this).children("span:first").toggleClass("arrow-s-active");
	}
	//else{
		var ttt ;
		if (jQuery(this).hasClass('active')) {
		  	ttt='block';
		} else {
		 	ttt='none';
		}
		jQuery.cookies.set(this.id+'-box', ttt);
	//}
	return false; 
});

jQuery('ul.tabs a').click(function () {	
	jQuery(this).toggleClass("active");
	jQuery('ul.tabs a.tab-link').removeClass("active");	
	if(jQuery('#tab-'+this.id+'').css('display')=='block'){
		jQuery('div#tabclipboard-holder').addClass("collapsed");
	}else{
		jQuery('div.tabholder-div').css('display','none');
		jQuery(this).addClass("active");
		jQuery('div#tabclipboard-holder').removeClass("collapsed");
	}
		
	jQuery('#tab-'+this.id+'').slideToggle();
	return false; 
});

jQuery('.tb').click(function () {
	jQuery('.tb').removeClass("active");
	jQuery(this).addClass("active");
	return false;
});
/* sliding the preview boxes */
jQuery('.preview').live('click', previewEvent);

jQuery('.h-tabelm').click(function () { 	
	return false; 
});

/*header search mode*/
jQuery('.csearch,.qsearch').click(function () { 	
	jQuery('#navigation-search').toggleClass("qsearchactive");
	jQuery('#quick-search,#cite-search').toggle();
	return false; 	
});

jQuery('.ji-links ul li').hover(
	function () {
  		jQuery(this).css("background-color","#f0f0f0");
  	}, 
	function () {
  		jQuery(this).css("background-color","#FFFFFF");
  	}
);


/*header login /logout box*/
jQuery('.login').click(function () {
	if(jQuery(this).hasClass("second_step")){
		jQuery('.ssdd-section').toggle();
		jQuery('.ssdd-section-details').toggle();
		jQuery('.login').toggleClass("second_step");	
	}								
							
	jQuery(this).toggleClass("active");
	jQuery('#session-dd-holder').toggle();
	return false;
});

jQuery('.logout').click(function () {	
	if(jQuery(this).hasClass("second_step")){
		jQuery('.ssdd-section').toggle();
		jQuery('.ssdd-section-details').toggle();
		jQuery('.logout').toggleClass("second_step");	
	}								
							
	jQuery(this).toggleClass("active");
	jQuery('#session-dd-holder').toggle();
	return false; 	
});

jQuery('.membername').click(function () {							
	
	jQuery(this).toggleClass("active");
	jQuery('#library-login').toggle();
	return false; 	
});

/*for links that will open the login box*/
jQuery('.loginLink').click(function () {
	if(jQuery('.login').hasClass("second_step")){
		jQuery('.ssdd-section').toggle();
		jQuery('.ssdd-section-details').toggle();
		jQuery('.login').toggleClass("second_step");	
	}								
							
	jQuery('.login').toggleClass("active");
	jQuery('#session-dd-holder').toggle();
	
	
	return false;
});	



jQuery('.ssdd-section-bttn').click(function () {
	jQuery('.login').toggleClass("second_step");									
	jQuery('.ssdd-section').toggle();
	jQuery('.ssdd-section-details').toggle();
	jQuery('#cjo_username').focus();
	return false; 	
});

jQuery('.ssdd-section-social').click(function () {
	jQuery('.login').toggleClass("second_step");									
	jQuery('.ssdd-section').toggle();
	jQuery('.ssdd-section-networking').toggle();
	return false; 	
});

jQuery('.back-issue-row').live('click', animations_toggleBackIssueRow);

function animations_toggleBackIssueRow() {
	jQuery(this).toggleClass("inactive");
	jQuery('#'+this.id+"inner").slideToggle();
	var classname=this.className;
	if (classname.indexOf('journal-holder-helper')>-1 || classname.indexOf('comments-holder-helper')>-1 || classname.indexOf('metrics-holder-helper')>-1){
   //it is in abstract do not excute in related and comment area
	   return false; 
	}
	if (classname.indexOf('displayed')<0){
		jQuery.cookies.set(this.id+'~'+journal_id, 'displayed');
		this.className=classname+' displayed';
		jQuery('div#'+'#'+this.id+'inner *[class*=year-row-item]').each(function (i){
			var yearVol=this.id.substr(13);
			var splittedYearVol=yearVol.split('-');
			if (splittedYearVol.length==1){
				if(jQuery('div#'+this.id+'box div[id*=yvselector]').size() > 0) {
					jQuery('div#'+this.id+'box div[id*=yvselector]').each(function (ia){
						var lineToCut=11;
						if(this.id.indexOf('helper')>0) {
						 	lineToCut=18;
						}
					
						var yearVolForyvselector=this.id.substr(lineToCut);
						var splittedYearVolForyvselector=yearVolForyvselector.split('-');
						getYourAccess(journal_id,splittedYearVolForyvselector[1],splittedYearVolForyvselector[2],splittedYearVolForyvselector[0]);
					});
				} else {
					if(jQuery("#"+this.id + " [name=volume-year-identifier]").first().val()) {
						var volumeYear = jQuery("#"+this.id + " [name=volume-year-identifier]").first().val().split("/");
						if(volumeYear) getYourAccess(journal_id,volumeYear[0],volumeYear[2],volumeYear[1],volumeYear[3],volumeYear[4]);	
					} else {
						//this is for checking issue access
						var idSplit = jQuery(this).children().first("a").attr("id").split("_");
						getYourAccess(journal_id, idSplit[1], idSplit[2], idSplit[0], idSplit[3], idSplit[4]); // pass the issue component id
					}
				}
			} else if (splittedYearVol.length > 3) {				
				var year = splittedYearVol[0];
				for(var i = 1; i < splittedYearVol.length - 2; i++) {
					year = year + "-" + splittedYearVol[i];
				}
				getYourAccess(journal_id,splittedYearVol[splittedYearVol.length - 2],splittedYearVol[splittedYearVol.length - 1],year);
			} else {
				getYourAccess(journal_id,splittedYearVol[1],splittedYearVol[2],splittedYearVol[0]);
			}
		}); 
	} else {
		jQuery.cookies.set(this.id+'~'+journal_id, 'inactive');
	}
	jQuery.cookies.set(journal_id+"_closeAll",null);
	return false; 
}

jQuery('.year-row-item').live('click', animations_toggleYearRowItem);

function animations_toggleYearRowItem() {
	if (this.className.indexOf('active-expanded')>-1 ){
		jQuery.cookies.set(this.id+'~'+journal_id, null);
    } else {
		jQuery.cookies.set(this.id+'~'+journal_id, 'active-expanded');
    }
    
	var f = jQuery(this).hasClass("icon-row-f");
	var s = jQuery(this).hasClass("icon-row-s");
	var c = jQuery(this).hasClass("icon-row-c");
	var i = jQuery(this).hasClass("icon-row-i");
	var def= jQuery(this).hasClass("icon-row");
	
	if (def){
		jQuery(this).toggleClass("active-expanded");
		
	}
	
	if(f){
		jQuery(this).toggleClass("active-expanded-f");
	} else if(s) {
		jQuery(this).toggleClass("active-expanded-s");
	} else if(c) {
		jQuery(this).toggleClass("active-expanded-c");
	} else if(i) {
		jQuery(this).toggleClass("active-expanded-i");
	}
	jQuery('#'+this.id+"box").slideToggle();
	//jQuery.cookies.set(journal_id+"_openAll",null);
	jQuery.cookies.set(journal_id+"_closeAll",null);
	return false; 
}

jQuery('.yvselector').click(animations_toggleYVSelector);

function animations_toggleYVSelector() {
	if (this.className.indexOf('active-expanded-mini')>-1 ){ 	
	      jQuery.cookies.set(this.id+'~'+journal_id, null);
	}else{
	     jQuery.cookies.set(this.id+'~'+journal_id, 'active-expanded-mini');
	}

	var def= jQuery(this).hasClass("icon-row-mini");
	if (def) {
		jQuery(this).toggleClass("active-expanded-mini");		
	}else{
	
		if(jQuery(this).attr("class").split(" ")[2]){
			var a=jQuery(this).attr("class").split(" ")[2].split("-")[3];
			if(a) {
				a = "-" + a;
			} else {
				a = "";
			}
			jQuery(this).toggleClass("active-expanded-mini"+a);
		}else{
			var b=jQuery(this).attr("class").split(" ")[1].split("-")[3];
			if(b) {
				b = "-" + b;
			} else {
				b = "";
			}
			jQuery(this).toggleClass("active-expanded-mini"+b);
		}
	}	
	
	jQuery('#'+this.id+"-box").slideToggle();

	jQuery.cookies.set(journal_id+"_closeAll",null);
	return false; 	
}

/*supplement subclass*/
jQuery('.supplement-issue-row').click(function () {
	jQuery(this).toggleClass("inactive");
	jQuery('#'+this.id+"inner").slideToggle();
	return false; 	
});


jQuery('.supplement-row-item').click(function () {
	jQuery(this).toggleClass("active-expanded");										  
	jQuery('#'+this.id+"box").slideToggle();
	return true;
});

jQuery('.svselector').click(function () {
	jQuery(this).toggleClass("svselector-active-expanded");
	jQuery('#'+this.id+"-box").slideToggle();
	return false; 	
});


/*my alerts*/
jQuery('.my-alerts-row').click(function () {
	jQuery(this).toggleClass("inactive");
	jQuery('#'+this.id+"inner").slideToggle();
	return false; 	
});

jQuery('[class=issueTitle]').click(function () { 
	var title = jQuery(this).parent().attr('id');
	jQuery('#'+title).toggleClass("active-expanded");										  
	jQuery('#'+title+'box').slideToggle();
	return false; 	
});

/*free content page*/
jQuery('.freeContent-page-row').click(function () {
	jQuery(this).toggleClass("inactive");
	jQuery('#'+this.id+"inner").slideToggle();
	return false; 	
});

/*related content*/
jQuery('.related-content-row').click(function () {
	jQuery(this).toggleClass("inactive");
	jQuery('#'+this.id+"inner").slideToggle();
	return false; 	
});

/*rssWidgets page*/
jQuery('.rssWidgets-page-row').click(function () {
	jQuery(this).toggleClass("inactive");
	jQuery('#'+this.id+"inner").slideToggle();
	return false; 	
});

/*free content page*/
jQuery('.jnlUpdates-page-row').click(function () {
	jQuery(this).toggleClass("inactive");
	jQuery('#'+this.id+"inner").slideToggle();

	var status ;
	if (jQuery(this).hasClass('inactive')) {
	  	status='none';
	} else {
	 	status='block';
	}
	
	jQuery.cookies.set(this.id+'inner', status);
	
	return false; 	
});


/*contact us page*/
jQuery('.contactUs-page-row').click(function () {
	jQuery(this).toggleClass("inactive");
	jQuery('#'+this.id+"inner").slideToggle();
	
	jQuery.get("/action/contactUs/storeMenuSettings?"+Math.random(), {elementId:this.id,load:'N'}, function(data){
		if(data) {
			var items = data.split(",");
			
			if(items.length && items.length == 8) {
				jQuery("#openCloseAll a").text("Close All");
			} else if (items.length < 1){
				jQuery("#openCloseAll a").text("Open All");
			}
		} else {
			jQuery("#openCloseAll a").text("Open All");
		}
	});
	
	return false; 	
});

//PID 83008 :: fmergano - 03/30/2012
function goToByScroll(id){
	//jQuery('html,body').animate({scrollTop: $("#"+id).offset().top},'slow');
	if(!jQuery("#"+id+"inner").is(":visible")){
		jQuery("#"+id).click();
	}
}

jQuery('.your-basket-row').click(function () {
	jQuery(this).toggleClass("inactive");
	jQuery('#'+this.id+"inner").slideToggle();
	return false; 	
});


jQuery('.contact-us-row').click(function () {
	jQuery(this).toggleClass("inactive");
	jQuery('#'+this.id+"inner").slideToggle();
	return false; 	
});

jQuery('.commentbox').click(function() {
	animations_commentEvent(this);
});

jQuery('#alert-message-close').click(closeAlertMessage); //pid 84893:jlimpin
//jQuery('#alert-message').click(closeAlertMessage);

function closeAlertMessage() {
	jQuery('#alert-message').fadeOut();// pid 84893:jlimpin
	//jQuery(this).fadeOut();
	jQuery.cookies.set("alert-message", "closed");
	return false;
}

jQuery('.journal-holder-helper').click(function () {
	var classname=this.className;
	if(classname.indexOf('journal-holder-helper flm') < 0 ){
		jQuery(this).toggleClass("inactive");
	}
	jQuery('#journals-holder').slideToggle();
	return false; 	
});

jQuery('.comments-holder-helper').click(function () {
jQuery(this).toggleClass("active");
	jQuery(this.id+'-box').slideToggle();
	return false; 	
});

jQuery('.hp-bttn').click(function () {
	jQuery('.hp-bttn').removeClass("active-slide");							  
	jQuery(this).toggleClass("active-slide");
	var mydivid = this.id;
	var imgpath = "/images/background/"+mydivid+".jpg";
	jQuery('#area-selector ').css('background-image','url('+imgpath+')'); 
	return false; 	
});

/*navigation*/
var selectedMenu;
function openMenu(id) {
	if(selectedMenu && selectedMenu == id) {
		jQuery(".dir ul").hide();
		jQuery("ul.dropdown li a.active").attr("class","inactive");
		selectedMenu = null;
	} else {
		jQuery("#" + id).toggleClass("active");
		jQuery("#" + id + "-box").toggle();
		selectedMenu = id;
	}
		
	jQuery("#top-navigation-menu").hover(function(){},
		function(){
			jQuery(".dir ul").hide();
			jQuery("ul.dropdown li a.active").attr("class","inactive");
			selectedMenu = null;			
		}
	);
}

/* get filtered cookies */
function loadFilteredCookies() {
	filteredCookies = jQuery.cookies.filter( /^h-menu/ );

	/* PJTABIA 
	 * 'jQuery.cookies.get(cookiename)', set, etc. results to 'has no method get', BUT still working, 
	 * Binding to namespace jQuery is not working at loading
    */
	
	/* PJTABIA based on jquery.cookie.js document */
	var openJournalMenu = jaaulde.utils.cookies.get('openJournalMenu'); /*h-menu-rl3*/
	var openJournalInformation = jaaulde.utils.cookies.get('openJournalInformation'); /*h-menu-rl1*/
	var openOthers = jaaulde.utils.cookies.get('openOthers'); /*h-menu-r29*/
    var openAccessInformation = jaaulde.utils.cookies.get('openAccessInformation'); /*h-menu-rl9*/
    var openSpecialSales = jaaulde.utils.cookies.get('openSpecialSales'); /*h-menu-rl2*/
    var openRelatedLinks = jaaulde.utils.cookies.get('openRelatedLinks'); /*h-menu-r40*/
    var openSubscriptionPrices = jaaulde.utils.cookies.get('openSubscriptionPrices'); /*h-menu-r20*/
	
    /* PJTABIA */
	jaaulde.utils.cookies.set('openJournalInformation', null);
	jaaulde.utils.cookies.set('openJournalMenu', null);
	jaaulde.utils.cookies.set('openOthers', null);
	jaaulde.utils.cookies.set('openAccessInformation', null);
	jaaulde.utils.cookies.set('openSpecialSales', null);
	jaaulde.utils.cookies.set('openRelatedLinks', null);
	jaaulde.utils.cookies.set('openSubscriptionPrices', null);
	
	if( typeof filteredCookies === 'object'  ) {
        for( name in filteredCookies ) {
      
        	origName=name.replace('-box','');
        	if(openJournalInformation == 'Y' && origName == 'h-menu-rl1')
        	{ if(name !="block")
        	  {jaaulde.utils.cookies.set(name,"block");
        	   jQuery('#'+origName).removeClass("active");
        	   jQuery('#'+origName).closest("div.sidebar-menu-container").removeClass("hidden");}
            }else if(openJournalInformation == 'N' && origName == 'h-menu-rl1'){
            	jaaulde.utils.cookies.set(name,"none");
            }
        	
        	if(openJournalMenu == 'Y' && origName == 'h-menu-rl3')
        	{ if(name !="block")
        	  {jaaulde.utils.cookies.set(name,"block");
           	   jQuery('#'+origName).removeClass("active");
           	jQuery('#'+origName).closest("div.sidebar-menu-container").removeClass("hidden");}
        	}else if(openJournalMenu == 'N' && origName == 'h-menu-rl3'){
        		jaaulde.utils.cookies.set(name,"none");
        	}
        	
        	if(openOthers == 'Y' && origName == 'h-menu-r29')
        	{jaaulde.utils.cookies.set(name,"block");
        	jQuery('#'+origName).removeClass("active");
        	}else if(openOthers == 'N' && origName == 'h-menu-r29'){
            	jaaulde.utils.cookies.set(name,"none");
            }
        	
        	if(openAccessInformation == 'Y' && origName == 'h-menu-rl9')
        	{jaaulde.utils.cookies.set(name,"block");
        	jQuery('#'+origName).removeClass("active");
        	}else if(openAccessInformation == 'N' && origName == 'h-menu-rl9'){
        		jaaulde.utils.cookies.set(name,"none");
        	}
        	
        	if(openSpecialSales == 'Y' && origName == 'h-menu-rl2')
        	{jaaulde.utils.cookies.set(name,"block");
        	jQuery('#'+origName).removeClass("active");
        	}else if(openSpecialSales == 'N' && origName == 'h-menu-rl2'){
        		jaaulde.utils.cookies.set(name,"none");
        	}
        	
        	if(openRelatedLinks == 'Y' && origName == 'h-menu-r40')
        	{jaaulde.utils.cookies.set(name,"block");
        	jQuery('#'+origName).removeClass("active");
        	}else if(openRelatedLinks == 'N' && origName == 'h-menu-r40'){
        		jaaulde.utils.cookies.set(name,"none");
        	}
        	
        	if(openSubscriptionPrices == 'Y' && origName == 'h-menu-r20')
        	{jaaulde.utils.cookies.set(name,"block");
        	 jQuery('#'+origName).removeClass("active");
        	}else if(openSubscriptionPrices == 'N' && origName == 'h-menu-r20'){
        		jaaulde.utils.cookies.set(name,"none");
        	}
        	
        	cvalue=jaaulde.utils.cookies.get(name);
	
        	if (cvalue=='block') {
				
						jQuery('#'+origName).addClass("active");
						jQuery('#'+origName).closest("div.sidebar-menu-container").removeClass("hidden")
						jQuery('#'+name).slideDown();
						jQuery('#'+origName).children("span:first").toggleClass("arrow-s-active");
			
			} else {
						jQuery('#'+origName).removeClass("active");
						jQuery('#'+name).slideUp();
					
						
		  }
		}
	}
}
function loadEmergencyAnnouncementCookie() {
	var emergencyAnnouncementCookie = jaaulde.utils.cookies.get("alert-message");
	if(emergencyAnnouncementCookie == "closed") jQuery('#alert-message').hide();
}

jQuery(document).ready(function(){
	loadFilteredCookies();

	loadEmergencyAnnouncementCookie();

	/*collapse navigation*/
	jQuery("body").click(function(){
		jQuery(".dir ul").hide();
		jQuery("ul.dropdown li a.active").attr("class","inactive");
		if(selectedMenu && selectedMenu == jQuery("ul.dropdown li a.active").attr("id")) selectedMenu = null;
	});
    
    jQuery('#artLookup-bttn input').hover(
		function(){ // Change the input image's source when we "roll on"
			jQuery(this).attr({ src : '/images/buttons/articleLookup_hover.gif'});
		},
		function(){ // Change the input image's source back to the default on "roll off"
			jQuery(this).attr({ src : '/images/buttons/articleLookup.gif'}); 
		}
	);
	
	jQuery('.go-form-bttn').hover(
        function(){ // Change the input image's source when we "roll on"
            jQuery(this).attr({ src : '/images/buttons/go_hover.gif'});
        },
        function(){ // Change the input image's source back to the default on "roll off"
            jQuery(this).attr({ src : '/images/buttons/go_normal.gif'});
        }
    );
	
	jQuery('.comment-bttn').hover(
        function(){ // Change the input image's source when we "roll on"
            jQuery(this).attr({ src : '/images/buttons/comment_hover.gif'});
        },
        function(){ // Change the input image's source back to the default on "roll off"
            jQuery(this).attr({ src : '/images/buttons/comment_normal.gif'});
        }
    );
	
	jQuery('.comment-bttn').click(function() {
		var form = jQuery(this).closest("form").attr("name");
		postCommentEvent(this,form);
		return false;
	});	        
		
	jQuery("#paradigm_all").click(function(){
		var checked_status = this.checked;
		jQuery("input[name=paradigm]").each(function(){
			this.checked = checked_status;
		});
	});
			
	jQuery(".hselect_all").click(function(){
		var checked_status = true;
		jQuery("input[name=paradigm]").each(function(){
			this.checked = checked_status;
		});
		return false;
	});	
			
	jQuery(".hdselect_all").click(function(){
		var checked_status = false;
		jQuery("input[name=paradigm]").each(function(){
			this.checked = checked_status;
		});
		return false;
	});	
	
	
});

/*movie repository page*/
jQuery('.movie-page-row').click(function () {
	jQuery(this).toggleClass("inactive");
	jQuery('#'+this.id+"inner").slideToggle();
	return false; 	
});

/*header search mode*/
jQuery('.smSubmitArt').hover(
 function(){ // Change the input image's source when we "roll on"
 jQuery(this).attr({ src : '/images/buttons/submitArtButtonHover.gif'});
},
 function(){ // Change the input image's source back to the default on "roll off"
 jQuery(this).attr({ src : '/images/buttons/submitArtButton.gif'}); }
); 

function mrsPop() {
	var id = '#dialog';

	//Get the screen height and width
	var maskHeight = jQuery(document).height();
	var maskWidth = jQuery(window).width();

	//Set heigth and width to mask to fill up the whole screen
	jQuery('#mask').css({'width':maskWidth,'height':maskHeight});

	//transition effect		
	jQuery('#mask').fadeIn(1000);	
	jQuery('#mask').fadeTo("slow", 0.8);	

	//Get the window height and width
	var winH = jQuery(window).height();
	var winW = jQuery(window).width();
	      
	//Set the popup window to center
	jQuery(id).css('top', winH / 2 - jQuery(id).height() / 2);
	jQuery(id).css('left', winW / 2 - jQuery(id).width() / 2);

	//transition effect
	jQuery(id).fadeIn(2000); 	

	//if close button is clicked
	jQuery('.window .close').click(function (e) {
	//Cancel the link behavior
	e.preventDefault();

	jQuery('#mask').hide();
	jQuery('.window').hide();
	});
}