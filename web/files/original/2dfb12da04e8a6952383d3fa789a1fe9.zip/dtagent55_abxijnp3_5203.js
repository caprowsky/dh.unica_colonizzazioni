function DynaTraceCls(){var d=this;this.version='5203';d._aa=1;d._ba=0;d._ca='';d._da=[];d._ea=[];d._fa=[];d._ga=[];d._ha=function(){if(d._ia){return;}
try{d._ja._ha();d._ka._la();d._ma._ha();d._ia=true;}
catch(e){}};d._na=function(gf,hf,jf,kf){var lf='';if(!gf){lf=d._oa._pa(hf,gf);}
else{lf=d._oa._qa();}
var mf=null;if(lf.length>0){mf=new d._ra();if(d._sa.reportUrl){mf.monitorUrl=d._sa.reportUrl;}
if(gf){mf.a('PV',1);}
mf.a('a',d._ka._ta(lf));mf.a('fId',d._ua);if(d._va!=d._ua){mf.a('pId',d._va);}
if(d._ca){mf.a('pFId',d._ca);}
mf.a('rId',d._sa.requestId);mf.a('rpId',d._sa.rpid);mf.a('dtV',d.version);if(!gf){if(!d._wa){mf.a('title',d._ka._ta(d._ka._xa(document.title)));}
var nf=d.getDomR();if(nf){mf.a('domR',nf);}
d._wa=true;}
if(d._oa._ya()){mf.a('unload','xhr');}
for(var i=0;i<d._ea.length;i++){d._ea[i](mf,gf);}}
return mf;};d._za=function(of,pf,qf,rf){var tf=d._na(of,pf,qf,rf);if(tf){d._Aa._za(tf,d._Ba,true);}};d._Ca=function(){for(var j=0;j<d._ga.length;j++){d._ga[j]();}
d._Da=d._na(false,true,false,true);var ua=d._ja._Ea();if(ua){d._oa._Fa(ua._Ga(),ua._Ha,ua._Ia);}
else{d._oa._Fa(null,null,null);}
if(navigator.vendor&&(navigator.vendor.search('Apple')>=0)){if(window.frames){for(i=0;i<window.frames.length;i++){try{if(window.frames[i].dT_){window.frames[i].dT_._Ca();}}
catch(err){}}}}
if(d._Da){d._Aa._za(d._Da,d._Ba,true);}};d._Ja=function(){if(window.opera){d._Ca();}
d._ha();d._Ka();};d._Ka=function(){if(d._La){return;}
d._Ma._Na(d._ua);d._La=true;};d._Oa=function(){d._Ma._Pa(d._ua);d._oa._Qa('_load_','_load_',d._ma._Ra(),null);d._Sa();};d._Ta=function(){if(!d._Ua){d.la('_load_');d._Sa();d._Ua=true;}};d._Va=function(){d._Sa();if(!d._Wa){if(document.readyState=='complete'){if(!d._Xa){d._Xa=true;d._ka._Ya(d._Va,3000);}
else{d._za(false,true,true,false);}}
else{d._ka._Ya(d._Va,3000);}}};d._Za=function(){d._Sa();if(!d._Wa){d.solb();d._Wa=true;d._$a._ab();d._ka._Ya(d._bb,0);}};d._bb=function(){if(!d._cb){d._cb=true;d._Sa();for(var i=0;i<d._da.length;i++){try{d._da[i]();}
catch(e){}}
d.sole();}};d._db=function(){d._sa.checkImagesTimeout=0;d._sa.checkScriptsTimeout=0;var uf=d._ma._eb();var vf=d._ma._fb();if(uf&&vf){d.la("_onload_",uf,vf);}
else{d.la("_onload_");}
if(!d._gb){d._Ta();}};d._hb=function(){d._ka._ib(window,'beforeunload',d._Ca);d._ka._ib(window,'unload',d._Ja);d._ka._ib(document,'readystatechange',d._jb);d._ka._Ya(d._Va,3000);d._ka._ib(window,'load',d._Za);};d._jb=function(){if(document.readyState=='loaded'){d._Sa();}
if(document.readyState=='complete'){d._Za();}};d._kb=false;d._Ba=function(wf){d._ka.updateLatencyCookie(wf/2);};d._lb=function(){d._kb=false;d._za(false,false,true,false);};d._mb=function(){if(!d._kb){d._ka._Ya(d._lb,d._sa._nb);d._kb=true;}};d._ob=function(xf,yf,zf){var Af=d._ka._pb();var Bf=d._oa._qb(yf,d._ka._xa(xf),Af,Af,-1,zf);if(Bf){d._mb();}};d.getDomR=function(){var p=d._ka.getPerformance();if(p&&p.timing){if(p.timing.domComplete&&p.timing.domComplete>0){return p.timing.domComplete;}
else if(p.timing.domContentLoaded&&p.timing.domContentLoaded>0){return p.timing.domContentLoaded;}}
return d._rb;};d._sb=function(){if(d._ka._tb.ie){var Cf=function(){var Df=document.createElement('doc:rdy');try{Df.doScroll('left');Df=null;d._rb=d._ka._pb();d._Sa();}
catch(e){d._ka._Ya(Cf,0);}};Cf();}
else{document.addEventListener('DOMContentLoaded',function(){d._rb=d._ka._pb();d._Sa();},false);}};d._ub=function(){try{if(parent&&(parent!=self)&&parent.dT_){return parent.dT_._ub();}}
catch(err){}
return d;};d._vb=function(Ef){if(!d._wb){return;}
d._da.push(Ef);};d._xb=function(Ff){if(!d._wb){return;}
d._ea.push(Ff);};d._yb=function(Gf){d._ga.push(Gf);};d._zb=function(Hf){d._fa.push(Hf);};d._Sa=function(){if(d._wb){for(var i=0;i<d._fa.length;i++){d._fa[i]();}}};var If={sls:function(Jf){if(d._wb){d._ma._Ab=Jf?Jf:d._ka._pb();}},sle:function(){if(d._wb){d._Ta();}},sole:function(){if(d._wb){d._aa--;if(d._aa<=0){d._db();}}},iolm:function(){if(d._wb){d._aa++;}},solb:function(){if(d._wb){if(!d._Bb){d._Bb=true;d._oa._Qa("_onload_","_load_",null,d._oa._Cb());}}},ewa:function(Kf){var Lf=this.ex(Kf,3,true);return d._oa._Db(Lf);},gFId:function(){return d._ua;},gWRI:function(Mf){return Mf._Eb;},gAN:function(Nf){return Nf._Fb;},ex:function(Of,Pf,Qf){var Rf=null;if(d._wb){if(arguments.length==1){Pf=3;}
var Sf=d._ja._Ea();var Tf=null;if(Sf&&Sf.actionName){Tf=Sf.actionName;}
if(!Tf){Tf=d._oa._ya();}
if(Tf){Rf=d._oa._Gb(Tf);}
else{if(Sf){if(Pf>=3){Rf=d._oa._Hb(Sf._Ga(),Sf._Ha,Sf._Ia,Qf);Sf.actionName=Rf;if(d._Ib){d._Ib._Jb();}}}
else{var ca=d._oa._Kb();if(ca){if(Pf>=1){Rf=d._oa._Gb(ca._Fb,Of,'xhr',d._ka._pb(),Qf);if(d._Ib){d._Ib._Jb();}}}}}}
return Rf;},lx:function(Uf){if(d._wb){var Vf=d._oa._Lb();if(Vf>1){d._ka._Ya(function(){d._oa._Mb(Uf);},0);}
else{if(d._Ib){d._Ib._Nb(function(){d._ka._Ya(function(){d._oa._Mb(Uf);},0);});}
else{d._ka._Ya(function(){d._oa._Mb(Uf);},0);}
d._Sa();return true;}}
return false;},ec:function(Wf){if(d._wb){d._oa._Ob(Wf);}},lc:function(Xf){if(d._wb){d._oa._Pb(Xf);}},bi:function(Yf,Zf,$f){if(d._wb){return d._ja._Qb(Yf,Zf,$f);}},ei:function(ui){if(d._wb){d._ja._Rb(ui);}},ci:function(){if(d._wb){var ui=d._ja._Ea();if(ui){return ui._Ga();}}
return null;},aad:function(ag){if(d._wb){d._ja._Sb(ag);}},ea:function(bg,cg,dg,eg){if(d._wb){if(arguments.length<4||typeof eg=='undefined'){eg=true;}
return d._oa._Qa(bg,cg,dg,eg)._Fb;}},la:function(fg,gg,hg){if(d._wb){d._Sa();var ig=arguments;if(d._Ib&&d._Ib._Tb){d._Ib._Nb(function(){d._oa._Ub.apply(d._oa,ig);});}
else{d._oa._Ub.apply(d._oa,ig);}}},pe:function(jg,kg){d.pcn(jg,'_error_',kg);},pw:function(mg,ng){d.pcn(mg,'_warning_',ng);},pl:function(og,pg){d.pcn(og,'_log_',pg);},rv:function(qg,rg){if(d._wb){d._oa._Vb(qg,rg,d._ka._pb());}},rs:function(sg,tg){if(d._wb){d._oa._Wb(sg,tg,d._ka._pb());}},pcn:function(ug,vg,wg){if(d._wb){d._ob(ug,vg,wg);}},tp:function(){if(d._wb){return!d._Xb;}},tdto:function(){if(d._wb){return d._ub();}},slem:function(){if(d._wb){d._gb=true;}},dbg:function(e){if(d._wb){d._ka._Yb('dtUseDebugAgent',e);}},ti:function(){if(d._wb){d._Sa();}},isc:function(xg){return(xg&&xg>=382);},cfg:function(yg){if(d._wb){return d._sa[yg];}},gDtc:function(){if(d._wb){return d._Ma._Zb();}},sC:function(zg,Ag){return d._ka._Yb(zg,Ag);},gC:function(Bg){return d._ka._$b(Bg);},lv:function(Cg){if(d._wb){return d._ka._ac(Cg);}},sv:function(Dg,Eg){if(d._wb){d._ka._bc(Dg,Eg);}},gx:function(){return d._ka.getXHR();},lg:function(Fg){d._cc(Fg);},asl:function(Gg){d._xb(Gg);},all:function(Hg){d._vb(Hg);},ail:function(Ig){d._zb(Ig);},apll:function(Jg){d._yb(Jg);},ca:function(){return d._oa._Kb();},gh:function(Kg){return d._ka._dc(Kg);},ael:function(Lg,Mg,Ng){d._ka._ib(Lg,Mg,Ng);},esc:function(s){return d._ka._ta(s);},aesc:function(a){return d._ka._ec(a);},gBI:function(){return d._ka._tb;},lst:function(){return d._ma._Ra();},ulc:function(v){d._ka.updateLatencyCookie(v);},ism:function(Og){return d._sa._fc(Og);},smbi:function(Pg){return d._sa._gc(Pg);},st:function(fn,Qg){d._ka._Ya(fn,Qg);},nw:function(){return d._ka._pb();}};d._ab=function(){d._ka._hc(dT_,If);var Rg=d._Ma._Zb();if(!Rg){d._ic=true;}
if(Rg=='blocked'){}
else if(!d._wb){d._sa._ab();if(!d._sa.requestId){d._sa.requestId=d._ka.getRID(d._sa.ridPath);}
d._wb=true;d._Aa.init(d._ka);d._ua=d._Ma._jc();try{var p=parent;if(p&&p!=self&&p.dT_&&p.dT_.version==d.version){d._kc=p.dT_;d._Xb=p.dT_._ub();}}
catch(err){}
if(!d._Xb){d._va=d._ua;d._lc=document.title;}
else{d._va=d._Xb._va;d._lc=d._Xb._lc;d._ca=d._kc._ua;d._kc._ba++;}
var Sg=(d._kc?d._kc._oa:null);d._oa._ab(d._ka,Sg,d._ua,d._$a,d._mb,d._za,d._Ma);d._ja.init(d._sa,d._ka,d._ua);d._$a._ab(d._ka,d._ja,d._ob);d._hb();if(d._sa._mc){d._nc();}
if(d._sa.checkImagesEnabled){d._oc();}
d._sb();d._Oa();}};}
if(typeof window.dT_!='undefined'){}
else{window.dT_=new DynaTraceCls();document.dT_=window.dT_;}(function(){var Tg=window.setTimeout;var Ug={};var uA=navigator.userAgent;try{if(uA.indexOf('MSIE')>=0){Ug.ie=parseInt(uA.substr(uA.lastIndexOf('MSIE')+5,3),10);}
else if((navigator.appName=='Safari'||uA.indexOf('Safari')>-1)&&(uA.indexOf('Chrome')==-1)){Ug.sf=parseInt(uA.substr(uA.lastIndexOf('Version/')+8,1),10);}
else if(typeof window.opera!='undefined'){Ug.op=parseInt(window.opera.version().split('.')[0],10);}
else if(/Firefox[\/\s](\d+\.\d+)/.test(uA)){var Vg=parseInt(RegExp.$1,10);Ug.ff=Vg==-1?0:Vg;}
else if(/(iPod|iPhone|iPad)/.test(uA)&&/AppleWebKit/.test(uA)){var v=/Version\/([0-9]*\.[0-9]*)/.test(uA);Ug.msf=parseFloat(RegExp.$1);}
else if(uA.indexOf('Android')>=0){Ug.ab=parseFloat(ua.slice(ua.indexOf("Android")+8));}
else{var p=uA.indexOf('Chrome');if(p>-1){Ug.ch=parseInt(uA.substring(p+7,p+9),10);}}}
catch(e){}
var u={_qc:(typeof window.XMLHttpRequest!='undefined')?window.XMLHttpRequest:null,_rc:(typeof window.ActiveXObject!='undefined')?window.ActiveXObject:null,_sc:'dtLatC',_tc:false,_uc:null,_vc:'\t\n\r',_wc:[],_tb:Ug,_xc:[],_yc:/Gomez[\/\s]?Agent/.test(navigator.userAgent),_Ya:function(f,t){Tg(f,t);},_hc:function(Wg,Xg){for(var p in Xg){if(Xg.hasOwnProperty(p)){Wg[p]=Xg[p];}}
return Wg;},_zc:function(Yg){var r=false;if(u._tb.ie>0){if(Yg.complete){r=true;}}
else{if(Yg.naturalWidth>0){r=true;}}
return r;},_Ac:function(Zg){return document.getElementsByTagName(Zg);},_dc:function($g){if($g.indexOf('://')==-1){return null;}
var bh=$g.split('/');var dh=bh[2].split(':');var eh=dh[0];return eh.toLowerCase();},_Bc:function(fh){if(!fh){return null;}
fh=fh.replace(/^\s+/,'');for(var i=fh.length-1;i>=0;i--){if(/\S/.test(fh.charAt(i))){fh=fh.substring(0,i+1);break;}}
return fh;},_Cc:function(hh,ih){hh.push(ih);},_Dc:function(jh,kh,to){var lh=jh.slice((to||kh)+1||jh.length);jh.length=kh<0?jh.length+from:kh;return jh.push.apply(jh,lh);},_Ec:function(s){return u._ec(u._xa(s));},_xa:function(s){if(s){var r=[];for(var i=0;i<s.length;i++){var c=s.charAt(i);if(u._vc.indexOf(c)==-1){u._Cc(r,c);}}
s=r.join('');}
return s;},_ec:function(mh){if(mh!==null){if(typeof mh!='string'){return mh;}
var i=0;var nh=[];while(i<mh.length){var oh=mh.charAt(i++);if(oh=='^'){u._Cc(nh,'^^');}
else if(oh=='|'){u._Cc(nh,'^p');}
else if(oh==','){u._Cc(nh,'^c');}
else{u._Cc(nh,oh);}}
return nh.join('');}
return null;},_ta:function(ph){ph=encodeURIComponent(ph);var qh=[];var i=0;while(i<ph.length){var rh=ph.charAt(i++);if(rh=='!'){u._Cc(qh,'%21');}
else if(rh=='~'){u._Cc(qh,'%7E');}
else if(rh=='*'){u._Cc(qh,'%2A');}
else if(rh=='('){u._Cc(qh,'%28');}
else if(rh==')'){u._Cc(qh,'%29');}
else if(rh=='\''){u._Cc(qh,'%27');}
else if(rh=='$'){u._Cc(qh,'%24');}
else if(rh==';'){u._Cc(qh,'%3B');}
else if(rh==','){u._Cc(qh,'%2C');}
else{u._Cc(qh,rh);}}
return qh.join('');},_Yb:function(sh,th){if(th){document.cookie=sh+'='+th+';path=/'+((u._Fc)?";domain="+u._Fc:"");}else{u._Gc(sh);}},_Gc:function(uh){document.cookie=uh+'=""'+';path=/'+((u._Fc)?";domain="+u._Fc:"")+'; expires=Thu, 01-Jan-70 00:00:01 GMT;';},getPerformance:function(){if(!u._Hc&&u._tb.ff==-1){if(typeof window.performance!='undefined'){u._Hc=window.performance;}}
return u._Hc;},_$b:function(vh){var i,pos,key,value;var wh=document.cookie.split(";");for(i=0;i<wh.length;i++){pos=wh[i].indexOf("=");key=wh[i].substring(0,pos);value=wh[i].substring(pos+1);key=key.replace(/^\s+|\s+$/g,"");if(key==vh){return value;}}
return null;},_bc:function(xh,yh){var zh=false;if(window.sessionStorage){try{window.sessionStorage.setItem(xh,yh);zh=true;}
catch(QuotaExceededError){}}
if(!zh){u._Yb(xh,yh);}},_ac:function(Ah){var Bh;if(window.sessionStorage){Bh=window.sessionStorage.getItem(Ah);}
if(!Bh){Bh=u._$b(Ah);}
return Bh;},getRID:function(Ch){var Dh=Ch?Ch:window.location.pathname;var Eh=window.location.search;if(Eh&&Eh.length>0){if(Eh.charAt(0)=='?'){Eh=Eh.substring(1);}}
return 'RID_'+u._Ic(Dh,Eh);},_Ic:function(Fh,Gh){var Hh=1;Hh=31*Hh+u._Jc(Fh);Hh=31*Hh+u._Jc(Gh);Hh=Hh&Hh;return Hh;},_Jc:function(s){var Ih=0;if(s){var Jh=s.length;for(var i=0;i<Jh;i++){Ih=Ih*31+s.charCodeAt(i);Ih=Ih&Ih;}}
return Ih;},_Kc:function(){},trace:function(Kh,Lh){u._Kc();if(u._Lc){u._cc(Kh,Lh);}},_cc:function(Mh,Nh){u._Kc();if(u._Lc){var Oh='';for(var j=0;j<u._wc.length;j++){Oh+='..';}
var Ph=new Date();var ms=('00'+Ph.getMilliseconds());var Qh=[Ph.getHours(),':',Ph.getMinutes(),':',Ph.getSeconds(),'.',ms.substring(ms.length-3,ms.length),' debug   [javascript]: ',Oh,Mh];u._Lc._cc(Qh.join(''),Nh);}
else if((typeof console)!='undefined'&&console.log){console.log(Mh);}},_ib:function(Rh,Sh,Th){if(Rh.addEventListener){Rh.addEventListener(Sh,Th,false);}
else if(Rh.attachEvent){Rh.attachEvent('on'+Sh,Th);}
else{throw 'addEventListener and attachEvent not found on object: '+Rh;}
u._Cc(u._xc,{_Mc:Rh,_Nc:Sh,_Oc:Th});},_Pc:function(Uh,Vh,Wh){if(u._tb.ie>0&&u._tb.ie<9){Uh.detachEvent('on'+Vh,Wh);}
else{if(Uh.removeEventListener){Uh.removeEventListener(Vh,Wh,false);}
else if(Uh.detachEvent){Uh.detachEvent('on'+Vh,Wh);}}},getXHR:function(){var Xh=null;if(!u._qc){var ax=['Msxml2.XMLHTTP.6.0','Msxml2.XMLHTTP.3.0','Msxml2.XMLHTTP','Microsoft.XMLHTTP'];for(var i=0;i<ax.length&&!Xh;i++){try{Xh=new u._rc(ax[i]);}
catch(e){}}}
else{Xh=new u._qc();}
return Xh;},_Qc:function(){var c=u._ac(u._sc);if(c){var p=c.split('|');if(p.length>0){return parseInt(p[0],10);}}
return 0;},updateLatencyCookie:function(Yh){var Zh=u._bc(u._sc);var $h=0;var ai=[];var di=0;if(Zh&&(Zh.length>0)){var fi=Zh.split('|');if(fi.length>1){di=fi.length-1;}
if(di>9){di=9;}
for(var i=1;i<=di;i++){$h+=parseFloat(fi[i]);ai[i+1]=fi[i];}}
$h+=Yh;di++;ai[0]=parseInt($h/di,10);ai[1]=Yh;u._bc(u._sc,ai.join('|'));},_Rc:function(o){try{var gi=o.tagUrn;if(gi&&gi.indexOf("schemas-microsoft-com:vml")!=-1){return true;}
var hi=o.tagName;if(hi&&hi=="shape"){return true;}}
catch(e){return true;}
return false;},_pb:function(){return new Date().getTime();},_la:function(){var i;for(i=0;i<u._xc.length;i++){var li=u._xc[i];u._Pc(li._Mc,li._Nc,li._Oc);}
u._xc=null;u._Hc=null;u._qc=null;u._rc=null;}};if(!dT_._ka){window.dtDebugUtils=u;dT_._ka=u;dT_._cc=u._cc;}})();(function(){var a={};var u=dT_._ka;var ii='BUTTON',_Tc='INPUT',_Uc='HIDDEN',_Vc='SUBMIT',_Wc='RESET',_Xc='IMAGE',_Yc='A',_Zc='IMG',_$c='FORM',_ad='HTML',_bd='BODY',_cd='HEAD',_dd='SELECT',_ed='unknown';function _fd(ji,ki,mi,ni){var ui=this;ui._gd=ji;ui._Ha=ki;ui._Ia=mi;ui._hd=ni;ui._Ga=function(){if(!ui._Fb){var an=u._xa(a._id(ui._gd));if(!an){an="Unguessable action name";}
an=an&&an.length?(an.length>100?an.substring(0,97)+'...':an):_ed;ui._Fb='';if(ui._Ha){ui._Fb=ui._Ha+' on "'+an+'"';}
else{ui._Fb=an;}}
return ui._Fb;};}
a._jd=true;a._kd=0;a._ld={_md:0,_nd:1,_od:2,_pd:3,_qd:4,foreach:function(oi,pi){var r=oi(this._md,pi);if(r){return r;}
r=oi(this._nd,pi);if(r){return r;}
r=oi(this._od,pi);if(r){return r;}
r=oi(this._pd,pi);if(r){return r;}
r=oi(this._qd,pi);if(r){return r;}
return null;}};a.t=u._Bc;a._rd=function(qi){if(qi){var ri=qi.split('/');if(ri.length>0){var si=a.t(ri[ri.length-1]);if(si!==null){return si;}}}
return qi;};a._sd=a._rd(window.location.href);a._td=function(){for(var i=0;i<arguments.length;i++){var v=arguments[i];if(v&&a.t(v)){return a.t(v);}}
return null;};a._ud=function(vi){if(vi){var wi=vi.split('/');if(wi.length>0){return wi[wi.length-1].split('.')[0];}}
return null;};a._vd=function(id){if(id){var xi=document.getElementsByTagName('LABEL');for(var i=0;i<xi.length;i++){if(xi[i].htmlFor==id){var l=xi[i];return a._td(l.innerText,l.textContent);}}}
return null;};a._wd=function(o){if(!o){return null;}
var on=o.nodeName?o.nodeName.toUpperCase():null;if(on!=_dd){return null;}
var yi=a._vd(o.id);var zi=a._td(yi,o.name,on);var Ai=null;if(!o.multiple){var Bi=o.options&&o.selectedIndex>-1?o.options[o.selectedIndex]:null;if(Bi){Ai=a._td(Bi.label,Bi.innerText,Bi.textContent);}}
return Ai?'['+zi+'] to value ['+Ai+']':zi;};a._xd=function(Ci,Di){if(!Di||Di.length<=0){return null;}
if(a._kd>20){return null;}
for(var i=0;i<Di.length;i++){var o=Di[i];if(u._tb.ie&&u._Rc(o)){return "VML Node";}
var on=o.nodeName?o.nodeName.toUpperCase():_ed;var ot=o.type?o.type.toUpperCase():null;var r=null;a._kd++;r=a._xd(Ci,o.childNodes);if(r){return r;}
a._kd--;switch(Ci){case a._ld._md:if(on==_Tc&&ot!=_Uc){var Ei=ot&&(ot==ii||ot==_Vc||ot==_Wc||ot==_Xc)?o.value:null;var Fi=a._vd(o.id);if(ot&&(ot==ii||ot==_Vc||ot==_Wc)){r=a._td(Ei,Fi);}
else{r=a._td(Fi,Ei);}}
if(!r){r=a._td(o.textContent,o.innerText);}
break;case a._ld._nd:if(on==_Tc&&ot!=_Uc||on==ii){var Gi=(ot&&ot==_Xc)?o.alt:null;r=a._td(o.name,o.title,Gi);}
break;case a._ld._od:if(on==_Tc&&ot==_Xc){r=a._ud(o.src);}
else if(on==_Yc){r=a._td(o.title,a._rd(o.href));}
else if(on==_Zc){r=a._td(o.name,o.title,o.alt,a._ud(o.src));}
else if(on==_$c){r=a._td(o.name,o.id,o.action);}
if(!r){r=a._td(o.title,o.data,o.wholeText,o.id);}
break;case a._ld._pd:r=o.className;break;case a._ld._qd:if(on==_Tc&&ot!=_Uc){r=_Tc+': '+ot;}
else if(on==_Yc){r='LINK';}
else{r=on;}
break;}
if(r){return r;}}
return null;};a._id=function(o){if(u._tb.ie&&u._Rc(o)){return "VML Node";}
if(typeof o=='string'){return o;}
if(o.attributes){var Hi=o.attributes["data-dtName"];if(Hi&&Hi.value){return Hi.value;}}
var on=o.nodeName?o.nodeName.toUpperCase():_ed;if(on==_ad||on==_bd||on==_cd){return 'Page: '+a._sd;}
if(on==_dd){return a._wd(o);}
var r=a.t(a._td(o.innerText,o.textContent));if(r){return r;}
a._kd=0;return a._ld.foreach(a._xd,[o]);};a._yd=function(Ii){if(Ii){a._Rb(Ii);}};a._zd=function(Ji){return function(e){a._Ad(Ji,e||window.event);};};a._Bd=function(c){var Ki=[[13,'<RETURN>'],[9,'<TAB>'],[8,'<BACKSPACE>'],[127,'<DELETE>'],[27,'<ESCAPE>'],[33,'<PAGE UP>'],[34,'<PAGE DOWN>'],[116,'<F5>']];for(var i=0;i<Ki.length;i++){if(Ki[i][0]==c){return Ki[i][1];}}
var r=String.fromCharCode(c);if(r>='a'&&r<='z'||r>='A'&&r<='Z'||r>='0'&&r<='9'){return r;}
return c;};a._Cd=function(e){var ev=e||window.event;var t='keypress '+a._Bd(ev.keyCode?ev.keyCode:ev.charCode);a._Ad(t,ev);};a._Ad=function(Li,e){var Mi=null;if(e.target){Mi=e.target;}
else if(e.srcElement){Mi=e.srcElement;}
var Ni=a._Qb(Mi,Li,'detection');u._Ya(function(){a._yd(Ni);},30);};a._Dd=function(Oi,Pi){var p=Pi.parentNode;while(p){if(p==Oi){return true;}
p=p.parentNode;}
return false;};a._Ea=function(){try{if(a._Ed){var Qi=a._Ed;var c=a._Ed._Fd;while(c){if(c._gd!=Qi._gd&&a._Dd(Qi._gd,c._gd)){Qi=c;}
c=c._Fd;}
return Qi;}
else{return null;}}
catch(e){return null;}};a._Sb=function(Ri){a._jd=Ri;if(!Ri){a._Gd();}};a._Gd=function(){var p=a._Ed;while(p){p._gd=null;p=p._Fd;}
a._Ed=null;};a._Qb=function(Si,Ti,Ui){var ui=new _fd(Si,Ti,dT_._ka._pb(),Ui);if(a._jd){ui._Fd=a._Ed;if(ui._Fd){ui._Fd._Hd=ui;}
a._Ed=ui;}
return ui;};a._Rb=function(Vi){if(a._Ed){var Wi=a._Ed;while(Wi._Fd&&(Wi!==Vi)){Wi=Wi._Fd;}
if(Wi===Vi){Wi._gd=null;if(Wi._Hd){Wi._Hd._Fd=Wi._Fd;}
else{a._Ed=Wi._Fd;}
if(Wi._Fd){Wi._Fd._Hd=Wi._Hd;}}}};a._Id=function(Xi,Yi,Zi){var c=false;if(Zi&&a._sa._Jd){for(var i=0;i<a._sa._Jd.length;i++){if(a._sa._Jd[i]==Zi){c=true;}}}
if(!c){u._ib(document,Xi,Yi);}};a.init=function($i){a._sa=$i;a._Id('click',a._zd('click'),'clk');a._Id('mousedown',a._zd('click'),'mdw');a._Id('mouseup',a._zd('click'),'mup');a._Id('dblclick',a._zd('dblclick'),'dcl');a._Id('keydown',a._Cd,'kyd');a._Id('keyup',a._Cd,'kyu');a._Id('scroll',a._zd('scroll'),'scr');a._Id('touchstart',a._zd('touch'),'tcs');a._Id('touchend',a._zd('touch'),'tce');if(a._sa.ade){var aj=a._sa.ade.split(',');if(aj&&aj.length>0){for(var i=0;i<aj.length;i++){a._Id(aj[i],a._zd(aj[i]),null);}}}};a._ha=function(){if(a._Ed){var bj=a._Ed;while(bj._Fd){if(bj===userInputObj){bj._gd=null;}
bj=bj._Fd;}}
a._Ed=null;a._Gd();};if(!dT_._ja){dT_._ja=a;}})();(function(){var m={};var u=dT_._ka;m._Kd=[];m._Ld=[];m._Md=[];m._Nd=0;m._Od=[];m._Pd=[];m._Qd=function(cj,dj,ej,fj,gj,hj){var ij={_Rd:ej,_Sd:fj,_Ha:cj,_Fb:dj,_Td:gj,next:[],_Ud:null,_Vd:null,_Wd:null,_Xd:null,_Yd:null,_Zd:null,add:function(jj){if(jj&&jj._Fb){u._Cc(ij.next,jj);}
else{}}};if(hj){ij._Eb=getWebSocketRequestID();}
if(!m._Pd[ij._Fb]){m._Pd[ij._Fb]=1;}
else{m._Pd[ij._Fb]++;ij._Yd=ij._Fb;ij._Zd=m._Pd[ij._Fb];ij._Fb+='#'+ij._Zd;}
return ij;};function getWebSocketRequestID(){return rand(1,2147483647);}
function rand(kj,lj){return Math.floor(Math.random()*(lj-kj+1))+kj;}
m._$d=function(mj,nj){if(mj._Xd){var oj=[];var pj=[];pj[0]='0';pj[1]=mj._Xd;pj[2]=mj._Wd;oj[0]=pj.join('|');oj[1]=m._ae(mj,1,nj);return oj.join(',');}
else{return m._ae(mj,1,nj);}};m._ae=function(qj,rj,sj){if(!qj._Td){qj._Td=u._Ac('*').length;}
var tj=[];if(qj.next&&(qj.next.length>0)){for(var i=0;i<qj.next.length;i++){tj[i+1]=m._ae(qj.next[i],rj+1,sj);}
if(sj){var uj=qj.next[qj.next.length-1];if(!uj._Sd){qj._Sd=undefined;}
else if(qj._Sd&&uj._Sd>qj._Sd){qj._Sd=uj._Sd;}}}
var vj=[];vj[0]=rj.toString();vj[1]=u._ec(qj._Yd?qj._Yd:qj._Fb);vj[2]=qj._Zd?qj._Zd:'-';vj[3]=u._ec(qj._Ha);vj[4]=qj._Rd;vj[5]=qj._Sd?qj._Sd:0;vj[6]=qj._Td;if((rj==1)&&qj._be){vj[7]=qj._be;}
if(qj._Eb){if(!vj[7]){vj[7]="-";}
vj[8]=qj._Eb;}
tj[0]=vj.join('|');if(tj.length>1){return tj.join(',');}
return tj[0];};m._ce=function(wj){m._de=null;if(m._ee){var xj=m._ee._Od;m._de=xj[xj.length-1];if(m._de){wj._Xd=m._de._Fb;if(m._de._be){m._de._be++;}
else{m._de._be=1;}}}};m._qa=function(){var yj="";for(var i in m._Od){if(m._Od.hasOwnProperty(i)){yj=((yj)?(yj+","):(yj));yj+=m._$d(m._Od[i],false);}}
return yj;};m._pa=function(zj,Aj){var Bj='';var Cj=0;if(zj){Cj=m._Kd.length;m._Od=[];}
else{Cj=m._Kd.length-m._Od.length;}
if(Cj>0){if(m._fe){if(m._fe._ge){Bj='d|'+m._fe._Fb+'|'+m._fe._Ha+'|'+m._fe._ua+'|'+m._fe._Rd+'|'+m._fe._he+'|'+m._fe._ie;}
else{Bj='s|'+m._fe._Fb+'|'+m._fe._Ha+'|'+m._fe._ua+'|'+m._fe._Rd;}
if(!Aj){m._fe=null;}}
for(var i=0;i<Cj;i++){var Dj=m._$d(m._Kd[i],true);if(Dj.length>0){if(Bj.length>0){Bj+=',';}
Bj+=Dj;}
else{break;}}
m._Kd=[];for(var j in m._Od){if(m._Od.hasOwnProperty(j)){u._Cc(m._Kd,m._Od[j]);}}}
return Bj;};m._qb=function(Ej,Fj,Gj,Hj,Ij,Jj){var Kj=m._Qd(Ej,Fj,Gj,Hj,Ij);return m._je(Kj,Jj);};m._je=function(Lj,Mj){var pa;if(!Mj){pa=m._ke;}
else{pa=m._Db(Mj);}
if(pa){pa.add(Lj);return false;}
else{m._ce(Lj);u._Cc(m._Kd,Lj);return true;}};m._Vb=function(Nj,Oj,Pj,Qj){var Rj=m._Qd('_rv_',Nj+'='+Oj,Pj,Pj,0);m._je(Rj,Qj);m._mb();};m._Wb=function(Sj,Tj,Uj,Vj){var Wj=m._Qd('_rs_',Sj+'='+Tj,Uj,Uj,0);m._je(Wj,Vj);m._mb();};m._le=function(){var Xj=u._ac('dtSa');u._bc('dtSa','-');if(Xj&&Xj!='-'){var Yj=Xj.split('|');if(Yj.length==7){var a={_ge:Yj[0]=='true',_Ha:Yj[1],_Fb:Yj[2],_Rd:Yj[3],_ua:Yj[4],_he:Yj[5],_ie:Yj[6]};if(!document.referrer||(a._he==u._ec(document.referrer))||(a._he==u._ec(document.location))){m._fe=a;m._me=a;}
else{}}}};m._Kb=function(){return m._ke;};m._Cb=function(){return m._ne?m._ne:m._ke;};m._Hb=function(Zj,$j,ak,bk){return m._oe(Zj,$j,ak,null,bk);};m._oe=function(ck,dk,ek,fk,gk){var a=m._Qa(ck,dk,ek,fk,gk);a._pe=1;m._Ld[a._Fb]=a;return a._Fb;};m._Gb=function(hk,ik,jk,kk,lk){var mk=m._Ld[hk];var nk;if(mk){mk._pe++;nk=mk._Fb;}
else if(m._ke){nk=m._oe(ik,jk,kk,m._ke._Fb,lk);}
return nk;};m._Mb=function(ok){var pk=0;var a=m._Ld[ok];if(a){a._pe--;pk=a._pe;if(pk<=0){m._Ub(ok);m._Ld[ok]=null;delete m._Ld[ok];m._mb();}}
return pk;};m._Lb=function(){var qk=0;for(var a in m._Ld){if(a&&m._Ld.hasOwnProperty(a)){try{qk+=m._Ld[a]._pe;}catch(e){}}}
return qk;};m._qe=function(rk,sk){if(rk){var tk=null;for(var i=0;i<rk.length;i++){var a=rk[i];if(a._Fb==sk||a._Yd&&a._Yd==sk){return a;}
if(a.next){tk=m._qe(a.next,sk);if(tk!==null){return tk;}}}}
return null;};m._Db=function(uk){var r=null;if(m._Kd){r=m._qe(m._Kd,uk);}
return r;};m._Qa=function(vk,wk,xk,yk,zk){m._$a._ab();if(!xk){xk=dT_._ka._pb();}
var Ak=m._Qd(wk,vk,xk,null,null,zk);if(typeof yk=='boolean'&&yk){yk=m._ke;}
if(!yk){m._re(Ak);m._se(Ak);}
else{var pa=null;if(typeof yk=='string'){pa=m._Db(yk);}
else if(typeof yk=='object'){pa=yk;}
else{pa=m._ke;}
if(pa){pa.add(Ak);m._re(Ak);for(var i in m._Od){if(m._Od.hasOwnProperty(i)){if(m._Od[i]&&m._Od[i]._Ud>Ak._Rd+10000){m._Od[i]._Ud=Ak._Rd+10000;}}}}
else{}}
return Ak;};m._Ub=function(Bk,Ck,Dk){if(!Ck){Ck=dT_._ka._pb();}
var Ek=[];if(m._Kd){for(var i=0;i<m._Kd.length;i++){Ek[i]=m._te(m._Kd[i],Bk,Ck,Dk);}}
var Fk=false;for(var j=0;j<m._Kd.length;j++){if(!Ek[j]){m._me=null;var Gk=[];for(var k in m._Od){if(m._Od.hasOwnProperty(k)){var Hk=m._Od[k];if(Hk._Fb===m._Kd[j]._Fb&&Hk._Ha===m._Kd[j]._Ha){u._Cc(Gk,k);}else{if(m._de){var Ik=m._ee._Od;if(parent&&(Ik[Ik.length-1]==m._de)){Hk._Wd='S';}
else{Hk._Wd='A';}
m._de=null;}}}}
for(var l=0;l<Gk.length;l++){u._Dc(m._Od,Gk[l]);}}else{Fk=Ek[j];}}
if(!Fk){m._mb();}
m._re(Fk);};m._te=function(Jk,Kk,Lk,Mk){var Nk;if((Jk._Yd&&(Jk._Yd==Kk))||(Jk._Fb==Kk)){Jk._Sd=Lk;if(Mk){Jk._Rd=Mk;}
Jk._Td=u._Ac('*').length;}
else if(!Jk._Sd){Nk=Jk;}
if(Jk.next&&(Jk.next.length>0)){for(var i=1;i<=Jk.next.length;i++){var Ok=m._te(Jk.next[Jk.next.length-i],Kk,Lk,Mk);if(Ok){Nk=Ok;}}}
return Nk;};m._re=function(Pk){if(typeof Pk==='undefined'||Pk._Fb==='_load_'){m._ne=Pk;}
if(m._ke!=Pk){m._ke=Pk;if(Pk){m._Ma._ue(m._ua,Pk._Fb);}
else{m._Ma._Na(m._ua);}}};m._se=function(Qk){m._ce(Qk);u._Cc(m._Od,Qk);m._ke=Qk;u._Cc(m._Kd,Qk);Qk._Ud=Qk._Rd+10000;Qk._Vd=100;u._Ya(m._ve,5000);};m._ve=function(){var Rk=false;var Sk=[];for(var i in m._Od){if(m._Od.hasOwnProperty(i)){var Tk=m._Od[i];if(Tk._Vd>0){if(dT_._ka._pb()>Tk._Ud){Tk._Ud+=60000;u._Cc(Sk,Tk);}
Rk=true;}}}
if(Sk.length>0){m._lb(true,true,true,false);}
for(var j=0;j<Sk.length;j++){Sk[j]._Vd--;}
if(Rk){u._Ya(m._ve,1000);}};m._we=function(){var s=document.location.href;var p=s.indexOf('#');if(p>=0){s=s.substr(0,p);}
return s;};m._Fa=function(Uk,Vk,Wk){var Xk=m._ya();if(!Xk&&Uk&&Vk&&Wk){u._bc('dtSa','true|'+u._ec(Vk)+'|'+u._ec(Uk)+'|'+Wk+'|'+m._ua+'|'+u._ec(m._we())+'|'+u._Ec(document.title));}
else{var Yk=m._me;if(Xk&&Yk){u._bc('dtSa','false|'+Yk._Ha+'|'+Yk._Fb+'|'+dT_._ka._pb()+'|'+Yk._ua+'|'+u._ec(m._we())+'|'+u._Ec(document.title));m._me=null;}
else if(m._ke&&m._ke._Fb!='_load_'){u._bc('dtSa','false|'+u._ec(m._ke._Ha)+'|'+u._ec(m._ke._Fb)+'|'+dT_._ka._pb()+'|'+m._ua+'|'+u._ec(m._we())+'|'+u._Ec(document.title));}}};m._Ob=function(Zk){u._Cc(m._Md,Zk);m._Nd++;};m._Pb=function($k){m._Nd--;u._Ya(function(){var al=-1;var i=m._Md.length-1;while(al==-1&&i>=0){if(m._Md[i]==$k){al=i;}
i--;}
if(al!=-1){if(al==m._Md.length-1){m._Md.pop();}
else{m._Md.splice(al,1);}}},0);};m._ya=function(){if(m._Nd>0){var l=m._Md.length;if(l>0){return m._Md[l-1];}}
return null;};m._ab=function(bl,cl,dl,el,fl,gl,hl){u=bl;m._ee=cl;m._ua=dl;m._$a=el;m._mb=fl;m._lb=gl;m._Ma=hl;m._le();};if(!dT_._oa){dT_._oa=m;}})();(function(){var c={};var u=dT_._ka;c.requestId=null;c.responseId="0";c.checkScriptsTimeout=false;c.checkImagesEnabled=false;c._xe=undefined;c._ye="";c.nottfb=false;c.ridPath=null;c.reportUrl='dynaTraceMonitor';c._nb=5000;c._ze=function(il,jl){if(il=='rid'){c.requestId=jl;}
else if(il=='domain'){u._Fc=jl;}
else if(il=='reportUrl'){c.reportUrl=decodeURIComponent(jl);}
else if(il=='doNotDetect'){var kl=jl.split(',');c._Jd=kl;}
else if(il=='sst'){c._nb=parseInt(jl,10);}else if(il=='spc'){u._vc+=jl;}
else{c[il]=jl;}};c._fc=function(ll){if(!ll||ll.length!=1){return false;}
return c._xe===undefined||c._xe.indexOf(ll)!=-1;};c._gc=function(ml){if(c._fc(ml)&&c._ye.indexOf(ml)==-1){c._ye+=ml;return true;}
else if(c._fc(ml)){var nl='Module "'+ml+'" already enabled!';if(typeof window.dT_!='undefined'){if(typeof console!='undefined'){console.log('WARNING: '+nl);}}}
return false;};c._Ae=function(ol,ql){if(ol){var rl=new RegExp('dtagent(dbg){0,1}[0-9]{2}_[a-zA-Z_0-9]*_[0-9]{4}');var sl=rl.exec(ol);if(sl){var tl=sl[0];var ul=tl.split('_');c._xe=ul[1];}
else{c._xe=undefined;}}
if(ql){var vl=ql.split('|');for(var j=0;j<vl.length;j++){var p=vl[j].indexOf('=');if(p==-1){c._ze(vl[j],true);}
else{var wl=vl[j].substring(0,p);var xl=vl[j].substring(p+1,vl[j].length);c._ze(wl,xl);}}}};c._ab=function(){var yl=u._Ac('script');if(yl.length>0){var zl;for(var j=yl.length-1;j>=0;j--){zl=yl[j];if((zl.src.search('dtagent')>=0)&&zl.attributes){var Al=zl.attributes.getNamedItem('data-dtconfig');if(Al&&Al.value){c._Ae(zl.src,Al.value);}
break;}}}};if(!dT_._sa){dT_._sa=c;}})();(function(){dT_._ra=function(){var m=this;m.monitorUrl=null;m._Be=[];m.a=function(k,v){m._Be.push(k);m._Be.push('=');m._Be.push(v);m._Be.push('$');};m.l=function(){var Bl=0;for(var i=0;i<m._Be.length;i++){for(var j=0;j<m._Be[i].length;j++){Bl++;}}
return Bl;};m.getSignals=function(){var Cl=m.monitorUrl?m.monitorUrl:'dynaTraceMonitor';var l=dT_._ka._tb.ie?1500:7000;if(dT_._sa.msl){l=Math.min(l,parseInt(dT_._sa.msl,10));}
var Dl=[];var s=m._Be.join('');var El=((s.length%l)===0)?Math.floor(s.length / l) : Math.floor(s.length / l)+1;var Fl;var Gl=dT_._ka._pb();var j=0;if(El>1){if(El<100){for(var i=0;i<El;i++){var id='sid='+Gl+'&p'+(i+1)+'_'+El+'=';if(j+l<=s.length){Fl=s.slice(j,j+l);if(Fl.charAt(Fl.length-1)=='%'&&s.length>=(j+l+1)){Fl+=s.charAt(j+l);Fl+=s.charAt(j+l+1);j+=2;}
if(Fl.charAt(Fl.length-2)=='%'&&s.length>=(j+l+2)){Fl+=s.charAt(j+l);j+=1;}}
else{Fl=s.slice(j);}
Dl.push(Cl+'?'+id+Fl);j+=l;}}
else{return null;}}
else{Dl.push(Cl+'?'+s);}
return Dl;};};})();(function(){var m={};m._ka=null;m._za=function(Hl,Il,Jl){var Kl=dT_._ka._pb();Hl.a('time',Kl);var r=Hl.getSignals();var Ll=true;var bi=m._ka._tb;var Ml=bi.ie;var Nl=bi.ch;if(Jl){if(bi.sf||bi.op){Ll=false;}
if(bi.ff&&(r.length>1||dT_._sa.sffs||bi.ff>=18)){Ll=false;}
if(Ml&&(Ml<9||dT_._sa.sies)){Ll=false;}
if(bi.msf||bi.ab){Ll=false;}
if(Nl&&(Nl>22)){Ll=false;}}
var Ol=false;if(Ml&&r.length<=1&&Ml<=8){Ol=true;}
if(Nl&&r.length<=1){Ol=true;}
var Pl=function(Ql){Ql.onreadystatechange=function(){if(this.readyState==4){if(this.status==200){var Rl=dT_._ka._pb()-Kl;if(Il){Il(Rl);}}}};};if(r!==null){if(Ol){var Sl=document.createElement('img');if(Il){Sl.onerror=function(){Il(dT_._ka._pb()-Kl);};}
Sl.setAttribute('src',r[0]);}else{for(var i=0;i<r.length;i++){var Tl=3;while(Tl>0){try{var Ul=m._ka.getXHR();Kl=dT_._ka._pb();Pl(Ul);Ul.open('POST',r[i],Ll);Ul.send(null);Tl=0;}catch(e){Tl--;}}}
if((Nl&&Nl<=22)||(bi.ff&&r.length>1)){m._Ce(25);}}}};m._Ce=function(Vl){var Wl=dT_._ka._pb();while((dT_._ka._pb()-Wl)<Vl){}};m.init=function(Xl){m._ka=Xl;};if(!dT_._Aa){dT_._Aa=m;}})();(function(){var u=dT_._ka,agentStartTime=u._pb(),timing=null;if(typeof performance!='undefined'&&performance.timing&&(!u._tb.ff||u._tb.ff>9)){timing=performance.timing;}
dT_._ma={_Ab:0,_Ra:function(){if(timing){if(timing.redirectStart>0){return(timing.navigationStart+60*1000)>timing.redirectStart?timing.navigationStart:timing.redirectStart;}
else{return(timing.navigationStart+60*1000)>timing.fetchStart?timing.navigationStart:timing.fetchStart;}}
return agentStartTime;},_fb:function(){return timing?timing.loadEventStart:0;},_eb:function(){return timing?timing.loadEventEnd:0;},_ha:function(){timing=null;}};})();(function(){var h={};h._De=function(Yl,Zl,$l){if(!h._Ee){h._Ee=true;var am=null;try{if(typeof(Yl)=='object'){if(Yl.srcElement){if(Yl.srcElement.outerHTML&&(Yl.srcElement.outerHTML.length<200)){am=document.URL.split('#')[0]+"[-]: Error at '"+Yl.srcElement.outerHTML+"'";}
else{am=document.URL.split('#')[0]+"[-]: Error at tag: '"+Yl.srcElement.tagName+"'";}}
else{am='unknown error';}}
else{if(typeof Zl==='undefined'||Zl=="undefined"){am=Yl;}
else{am=Zl+'['+$l+']: '+Yl;}}
if(am){var ua=h._ja._Ea();if(ua){am+=', user action: '+ua._Ga();}
h._Fe(am,'_error_');}}
catch(e){}
if(h._Ge&&h._Ge!=h._De){h._Ge(Yl,Zl,$l);}
h._Ee=false;}
return false;};h._He=function(){if(h._ka._tb.ie){h._Fe(event.type+':'+event.errorUrl+'['+event.errorLine+'] Code: '+event.errorCode+': '+event.errorMessage,'_error_');}
else{if(window.onerror!=h._De){h._Fe('window.onerror is overwritten - JavaScript error probably lost!','_warning_');h._ab();}}};h._ab=function(bm,cm,dm){if(bm){h._ka=bm;}
if(cm){h._ja=cm;}
if(dm){h._Fe=dm;}
if(!h._Ie){h._ka._ib(window,'error',h._He);h._Ie=true;}
if(!h._ka._tb.ie&&(window.onerror!=h._De)){if(window.onerror){h._Ge=window.onerror;}
window.onerror=h._De;}
h._ka._ib(window,'unload',function(){window.onerror=null;});};if(!dT_._$a){dT_._$a=h;}})();(function(){var p={},sessionCookieName='dtCookie',pageContextCookieName='dtPC',frameIdModulo=604800000,u=dT_._ka;function _Je(em){var f=em.split('_');var t=parseInt(f[0],10);var fm=dT_._ka._pb()%frameIdModulo;if(fm<t){fm+=frameIdModulo;}
return(t+1000*60*15>fm);}
function _Ke(gm){var hm=[];if(gm&&gm!='-'){var im=gm.split('|');for(var i=0;i<im.length;i++){var jm=im[i].split('#');if(jm.length==2&&jm[0]&&jm[1]){var km=jm[0];if(_Je(km)){hm.push({_ua:km,_Le:jm[1]});}}}}
return hm;}
function _Me(){var pc=u._$b(pageContextCookieName);return _Ke(pc);}
function _Ne(lm){var c='';if(lm){var mm=[];for(var i=0;i<lm.length;i++){if(i>0){mm.push('|');}
mm.push(lm[i]._ua);mm.push('#');mm.push(lm[i]._Le);}
c=mm.join('');}
if(!c){c='-';}
u._Yb(pageContextCookieName,c);}
p._jc=function(){return((dT_._ka._pb()%frameIdModulo)+'_'+Math.floor(Math.random()*1000));};p._Zb=function(){var nm=u._$b(sessionCookieName);if(nm){var p=nm.indexOf('|');if(p!=-1){nm=nm.substring(0,p);}}
return nm;};p._Pa=function(om,pm){var qm=_Me();if(!pm){pm='_load_';}
var rm={_ua:om,_Le:u._ec(pm)};qm.push(rm);_Ne(qm);};p._ue=function(sm,tm){var um=_Me();var vm=false;for(var i=0;i<um.length;i++){if(um[i]._ua==sm){um[i]._Le=u._ta(tm);vm=true;}}
if(!vm){um.push({_ua:sm,_Le:u._ta(tm)});}
_Ne(um);};p._Na=function(wm){var xm=_Me();if(xm.length>0){var ym=[];for(var i=0;i<xm.length;i++){if(xm[i]._ua!=wm){ym.push(xm[i]);}}
_Ne(ym);}};if(!dT_._Ma){dT_._Ma=p;}})();if(!dT_._wb){dT_._ab();}(function(){var zm={};zm._Oe=[];zm._Pe=false;zm._Qe=function(){var Am={};Am.height=10;if(dT_.gBI().ie){Am.width=140;}
else{Am.width=10;}
return Am;};zm._Re=function(Bm){if(!zm._Pe){zm._Oe.push(Bm);}
else{Bm(dT_.bwsW,dT_.bwsH);}};zm._Se=function(Cm,Dm){for(var i=0;i<zm._Oe.length;i++){zm._Oe[i](Cm,Dm);}};zm._Te=function(){var d=document;var de=d.documentElement;var w=0;var h=0;if(typeof(self.innerWidth)=='number'){w=self.innerWidth;h=self.innerHeight;}
else if(d&&(de.clientWidth||de.clientHeight)){w=de.clientWidth;h=de.clientHeight;}
else if(d.body&&(d.body.clientWidth||d.body.clientHeight)){w=d.body.clientWidth;h=d.body.clientHeight;}
if(w>0&&h>0){var aw=screen.availWidth;var ah=screen.availHeight;w=(w<aw)?w:aw;h=(h<ah)?h:ah;zm._Ue(w,h);}
else{var Em=zm._Qe();w=Math.max(w,Em.width);h=Math.max(h,Em.height);zm._Ue(w,h);}};zm._Ue=function(Fm,Gm){dT_.bwsW=Fm;dT_.bwsH=Gm;zm._Pe=true;zm._Se(Fm,Gm);};zm._Ve=function(){zm._Te();};dT_.all(zm._Ve);if(!dT_.abwsl){dT_.abwsl=zm._Re;}
var Hm=true;dT_.asl(function(Im,Jm){if(!Jm&&Hm){Hm=false;var Km=dT_.tdto();var Lm=function(Mm){if(Mm<0||Mm>=2147483647||isNaN(Mm)){return 0;}
return Mm;};if(Km){Im.a('w',Lm(Km.bwsW));Im.a('h',Lm(Km.bwsH));}
else{Im.a('w',Lm(dT_.bwsW));Im.a('h',Lm(dT_.bwsH));}}});})();(function(){var x={};var u=dT_._ka;u._hc(x,{_We:0,_Xe:0,_Ye:null,_Ze:function(Nm){var Om=0;var Pm=u._Ac("img");for(var i=0;i<Pm.length;i++){if(Pm[i].src!=""){Om+=Nm(Pm[i]);}}
var Qm=u._Ac("input");for(i=0;i<Qm.length;i++){if((Qm[i].type=='image')&&(Qm[i].src!="")){Om+=Nm(Qm[i]);}}
return Om;},_Jb:function(){x._Ze(function(Rm){Rm._$e=true;});},_af:function(){if(x._bf){for(var i=0;i<x._bf.length;i++){x._bf[i]();}
x._bf=null;}},_cf:function(){x._Xe++;if(x._df()){x._af();}},_df:function(){return x._Xe===x._We;},_ef:function(Sm){if(!Sm._$e){Sm._$e=true;if(u._zc(Sm)){return;}
u._ib(Sm,'load',x._cf);u._ib(Sm,'error',x._cf);Sm.src=Sm.src;x._We++;}},_Nb:function(Tm){x._Ze(x._ef);if(!x._bf){x._bf=[];}
u._Cc(x._bf,Tm);if(x._df()){x._af();}}});var Um=dT_.cfg('wi');if(Um){x._Tb=(Um=='all');dT_._Ib=x;}})();(function(){var ac={INSTR:'instr'};ac._aa={_ba:[],_ca:{_da:'onchange',_ea:'onclick',_fa:'onmouseup',_ga:'onblur',_ha:'touchstart',_ia:'touchend'},_ja:{_ka:'object',_la:'dT_handler'},_ma:function(o,Da){var me=this;o[me._na(Da)]=true;if(!o[me._ja._la]){var Ea=me._ba.length;me._ba[Ea]=o;o[me._ja._la]=true;}},_na:function(Fa){var me=this;return me._ja._la+Fa;},_oa:function(){var me=this;if(me._ba){for(var i=0;i<me._ba.length;i++){var o=me._ba[i];if(o.onclick){o.onclick.toString=null;}
o.onclick=null;if(o.onmouseup){o.onmouseup.toString=null;}
o.onmouseup=null;if(o.onchange){o.onchange.toString=null;}
o.onchange=null;if(o.onblur){o.onblur.toString=null;}
o.onblur=null;me._ba[i]=null;}
me._ba=null;}}};ac._pa=function(o,Ga,Ha,Ia){if(Ha===true){if(o[Ga]&&!o[ac._aa._na(Ga)]){ac._aa._ma(o,Ga);var Ja=o[Ga];o[Ga]=function(){var Ka=Ga.replace('on','');var ui=dT_.bi(o,Ia||Ka,Ka+' wrapper');var La=null;if(Ja){La=Ja.apply(this,arguments);}
dT_.st(function(){dT_.ei(ui);},30);return La;};if(ac._qa){o[Ga].toString=function(){if(Ja){return Ja.toString();}};}}}};ac._ra=function(){if(ac._sa||ac._ta||ac._ua||ac._va||ac._wa||ac._xa){if(typeof document.createTreeWalker=='function'&&typeof NodeFilter!='undefined'){var Ma=document.createTreeWalker(document,NodeFilter.SHOW_ALL,null,false);while(Ma.nextNode()){ac._ya(Ma.currentNode);}}
else{var Na=document.getElementsByTagName('*');var Oa=Na.length;if(!dT_.gBI().ie||dT_.gBI().ie>=9||Oa<ac._za()){for(var i=0;i<Oa;i++){ac._ya(Na[i]);}}
else{if(!ac._Aa){ac._Aa=true;dT_.pw("Document has "+Oa+" DOM nodes. Disabling instrumentation!");}}}}
else{}};ac._ya=function(o){try{ac._pa(o,ac._aa._ca._fa,ac._ta,'click');ac._pa(o,ac._aa._ca._ea,ac._sa);}
catch(e){}
for(var i=0;i<ac.wrappers.length;i++){try{if(ac.wrappers[i].length==3){ac._pa(o,ac.wrappers[i][0],ac.wrappers[i][1],ac.wrappers[i][2]);}
else{ac._pa(o,ac.wrappers[i][0],ac.wrappers[i][1]);}}
catch(e2){}}};ac._za=function(){var Pa=parseInt(dT_.cfg("mdn"),10);return isNaN(Pa)?5000:Pa;};ac._Ba=function(){ac._Ca=dT_.cfg(ac.INSTR);ac._sa=false;ac._ta=false;ac._qa=false;ac._ua=false;ac._va=false;ac._wa=false;ac._xa=false;var i=0;if(ac._Ca){var Qa=ac._Ca.split(',');for(i=0;i<Qa.length;i++){var f=Qa[i];if(f=='clk'){ac._sa=true;}
else if(f=='mup'){ac._ta=true;}
else if(f=='tos'){ac._qa=true;}
else if(f=='blr'){ac._ua=true;}
else if(f=='chg'){ac._va=true;}
else if(f=='tcs'){ac._wa=true;}
else if(f=='tce'){ac._xa=true;}
else{}}}
ac.wrappers=[[ac._aa._ca._ga,ac._ua],[ac._aa._ca._da,ac._va]];dT_.ael(window,'unload',ac._aa._oa);dT_.ail(ac._ra);};if(dT_.smbi('a')){ac._Ba();}})();(function(){var b={};b._aa=-1;b._ba=0;b._ca=-1;b._da=0;b._ea='';b._fa=0;b._ga=0;b._ha=0;b._ia=-1;var ra=dT_.gDtc();b._ja=(ra&&ra.substr(ra.length-2)=="_m");b._ka='dtbw';b._la=function(){var sa=(new Date()).getTime();var ta=b._ea+'dynaTraceMonitor?bwstate='+b._ba+'&unique='+sa;if(dT_.gBI().ie){ta+='&ie='+dT_.gBI().ie;}else if(dT_.gBI().o){ta+='&o='+dT_.gBI().o;}
var ua=document.createElement('img');ua.setAttribute('src',ta);var va=false;b._ia=(new Date()).getTime();ua.onload=ua.onreadystatechange=function(){if(!va&&(!this.readyState||this.readyState=='complete')){va=true;b._ma();}};var wa=false;ua.onerror=function(){if(!wa&&b._ba==1){wa=true;b._ma();}};};b._ma=function(){var xa=(new Date()).getTime();var ya=false;b._ca=xa-b._ia;if(b._ba===0){b._da=b._ca/2;dT_.ulc(b._da);}
if(b._ba>=6||b._ca>100){b._ha=1;ya=true;}
b._na();b._ba++;if(ya){return;}
dT_.st(b._la,100);};b._oa=function(za){var Aa=za.toString();return Aa.substring(Aa.indexOf(' ')+1,Aa.indexOf('('));};b._pa=function(){if(b._ha&&(dT_.nw()-b._ia)<b._aa){return;}
dT_.st(b._la,100);};b._qa=function(){var Ba=dT_.lv(b._ka);if(Ba){var ps=Ba.split('|');lastCheckTime=ps[0];if((dT_.nw()-lastCheckTime)<b._aa&&ps.length==6){b._ia=ps[0];b._ba=ps[1];b._ca=isNaN(ps[2])?0:ps[2];b._da=isNaN(ps[3])?0:ps[3];b._ha=parseInt(ps[4],10);b._ga=parseInt(ps[5],10);}}};b._na=function(){dT_.sv(b._ka,b._ia+'|'+b._ba+'|'+b._ca+'|'+b._da+'|'+b._ha+'|'+b._ga);};var bw=dT_.cfg('bandwidth');if(bw&&dT_.tp()&&dT_.smbi('b')){if(b._ja){if(bw.indexOf('m')==-1){return;}
else{bw=bw.substr(0,bw.length-2);}}
b._aa=parseInt(bw,10)*1000;var Ca=dT_.cfg('reportUrl');if(Ca){var p=Ca.lastIndexOf("/");if(p>=0){b._ea=Ca.substring(0,p+1);}}
b._qa();dT_.asl(function(Da,Ea){if(!Ea&&b._ba>0&&b._ha&&!b._ga){Da.a('bw',b._ba+'_'+b._ca);b._ga=1;b._na();}});dT_.st(b._pa,2000);dT_.bwo=b;}})();(function(){if(!dT_.smbi('x')){return;}
var na=window,_ba=na.XMLHttpRequest,_ca=na.ActiveXObject,_da=na.document.all&&!na.opera;function synchronizeValues(oa){try{oa.responseText=oa._ea.responseText;}
catch(e){}
try{oa.responseXML=getXmlDocument(oa._ea);}
catch(e1){}
try{oa.status=oa._ea.status;}
catch(e2){}
try{oa.statusText=oa._ea.statusText;}
catch(e3){}}
function readyStateChange(pa){try{dT_.ec(pa._fa);pa.dispatchEvent({'type':"readystatechange",'bubbles':false,'cancelable':false,'timeStamp':new Date()+0});}
finally{dT_.lc(pa._fa);if(pa.readyState==4&&pa._fa){dT_.lx(pa._fa);pa._fa=null;}}}
function getXmlDocument(qa){var ra=qa.responseXML;if(_da&&ra&&!ra.documentElement&&qa.getResponseHeader("Content-Type").match(/[^\/]+\/[^\+]+\+xml/)){ra=new na.ActiveXObject("Microsoft.XMLDOM");ra.loadXML(qa.responseText);}
if(ra){if((_da&&ra.parseError&&ra.parseError.errorCode!==0)||(ra.documentElement&&ra.documentElement.tagName=="parsererror")){return null;}}
return ra;}
function cleanTransport(t){t._ea.onreadystatechange=function(){};delete t._ga;}
var sa=function(){var t=this;t._ea=_ba?new _ba():new _ca("Microsoft.XMLHTTP");t._ia=[];t.readyState=0;t._ja=-1;t.responseText=undefined;t.responseXML=null;t.status=0;t.statusText='';t.onreadystatechange=null;t.withCredentials=false;var ta=null;function _ka(){t.readyState=t._ea.readyState;synchronizeValues(t);if(t.readyState==4){cleanTransport(t);if(_da&&t._la){na.detachEvent("onunload",ta);}}
if(t._ja!=t.readyState){readyStateChange(t);t._ja=t.readyState;}}
t.open=t.Open=function(ua,va,wa,xa,ya){t._ma=false;if(arguments.length<3){wa=true;}
t._la=wa;if(_da){if(wa){ta=function(){if(t._ea.readyState!=4){cleanTransport(t);t.abort();}};na.attachEvent("onunload",ta);}}
if(wa){t._ea.onreadystatechange=_ka;}
if(t.onopen){t.onopen.apply(t,arguments);}
if(arguments.length>4){t._ea.open(ua,va,wa,xa,ya);}
else{if(arguments.length>3){t._ea.open(ua,va,wa,xa);}
else{t._ea.open(ua,va,wa);}}};t.send=function(za){t._fa=dT_.ex('Generic XHR');if(t.onsend){t.onsend.apply(t,arguments);}
if(za&&za.nodeType){za=na.XMLSerializer?new na.XMLSerializer().serializeToString(za):za.xml;if(!t._ga["Content-Type"]){t._ea.setRequestHeader("Content-Type","application/xml");}}
if(t.onloadstart){t._ea.onloadstart=function(){try{dT_.ec(t._fa);t.onloadstart.apply(t,arguments);}
finally{dT_.lc(t._fa);}};}
if(t.onloadend){t._ea.onloadend=function(){try{dT_.ec(t._fa);t.onloadend.apply(t,arguments);}
finally{dT_.lc(t._fa);}};}
if(t.onload){t._ea.onload=function(){try{dT_.ec(t._fa);t.onload.apply(t,arguments);}
finally{dT_.lc(t._fa);}};}
if(t.onerror){t._ea.onerror=function(){try{dT_.ec(t._fa);t.onerror.apply(t,arguments);}
finally{dT_.lc(t._fa);}};}
if(t.onprogress){t._ea.onprogress=function(){try{dT_.ec(t._fa);t.onprogress.apply(t,arguments);}
finally{dT_.lc(t._fa);}};}
t._ea.send(za);if(!t._la){_ka();}};t.abort=function(){if(t.onabort){t.onabort.apply(t,arguments);}
if(t.readyState>0){t._ma=true;}
t._ea.abort();cleanTransport(t);if(t._fa){dT_.lx(t._fa);t._fa=null;}};t.getAllResponseHeaders=function(){return t._ea.getAllResponseHeaders();};t.getResponseHeader=function(Aa){return t._ea.getResponseHeader(Aa);};t.setRequestHeader=function(Ba,Ca){if(!t._ga){t._ga={};}
t._ga[Ba]=Ca;return t._ea.setRequestHeader(Ba,Ca);};t.addEventListener=function(Da,Ea,Fa){var Ga=null;for(var i=0;i<t._ia.length;i++){Ga=t._ia[i];if(Ga[0]==Da&&Ga[1]==Ea&&Ga[2]==Fa){return;}}
t._ia.push([Da,Ea,Fa]);};t.removeEventListener=function(Ha,Ia,Ja){var Ka=null;for(var La=0;La<t._ia.length;La++){Ka=t._ia[La];if(Ka[0]==Ha&&Ka[1]==Ia&&Ka[2]==Ja){break;}}
if(Ka){t._ia.splice(La,1);}};t.dispatchEvent=function(Ma){var Na={'type':Ma.type,'target':t,'currentTarget':t,'eventPhase':2,'bubbles':Ma.bubbles,'cancelable':Ma.cancelable,'timeStamp':Ma.timeStamp,'stopPropagation':function(){},'preventDefault':function(){},'initEvent':function(){}};if(Na.type=="readystatechange"&&t.onreadystatechange){(t.onreadystatechange.handleEvent||t.onreadystatechange).apply(t,[Na]);}
for(var Oa=0;Oa<t._ia.length;Oa++){var Pa=t._ia[Oa];if(Pa[0]==Na.type&&!Pa[2]){(Pa[1].handleEvent||Pa[1]).apply(t,[Na]);}}};t.toString=function(){return '['+"XMLHttpRequest"+']';};};if(na.XMLHttpRequest){na.XMLHttpRequest=sa;}
if(na.ActiveXObject){na.ActiveXObject=function(Qa,Ra){if(Qa==="Microsoft.XMLHTTP"||Qa==="Msxml2.XMLHTTP.6.0"||Qa==="Msxml2.XMLHTTP.3.0"||Qa==="Msxml2.XMLHTTP"){return new sa();}
if(arguments.length==1){return new _ca(Qa);}
return new _ca(Qa,Ra);};}
dT_.ael(window,'unload',function(){sa=null;na=null;_ba=null;_ca=null;_da=null;});})();(function(){var f={};f._aa=[];f._ba=function(ka,la,ma){f._aa.push(dT_.ex('ice.jsfXhr',3));f._ca(ka,la,ma);};f._da=function(){var na=f._aa.shift();dT_.ec(na);var oa;try{oa=f._ea.apply(this,arguments);}
finally{dT_.lc(na);dT_.lx(na);}
return oa;};f._fa=function(){if(f._ga()){if(jsf.ajax.request!=f._ba){f._ca=jsf.ajax.request;jsf.ajax.request=f._ba;}
if(jsf.ajax.response!=f._da){f._ea=jsf.ajax.response;jsf.ajax.response=f._da;}}else if(f._ha()){if(!f._ia){f._ia=Ice.Ajax.RequestProxy;Ice.Ajax.RequestProxy=function(pa,b){var qa=dT_.ex('ice.1.8.ajax',3);var ra=new f._ia(pa,b);var sa=ra.responseCallback;ra.responseCallback=function(){dT_.ec(qa);var ta;try{ta=sa.apply(this,arguments);}
finally{dT_.lc(qa);if(pa.readyState==4){dT_.lx(qa);}}
return ta;};return ra;};}}};f._ga=function(){return!!((typeof jsf!='undefined')&&(typeof jsf.ajax!='undefined'));};f._ha=function(){return!!(typeof container!='undefined'&&typeof container.bridge!='undefined');};f._ja=function(){if(f._ga()||f._ha()){dT_.ail(f._fa);dT_.ti();}
else{}};if(dT_.smbi('i')){dT_.all(function(){f._ja();});}})();(function(){var j={};j._aa=function(ka,la){var lx=false;function checkLx(ma){if(lx===false){lx=true;dT_.st(function(){dT_.lx(ma);},0);}}
if(typeof ka==="object"){la=ka;}
la=la||{};var na=dT_.ex('jQuery.ajax',3);var oa;if((la.async===undefined)||la.async){var pa=la.complete;la.complete=function(qa,ra){if(ra!="success"){dT_.pw('jQuery reported "'+ra+'"');}
dT_.ec(na);var sa=undefined;if(pa){if(typeof pa=='function'){sa=pa.apply(this,arguments);}else if(pa.length){for(var i=0;i<pa.length;i++){pa[i].apply(this,arguments);}}}
dT_.lc(na);checkLx(na);return sa;};var ta=la.success;if(ta){la.success=function(ua,va,wa){dT_.ec(na);var xa=undefined;if(typeof ta=='function'){xa=ta.apply(this,arguments);}else if(ta.length){for(var i=0;i<ta.length;i++){ta[i].apply(this,arguments);}}
dT_.lc(na);checkLx(na);return xa;};}
var ya=la.error;if(ya){la.error=function(za,Aa,Ba){dT_.ec(na);var Ca=ya.apply(this,arguments);dT_.lc(na);checkLx(na);return Ca;};}
oa=j._ea.apply(this,arguments);}
else{dT_.ec(na);oa=j._ea.apply(this,arguments);dT_.lc(na);checkLx(na);}
return oa;};j._fa=function(Da,Ea){if(Da){var Fa=function(e){var Ga=null;if(e.currentTarget){Ga=dT_.bi(e.currentTarget,Ea,'jquery');}
else if(e.srcElement){Ga=dT_.bi(e.srcElement,Ea,'jquery');}
var Fa=Da.apply(this,arguments);if(Ga){dT_.st(function(){dT_.ei(Ga);},50);}
return Fa;};Fa._ga=true;return Fa;}else{return Da;}};j._ha=function(Ha,Ia){var Ja=Ha[Ia];if(Ja){for(var i=0;i<Ja.length;i++){if(Ja[i].handler&&!Ja[i].handler._ga){Ja[i].handler=j._fa(Ja[i].handler,Ia);}}}};j._ia=function(Ka,La,Ma){var Na=j._ja.apply(this,arguments);if(typeof Na!='undefined'&&Na){if(La=='events'){j._ha(Na,'click');j._ha(Na,'mouseup');j._ha(Na,'mousedown');j._ha(Na,'keydown');j._ha(Na,'autocomplete');}}
return Na;};if(dT_.smbi('j')){dT_.all(function(){if(typeof jQuery!='undefined'){dT_.ti();j._ea=jQuery.ajax;jQuery.ajax=j._aa;j._ja=jQuery.data;jQuery.data=j._ia;dT_.ael(window,'unload',function(){if(j){if(typeof jQuery!='undefined'){jQuery.ajax=j._ea;jQuery.data=j._ja;}
j._ea=null;j._ja=null;j=null;}});}});}})();(function(){var ba=["redirectStart","redirectEnd","fetchStart","domainLookupStart","domainLookupEnd","connectStart","connectEnd","secureConnectionStart","requestStart","responseStart","responseEnd","domLoading","domInteractive","domContentLoadedEventStart","domContentLoadedEventEnd","domComplete","loadEventStart","loadEventEnd"];var ca="cdefghijklmnopqrstuvwxyz";var da=true;function _aa(ea){var fa=ea.timing||{};var ga=ea.navigation||{};var ha=fa.navigationStart;if(ha){var ia=["a",ga.type,"b",ha];var ja=ba.length;for(var i=0;i<ja;i++){var p=ba[i];var v=fa[p];if(v&&v>=ha){ia.push(ca.charAt(i));ia.push(v-ha);}}
return ia.join("");}
return null;}
if(dT_.smbi('n')){dT_.asl(function(ka,la){if(!la&&da){da=false;if(typeof performance!='undefined'){var ma=/Firefox[\/\s](\d+\.\d+)/.test(navigator.userAgent);if(ma){if(Number(RegExp.$1)<=9){ka.a('nt',"0");return;}}
var s=_aa(performance);if(s){ka.a('nt',s);}
else{ka.a('nt',"0");}}
else{ka.a('nt',"0");}}});}})();(function(){var ya={};ya._aa=0;ya._ba=0;ya._ca=false;ya._da=0;ya._ea=0;dT_.vi=0;ya._fa=0;ya._ga=null;ya._ha=function(za,Aa){var Ba={};if(document.getBoxObjectFor){var b=document.getBoxObjectFor(za);Ba.x=b.x;Ba.y=b.y;}
else if(za.getBoundingClientRect){var r=za.getBoundingClientRect();Ba.x=r.left;Ba.y=r.top;}
else{Ba.x=-1;Ba.y=-1;}
if(Aa&&window.self!=window.top){var Ca=ya._ia();var Da=ya._ja(Ca);Ba.x+=Da.x;Ba.y+=Da.y;}
return Ba;};ya._ka=function(){if(document.images.length>ya._da){ya._la();}
if(ya._ca){return;}
dT_.st(ya._ka,10);};ya._la=function(){var di=document.images;var Ea=ya._da===0?0:(ya._da-1);for(var i=Ea;i<di.length;i++){ya._ma(di[i]);}
ya._da=di.length;};ya._ma=function(Fa){dT_.ael(Fa,"load",ya._na);dT_.ael(Fa,"error",ya._na);dT_.ael(Fa,"abort",ya._na);};ya._na=function(Ga){var Ha=Ga.target||Ga.srcElement;var Ia=dT_.nw();dT_.abwsl(function(){ya._oa(Ha,Ia,Ga);});};ya._oa=function(Ja,Ka,La){if(dT_!=ya._ga){ya._ga.abwsl(function(Ma,Na){var Oa=ya._pa(Ja);var Pa=ya._ha(Ja,true);var Qa=ya._ga.iws(Ja,Pa);Oa&=Qa;ya._qa(Oa,Ka);});}
else{var Ra=ya._pa(Ja);ya._qa(Ra,Ka);}};ya._qa=function(Sa,Ta){if(Sa){dT_.vi++;}
if(Sa&&Ta>ya._ea){ya._ea=Ta;}};ya._ra=function(Ua){return Ua.x>=0&&Ua.x<=5&&Ua.y>=0&&Ua.y<=5;};ya._sa=function(Va,Wa,Xa){return Va.x<=0&&Va.y<=0&&(Va.x+Wa)>=0&&(Va.y+Xa)>=0;};ya._pa=function(Ya,Za){if(!Ya){return false;}
if(!Za){Za=ya._ha(Ya);}
if(ya._ra(Za)){return true;}
var tw=ya._ga.bwsW;var th=ya._ga.bwsH;var rw=Ya.width||Ya.scrollWidth;var rh=Ya.height||Ya.scrollHeight;if(ya._sa(Za,rw,rh)){return true;}
if(rw<0||rh<0||tw<0||th<0){return false;}
var tx=ya._aa;var ty=ya._ba;var rx=Za.x;var ry=Za.y;rw+=rx;rh+=ry;tw+=tx;th+=ty;return((rw<rx||rw>tx)&&(rh<=ry||rh>=ty)&&(tw<tx||tw>rx)&&(th<ty||th>ry));};ya._ta=function(){ya._ka();dT_.iws=ya._pa;ya._ga=dT_.tdto();};ya._ua=function(){if(ya._fa===0){ya._fa=dT_.nw();}
return ya._fa;};ya._va=function(){ya._ua();ya._ca=true;var $a=ya._ua();if(ya._ea===0||document.images.length===0){ya._ea=$a;}};ya._ja=function(ab){var bb=0;var cb=0;var db=ab;var eb=window.self;while(eb!==null&&ya._ga!=eb.dT_){bb+=db?db.offsetLeft:0;cb+=db?db.offsetTop:0;try{db=ya._ia(window.parent);eb=eb.parent;}
catch(e){eb=null;}}
var fb={};fb.x=bb;fb.y=cb;return fb;};ya._ia=function(gb){if(!gb){gb=window;}
if(ya._ga===dT_){return null;}
try{var hb=gb.parent.frames;for(var i=0;i<hb.length;i++){var ib=hb[i];if(ib!=gb){continue;}
return ib.frameElement;}
return null;}
catch(e){return null;}};ya._wa=function(){if(dT_===ya._ga){return true;}
var jb=ya._ia();if(jb===null){return(dT_.vi>0||window.frames.length===0);}
if(dT_.vi===0){return false;}
if(document.images.length===0&&window.frames.length>0){return false;}
pos=ya._ja(jb);return ya._ga.iws(jb,pos);};ya._xa=function(kb){var lb=dT_.lst();var mb=ya._ua();var nb=kb-lb;if(nb<=0){nb=mb-lb;}
if(nb<0||nb>=2147483647){nb=0;}
return nb;};var ob=true;if(dT_.smbi('p')){dT_.all(ya._va);ya._ta();dT_.asl(function(pb,qb){if(!qb&&ob){ob=false;var rb=ya._xa(ya._ea);var sb=ya._wa();if(sb){pb.a('p',rb);}}});}})();(function(){var ob=function(pb,qb){pb.push(qb);};var rb=function(){this._ba=null;this._ca=function(sb,tb){if(sb>tb){throw 'Error: Start('+sb+') must be before stop ('+tb+')';}
var ub={_da:sb,_ea:tb};var c=this._ba;var p=null;if(!c){this._ba=ub;ub._fa=null;}else{while(c&&sb>c._da){p=c;c=c._fa;}
if(p){ub._fa=p._fa;p._fa=ub;}else{ub._fa=this._ba;this._ba=ub;}}};this._ga=function(){var c=this._ba;while(c&&c._fa){while(c._fa&&c._ea>=c._fa._da){if(c._ea<=c._fa._ea){c._ea=c._fa._ea;}
c._fa=c._fa._fa;}
c=c._fa;}};this._ha=function(){this._ga();var vb=[];var c=this._ba;while(c){if(vb.length>0){ob(vb,'_');}
ob(vb,c._da);ob(vb,'_');ob(vb,c._ea);c=c._fa;}
var r=vb.join('');return r;};};var t={_ia:2000,_ja:30,_ka:500,_la:3,_ma:'i',_na:'s',_oa:'c',_pa:[],_qa:function(wb,xb){var ca=dT_.ca();var n=dT_.nw();for(var i=0;i<t._pa.length;i++){if(t._pa[i]._ra==xb){return;}}
ob(t._pa,{_sa:wb,_da:n,_ra:xb,_ta:ca?ca._ua:'-',_ea:0});},_va:function(yb,zb,Ab,Bb){for(var i=0;i<t._pa.length;i++){if(t._pa[i]._ra==yb){if(arguments.length>2&&Ab>0){t._pa[i]._da=Ab;}
if(arguments.length>3&&Bb>0){t._pa[i]._ea=Bb;}else{t._pa[i]._ea=dT_.nw();}
t._pa[i]._wa=zb;return;}}},_xa:function(a,b){var Cb=(a._ea-a._da);var Db=(b._ea-b._da);if(Cb<Db){return 1;}
if(Cb==Db){return 0;}
return -1;},_ya:function(v1,v2){return v1<v2?v1:v2;},_za:function(v1,v2){return v1>v2?v1:v2;},_Aa:function(){var Eb=dT_.lst();if(t._pa.length>0&&Eb>0){var Fb={};var i;for(i=0;i<t._pa.length;i++){var Gb=t._pa[i];if(Gb._ea===0){if(Gb._sa===t._ma){Gb._Ba=true;Gb._wa=false;Gb._ea=dT_.nw();}else{Gb._ea=Gb._da;Gb._wa=true;}}
var dm=dT_.gh(Gb._ra);if(!Fb[dm]){Fb[dm]=[];}
ob(Fb[dm],Gb);}
var Hb={};var Ib=null;var Jb;for(Ib in Fb){if(Fb.hasOwnProperty(Ib)&&Fb[Ib].length){Jb=Fb[Ib];Jb.sort(t._xa);var Kb=new rb();var Lb=new rb();var Mb=new rb();var Nb=0;var Ob=0;var Pb=0;var Qb=0;var Rb=0;var Sb=0;var Tb=Eb+99999999;var Ub=0;var Vb=0;var Wb=Tb;var Xb=0;var Yb=Eb+99999999;var Zb=0;var $b=0;for(i=0;i<Jb.length;i++){var ac=Jb[i]._ea-Jb[i]._da;if(Jb[i]._sa==t._ma){Tb=t._ya(Tb,ac);Ub=t._za(Ub,ac);var bc=Nb+Ob+Pb;Sb=parseInt((Sb*bc+ac)/(bc+1),10);Kb._ca(Jb[i]._da-Eb,Jb[i]._ea-Eb);if(Jb[i]._wa){Nb++;}else{if(Jb[i]._Ba){Pb++;}else{Ob++;}}}else if(Jb[i]._sa==t._na){Lb._ca(Jb[i]._da-Eb,Jb[i]._ea-Eb);Wb=t._ya(Wb,ac);Xb=t._za(Xb,ac);Vb=parseInt((Vb*Qb+ac)/(Qb+1),10);Qb++;}else{Mb._ca(Jb[i]._da-Eb,Jb[i]._ea-Eb);Yb=t._ya(Yb,ac);Zb=t._za(Zb,ac);$b=parseInt(($b*Rb+ac)/(Rb+1),10);Rb++;}}
Hb[Ib]={_Ca:Nb,_Da:Ob,_Ea:Pb,_Fa:Qb,_Ga:Kb._ha(),_Ha:Sb,_Ia:(Nb+Ob+Pb)>0?Tb:0,_Ja:Ub,_Ka:Lb._ha(),_La:Vb,_Ma:Qb>0?Wb:0,_Na:Xb,_Oa:Rb,_Pa:Mb._ha(),_Qa:$b,_Ra:Rb>0?Yb:0,_Sa:Zb};}}
var cc=[];for(Ib in Fb){if(Fb.hasOwnProperty(Ib)){Jb=Fb[Ib];var dc=Hb[Ib];if(cc.length>0){ob(cc,';');}
ob(cc,dT_.aesc(Ib));ob(cc,'|');ob(cc,dc._Ca);ob(cc,'|');ob(cc,dc._Da);ob(cc,'|');ob(cc,dc._Ea);ob(cc,'|');ob(cc,dc._Ga);ob(cc,'|');ob(cc,dc._Ha);ob(cc,'|');ob(cc,dc._Ia);ob(cc,'|');ob(cc,dc._Ja);ob(cc,'|');ob(cc,dc._Fa);ob(cc,'|');ob(cc,dc._Ka);ob(cc,'|');ob(cc,dc._La);ob(cc,'|');ob(cc,dc._Ma);ob(cc,'|');ob(cc,dc._Na);ob(cc,'|');ob(cc,dc._Oa);ob(cc,'|');ob(cc,dc._Pa);ob(cc,'|');ob(cc,dc._Qa);ob(cc,'|');ob(cc,dc._Ra);ob(cc,'|');ob(cc,dc._Sa);for(i=0;i<Jb.length&&i<t._la&&Jb[i]._ea-Jb[i]._da>=t._ka;i++){ob(cc,',');ob(cc,Jb[i]._sa);if(!Jb[i]._wa){if(Jb[i]._Ba){ob(cc,'i');}else{ob(cc,'f');}}
ob(cc,'|');ob(cc,Jb[i]._da-Eb);ob(cc,'|');ob(cc,Jb[i]._ea-Eb);ob(cc,'|');ob(cc,dT_.aesc(Jb[i]._ta));ob(cc,'|');ob(cc,dT_.aesc(Jb[i]._ra));}}}
var rj=cc.join('');return dT_.esc(rj);}else{return null;}},_Ta:function(ec,fc){if(!fc){var gc=t._Aa();if(gc){ec.a('3p',gc);}
t._pa=[];}},_Ua:function(hc){var d=dT_.gh(hc);return t._Va||(d&&d!=t._Wa);},_Xa:function(ic){return document.getElementsByTagName(ic);},_Ya:function(jc){t._va(jc.src,true);},_Za:function(e){t._Ya(e.target);},_$a:function(){if(window&&window.event&&window.event.srcElement){if(window.event.srcElement.readyState=='loaded'||window.event.srcElement.readyState=='complete'){t._Ya(window.event.srcElement);}}},_ab:function(sc){if(!sc._bb){sc._bb=dT_.nw();if(sc.src!=''&&t._Ua(sc.src)){if((sc.attributes&&sc.attributes['data-dtconfig'])){}else{t._qa(t._na,sc.src);if(dT_.gBI().ie){dT_.ael(sc,'readystatechange',t._$a);}
else{dT_.ael(sc,'load',t._Za);}}}}},_cb:function(){var kc=t._Xa('script');for(var i=0;i<kc.length;i++){var sc=kc[i];t._ab(sc);}},_db:function(lc){t._va(lc.src,true);},_eb:function(mc){var nc=null;if(mc){if(mc.target){nc=mc.target;}
else if(mc.srcElement){nc=mc.srcElement;}}
else{if(window&&window.event){nc=window.event.srcElement;}}
if(nc){t._db(nc);}else{}},_fb:function(e){var oc=null;if(e){if(e.target){oc=e.target;}
else if(e.srcElement){oc=e.srcElement;}}
else{if(window&&window.event){oc=window.event.srcElement;}}
if(oc){if(oc.src!=document.location.href){t._va(oc.src,false);}}},_gb:function(pc){if(!pc.complete){return false;}
if(typeof pc.naturalWidth!="undefined"&&pc.naturalWidth===0){return false;}
return true;},_hb:function(qc){if(!qc._bb){qc._bb=dT_.nw();if(qc.src!=''&&t._Ua(qc.src)){t._qa(t._ma,qc.src);if(t._gb(qc)){t._db(qc);return;}
dT_.ael(qc,'load',t._eb);dT_.ael(qc,'error',t._fb);qc.src=qc.src;}}},_ib:function(){var rc=t._Xa('img');var i;var tc;for(i=0;i<rc.length;i++){tc=rc[i];t._hb(tc);}
rc=t._Xa('input');for(i=0;i<rc.length;i++){tc=rc[i];if(tc.type&&tc.type.toUpperCase()=='SUBMIT'){t._hb(tc);}}},_jb:function(){t._ib();t._cb();},_kb:function(){if(dT_.nw()-t._lb>t._ia){t._mb=false;return;}
t._jb();dT_.st(t._kb,t._ja);},_nb:function(){t._jb();if(dT_.ca()){if(!t._mb){t._lb=dT_.nw();t._mb=true;t._kb();}}else{}}};var uc=dT_.cfg('tp');if(dT_.smbi('3')){var vc=uc.split(',');var l=vc.length;if(l==3||l==4){t._ka=parseInt(vc[0],10);t._ja=parseInt(vc[1],10);t._la=parseInt(vc[2],10);if(l==4){t._Va=1;}
t._Wa=dT_.gh(document.location.href);dT_.ail(t._nb);dT_.asl(t._Ta);dT_.tpstr=t._qa;dT_.tpsto=t._va;t._nb();}}})();