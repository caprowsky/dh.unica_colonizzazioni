var cjo_url = "http://journals.cambridge.org";
var mrs_url = "www.mrs.org";