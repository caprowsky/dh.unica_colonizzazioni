/**
 * On document load
 */
jQuery(document).ready(function() {
	//load custom validations
	addCustomValidations();
	
	//load validator defaults 
	setValidatorDefaults();
	
	//load login
	initLogin();
		
	//load Submit buttons
	initSubmit();
	
	//load Reset buttons
	initReset();
	
	//Custom Initialization
	initPage();
});

/**
 * Set jquery validator defaults here
 * use jQuery(form).valid() to validate
 * @onsubmit: do not validate
 */
function setValidatorDefaults() {
	jQuery.validator.setDefaults({
		onsubmit: false
	});
}


/**
 * Initialize CJO submit buttons
 */
function initSubmit() {
	jQuery("a.go").click(submitForm);
	jQuery("li.save").click(submitForm);
	jQuery("li.back").click(submitForm);
	jQuery("li.email").click(submitForm);
	jQuery("li.cancel").click(submitForm);
	jQuery("li.search").click(submitForm);
	jQuery("li.submit").click(submitForm);
	jQuery("li.update").click(submitForm);
	jQuery("li.delete").click(submitForm);
	jQuery("li.reject").click(submitForm);
	jQuery("li.publish").click(submitForm);
	jQuery("li.activate").click(submitForm);
	jQuery("li.download").click(submitForm);
	jQuery("li.unpublish").click(submitForm);
	jQuery("li.runReport").click(submitForm);
	jQuery("li.uploadLogo").click(submitForm);
	jQuery("li.removeLogo").click(submitForm);
	jQuery("li.delRemUser").click(submitForm);
	jQuery("li.actRemUser").click(submitForm);
	jQuery("li.findTitles").click(submitForm);
	jQuery("li.saveArticle").click(submitForm);
	jQuery("li.saveHeading").click(submitForm);
	jQuery("li.deactRemUser").click(submitForm);
	jQuery("li.activateMore").click(submitForm);
	jQuery("li.newRemoteUser").click(submitForm);
	jQuery("li.backCommentList").click(submitForm);
	jQuery("li.activateMultiple").click(submitForm);
	jQuery("li.updateOrganisation").click(submitForm);
	jQuery("li.addHighlightArticle").click(submitForm);
	jQuery("li.updateHighlightArticle").click(submitForm);
	jQuery("a.del").click(submitForm);
	jQuery("a.upload").click(submitForm);
	jQuery("li.submitForm").click(submitForm);
	jQuery("li.export").click(submitForm);
	jQuery("li.add").click(submitForm);
	jQuery("li.remove").click(submitForm);
	jQuery("a#delete").click(submitForm);
	jQuery("a.removeLogo").click(submitForm);
	jQuery("a.savebttn").click(submitForm);

	//default cjo Done --fix for My Cambridge Journals Online menu 
	jQuery("div.userDetails-buttons li.done").click(function(){
		window.location.href = "login";
	});
}

/**
 * Override this for logic before submit
 * @return boolean 
 */
function doBeforeSubmit(element) {
	return(element.closest("form").valid());
}

/**
 * Default submit functionality
 */
function submitForm(event) {	
	if(doBeforeSubmit(jQuery(this))) {
		jQuery(this).closest("form").submit();
	}
}

/**
 * Initialize CJO Reset buttons
 * @return
 */
function initReset() {
	jQuery("li.reset").click(resetForm);
	jQuery("li.SmallReset").click(resetForm);	
	jQuery("a.bot_reset").click(resetForm);
	jQuery("li.clearForm").click(resetForm);
	
}

/**
 * Default reset functionality
 */
function resetForm(event) {
	var formName = jQuery(this).closest("form").attr("name");
	document.forms[formName].reset();
	event.preventDefault();
}

/**
 * Override this for custom initialization 
 */
function initPage() {
	
}

/**
 * Set Custom validators here
 */
function addCustomValidations() {
	/**
	 * Check if input date format is correct (ddMMMyyyy)
	 */
	jQuery.validator.addMethod("cjoDateFormat", function(value, element) {
		if( !value ) {
  			return true;
		}
		return Date.parseExact(value, "ddMMMyyyy") ? true : false;		
	  }, "Invalid date format."
	);
	
	/**
	 * Validate comma separated email addresses
	 */
	jQuery.validator.addMethod("multipleEmail", function(value, element) {
		if( !value ) {
  			return true;
		} else {
			var separator = ",";
			var tokens = new Array();

			if (value.substring(value.length - 1, value.length) == ',') {
				return false;
			}

			tokens = tokenize(value, separator);
			for (var i = 0; i < tokens.length; i++) {
				if (!checkEmail(trim(tokens[i]))) {
					return false;
				}
			}
			return true;
		}		
	}, "Please enter a valid email address after each comma.");
	
	/**
	 * Validate multiple subscription numbers
	 */
	jQuery.validator.addMethod("activateMultiple", function(value, element) {
		if( !value ) {
  			return true;
		}

		var subscriptionNumbers = value.split(",");
		var ret = true;
		
		for(var i = 0; i < subscriptionNumbers.length; i++) {
			if(!isValidNumber(subscriptionNumbers[i])) {
				ret = false;
				break;
			}
		}
		
		return ret;		
	}, "Please enter a valid number.");
	
	/**
	 * Phone number validation
	 */
	jQuery.validator.addMethod("phone", function(value, element) {
		if(!value) {
			return true;
		}
		
		var stripped = value.replace(/[\s()+-]|ext\.?/gi, "");
		
		if(isValidNumber(stripped) && stripped.match(/\d{7,}/i)) {
			return true;
		}
		
		return false;
	}, "Please enter a valid phone number.");
}

function isValidNumber(sText) {
	var PNum = new String(sText);
	var regex = /[^0-9]/;
	return !regex.test(PNum);
}

/**
 * Initialize for Login
 */
function initLogin() {
	jQuery("#cjo_username").click(function() {
		jQuery('div.errorRow').text('');
	});
	
	jQuery("#loginForm").bind("keypress", function(e) {
		if(e.keyCode==13){
			jQuery("#submitUsrnamePassword").click();
			return false;
		}
	}); 

	jQuery('div.submitrow a,div.login_button_container a').click(function() {
		var puserName = document.loginForm.userName.value;
	    var ppassWord = document.loginForm.passWord.value;
		var puserName= document.loginForm.userName.value;
		var ploginCount = document.loginForm.loginCount.value;
	
		if (ploginCount=='') {
			ploginCount='0';
		}
				
		jQuery.post('/validator?'+Math.random(),
				{userName:puserName, passWord:ppassWord, loginCount:ploginCount },
				function(data) {
					if(data=='success'){
						document.loginForm.submit();
					} else if(data=='forgottenPassword') {
						window.location='forgottenPassword';
					} else if(data=='NSforgottenPassword') {
						window.location='NSforgottenPassword';
					} else if(null != data )  {
						var computedValues = data.split(',');
						document.loginForm.loginCount.value= computedValues[0];
		                jQuery('div.errorRow').html(computedValues[1]);
	 					document.loginForm.passWord.value='';
	 					document.loginForm.userName.value='';
					} else {   
						jQuery('div.errorRow').text('Unexpected error.');
					}
				}
		);
	});
	
	jQuery('#cjolinksselect, #orgadminlinksselect, #conadminlinksselect, #socadminlinksselect, #editorlinksselect').bind('change', function () {
		//jQuery('ul.selectbox_menu').toggle();
		var url = jQuery(this).val(); // get selected value
		
	    if (url) { // require a URL
	    	var win = window.open(url,'_new'); // redirect
	    	win.focus();
	    }
	    setTimeout(function(){
			jQuery("SELECT").selectbox('value', '#');
			jQuery('#library-login').toggle();
		},1000);
		return false;
	 });
	 
}

function animations_commentEvent(item) {	
	animations_initMultipleCaptcha(jQuery(item).attr("id").replace("commentbox", ""));
	var form = jQuery(item).closest("form").attr("name");
	commentEvent(item,form);
}

function animations_contactUsEvent(item) {	
	animations_initMultipleCaptcha(jQuery(item).attr("id"));
	var form = jQuery(item).closest("form").attr("name");
	contactUsEvent(item,form);
}

function animations_initMultipleCaptcha(id) {
	var currentCaptchaHolder = jQuery("#recaptcha_widget_div").parent("div").attr("id");
	
	if(currentCaptchaHolder && currentCaptchaHolder != "captcha" + id) {
		//jQuery("#captcha" + id).html(jQuery("#recaptcha_widget_div").clone(true, true));
		var activeCaptcha = jQuery("#recaptcha_widget_div");
		jQuery("#" + currentCaptchaHolder).html("");
		jQuery("#captcha" + id).html(activeCaptcha);
		
		if(id.indexOf("contactUs")>-1){
			if(id.indexOf("9")>=0){ // production query
				jQuery("#contactUs-h-3inner").slideUp();
				jQuery("#contactUs-h-3").attr("class", "contactUs-page-row inactive");
				jQuery.cookies.set("contactUs-h-3", null);
			}
			else{ // feedback
				jQuery("#contactUs-h-9inner").slideUp();
				jQuery("#contactUs-h-9").attr("class", "contactUs-page-row inactive");
				jQuery.cookies.set("contactUs-h-9", null);
			}
		}
		
		else 
			jQuery("#commentbox" + currentCaptchaHolder.replace("captcha", "") + "-box").slideToggle();
		
		
		currentCaptchaHolder = "captcha" + id;
		Recaptcha.reload();
	}
}

function contactUsEvent(item,form){
	//var componentId = parseInt(item.id.split('commentbox')[1]);
	//var jid = jQuery("#jid").val();
	
	if (jQuery('#'+item.id+"-box").css('display') == 'none') {
		jQuery('#'+item.id+"-box").slideToggle();		
		
		//loadComments(jid, componentId, form);
	} else {
		jQuery('#'+item.id+"-box").slideToggle();
	}
	
	return false;
}

function saveComment(id, comment) {
	jQuery("#commentTextId1").val(id);
	jQuery("#commentText1").val(comment);
}

function showComment(componentId) {
	animations_initMultipleCaptcha(componentId);
	jQuery("#commentbox" + componentId + "-box").slideToggle();
	
	var form = jQuery("#commentbox" + componentId).closest("form").attr("name");
	var jid = jQuery("#jid").val();
	
	loadComments(jid, componentId, form);
}

function doSort(fname) {
	if (fname=='upper') { 
		document.page_sort_upper.action='displayIssue';
		document.page_sort_upper.submit();
	} else if(fname=='lower') {
		document.page_sort_lower.action='displayIssue';
		document.page_sort_lower.submit();
   }
   return true;
}

function displayCommentCount(componentId, form) {
	jQuery.post('/action/comment?'+Math.random(),
		{type:'getCommentCount', componentId:componentId},
		function(data) {
			if (data != '-1') {
				var com = getStaticResource("article.comments.comments");
				if (data == '1') {
					com = getStaticResource("article.comments.comment");
				}
				
				if(form == 'commentPostAbstract'){
					jQuery('#commentheader' + componentId).html('<span class="title">' + data + ' ' + com + ' </span>');
					jQuery('#commentbox' + componentId).html('<span class="title">' + getStaticResource("article.comments.user.comments") + ' (' + data + ')</span>');
				}else{
					jQuery('#commentbox' + componentId).html(data + ' ' + com);
				}	
			}
		}				
	);
}

function displayCommentCountsOnce(jsonObj) {
	jQuery.post('/action/comment?'+Math.random(),
			{data:JSON.stringify(jsonObj),type:"getCommentCountsOnce"},
			function(data) {
				parseJsonComments(data);
			});
}

function parseJsonComments(data){
	var obj = jQuery.parseJSON(data);	
	var length = obj.length - 1;
	var com = getStaticResource("article.comments.comment");
	var coms = getStaticResource("article.comments.comments");
	jQuery.each(obj, function (i, article) {
		writeCommentCounts(article.componentId,article.commentCount,com,coms);			
	})
}

function writeCommentCounts(id,count,com,coms){
	if(count != '-1'){
		var comStr = coms;
		if(count == '1'){
			comStr = com;
		}
		jQuery('#commentbox' + id).html(count + ' ' + comStr);
	}
}

function loadCommentsAnchor(jid, componentId, form) {
	$(window).scrollTop($('#commentbox' + componentId + "-box").position().top);
	loadComments(jid, componentId, form);
}

function loadComments(jid, componentId, form) {
	jQuery('.comments-list' + componentId).html('');
	jQuery.post('/action/comment?'+Math.random(),
		{type:'getComments', jid:jid, componentId:componentId},
		function(data) {	
			if (data == 'disabled') {
				jQuery('.comments-list' + componentId).html(getStaticResource("article.comments.disabled"));
			} else {
				var size;
				
				if (data != 'none') {
					data = data.replace(/\r/g, '');
					data = data.replace(/\n/g, '');
					var myJSONObject = eval('(' + data + ')');
					size = myJSONObject.comment.length;
					
					for (i=0; i<size;i++) {
						cmmnt = myJSONObject.comment[i];
						commentCtr = cmmnt.commentId;
												
						jQuery('.comments-list' + componentId).append("" +
								"<div class=\"clear\"></div>" +
								"<!-- start comment-->" +
								"<div class=\"comment\" style=\"display:none\" id=\"comment" + commentCtr + "\">" +
								"	<div class=\"comment-details\">" +
								"		<p class=\"cd-name\" id=\"cd-name" + commentCtr + "\"></p>" +
								"		<p class=\"cd-role\" id=\"cd-role" + commentCtr + "\"></p>" +
								"" +	
								"		<p class=\"cd-copy\" id=\"cd-copy" + commentCtr + "\"></p>" +
								"	</div>" +
								"</div>" +
								"<!-- end of comment -->" +
								"");
						
						jQuery('#cd-name'+commentCtr).text(cmmnt.name);
						jQuery('#cd-role'+commentCtr).text(cmmnt.institution);	
						jQuery('#cd-copy'+commentCtr).html(cmmnt.comment);
						
						jQuery('#comment'+commentCtr).fadeIn('slow');
					}
				} else {
					size = 0;
				}
				
				var com = getStaticResource("article.comments.comments");
				
				if (size == '1') {
					com = getStaticResource("article.comments.comment");
				}
			
				if(form == 'commentPostAbstract'){
					jQuery('#commentbox' + componentId).html('<span class="title">' + size + " " + com + '</span>');
					jQuery("#commentheader" + componentId).text(size + " " + com);
				} else {
					jQuery('#commentbox' + componentId).html(size + ' ' + com);
				}				
			}
		}		
	);
}

function commentEvent(item,form){
	var componentId = parseInt(item.id.split('commentbox')[1]);
	var jid = jQuery("#jid").val();
	
	if (jQuery('#'+item.id+"-box").css('display') == 'none') {
		jQuery('#'+item.id+"-box").slideToggle();		
		
		loadComments(jid, componentId, form);
	} else {
		jQuery('#'+item.id+"-box").slideToggle();
	}
	
	return false;
}

function validateComment(componentId) {
	var valid=true;
    var name = jQuery("#name" + componentId).val();
	var institution = jQuery("#institution" + componentId).val();
	var email = jQuery("#email" + componentId).val();
	var updates = jQuery("#updates" + componentId).val();
	var comment = jQuery("#Comment" + componentId).val();
	
	if (!name) {
		jQuery("#namelabel" + componentId).text(getStaticResource("article.comments.name.required"));
		jQuery("#name" + componentId).attr("class", "error");
		valid= false;
	} else {
		jQuery("#namelabel" + componentId).text("");
		jQuery("#name" + componentId).removeClass("error");
	}
	if (!comment) {
		jQuery("#commentlabel" + componentId).text(getStaticResource("article.comments.comment.required"));
		jQuery("#Comment" + componentId).attr("class", "error");
		valid= false;
	} else {
		jQuery("#commentlabel" + componentId).text("");
		jQuery("#Comment" + componentId).removeClass("error");
	}
	if (!email || !checkEmail(email)) {
		jQuery("#emaillabel" + componentId).text(getStaticResource("article.comments.invalid.email"));
		jQuery("#email" + componentId).attr("class", "error");
		valid= false;
	} else {
		jQuery("#emaillabel" + componentId).text("");
		jQuery("#email" + componentId).removeClass("error");
	}
 return valid;
}

function postCommentEvent(item,form) {
	var componentId = parseInt(item.id.split('cb')[1]);
	var name = jQuery("#name" + componentId).val();
	var institution = jQuery("#institution" + componentId).val();
	var email = jQuery("#email" + componentId).val();
	var updates = "off";
	
	if (jQuery("#updates" + componentId).is(':checked')) {
		updates = "on";
	}
		
	var comment = jQuery("#Comment" + componentId).val();
	var challenge = jQuery("[name=recaptcha_challenge_field]").val();
	var response = jQuery("[name=recaptcha_response_field]").val();	

	var jid = jQuery("#jid").val();
			
	jQuery("#postAlert" + componentId).html(getStaticResource("article.comments.wait") + " <img src='/images/ajax-loader.gif'/>");
	
	if (validateComment(componentId)) {
		if (jQuery("#alert" + componentId).is(':checked')) {
			jQuery("#postAlert" + componentId).html(getStaticResource("article.comments.log.in"));
			$(window).scrollTop($('#commentbox' + componentId + "-box").position().top);
		} else {
			jQuery.post('/action/comment?'+Math.random(),
				{type: 'saveComments', name:name, institution:institution, email:email, updates: updates, comment:comment, jid:jid, componentId:componentId, recaptcha_challenge_field: challenge, recaptcha_response_field: response},
				function(data) {
					if (data.indexOf('Error') < 0 && data != 'false') {
						if (data == 'spam') {
							jQuery("#postAlert" + componentId).html(getStaticResource("article.comments.invalid.captcha"));
							$(window).scrollTop($('#commentbox' + componentId + "-box").position().top);
						} else if (data == 'moderated'){
							jQuery("#postAlert" + componentId).html(getStaticResource("article.comments.moderated"));
							jQuery("#Comment" + componentId).val("");
							jQuery("#comctr" + componentId).html("1000");
							loadCommentsAnchor(jid,componentId,form);
						} else {
							jQuery("#postAlert" + componentId).html(getStaticResource("article.comments.success"));
							jQuery("#Comment" + componentId).val("");
							jQuery("#comctr" + componentId).html("1000");
							loadCommentsAnchor(jid,componentId,form);
						}
					} else {
						jQuery("#postAlert" + componentId).html(getStaticResource("article.comments.error"));
					}
					
					Recaptcha.reload();
				}
			);
		}
	} else {
		jQuery("#postAlert" + componentId).html("");
	}
	
	return false;
}

function previewEvent(){
	var articleId = jQuery(this).attr("id");
	jQuery(this).toggleClass("active");	
	jQuery(this).parent().siblings(".previewbox").slideToggle();
	var componentId = parseInt(articleId.split('hp')[1]);
	
	var cached = jQuery(this).parent().siblings("#cached"+componentId).html();
	var hasAccess = jQuery(this).parent().siblings('#access'+componentId).val();
	var link = jQuery(this).parent().siblings('#link'+componentId).val();
	var previewtab = jQuery(this).parent().siblings(".previewbox").children("#categoryitems").children(".contents");
	var previewbox = previewtab.children("#content_container");
	var tabs = previewtab.children("ul").children("li");
	
	if(jQuery(this).hasClass("active") && cached == 'false') {
		PreviewTabsContent.getAbstractText(componentId, function(data) {
			if (data == '') {
				previewbox.children("#preview"+ componentId + "-1").html("<div class='preview-div'>There is no abstract available for this article.</div>");
		    } else if (data == '**<NOCONTENT>**') {
		    	previewbox.children("#preview"+ componentId + "-1").html("<div class='preview-div'>There is no abstract available for this article.</div>");
		    } else {
		    	previewbox.children("#preview"+ componentId + "-1").html("<div class='preview-div'>" + data + "</div>");
		    }
		});
		
		if (hasAccess == 'true') {
			  PreviewTabsContent.getReferences(componentId, function(data) {
			  	if (data != '' && data != '**<NOCONTENT>**') {
			  		tabs.children("#tab" + componentId + "-4").fadeIn();
				    previewbox.children("#preview" + componentId + "-4").html("<div class='preview-div'>" + data + "</div>");    	     	
		    	}
			  }); 
			  
			 PreviewTabsContent.getStructure(componentId, link, function(data) {
			  	if (data != '' && data != '**<NOCONTENT>**') {
			  		tabs.children("#tab" + componentId + "-2").fadeIn();
			  		previewbox.children("#preview" + componentId + "-2").html("<div class='preview-div'>" + data + "</div>");
			    }
			  });
		  
		     PreviewTabsContent.getFiguresAndTablesText(componentId, link, 3, function(data) {
				if (data != '' && data != '**<NOCONTENT>**') {					
					tabs.children("#tab" + componentId + "-3").fadeIn();
				    previewbox.children("#preview" + componentId + "-3").html("<div class='preview-div'>" + data + "</div>");    	
		    	}
			  });
		     
		     PreviewTabsContent.getFiguresAndTablesText(componentId, link, 5, function(data) {
					if (data != '' && data != '**<NOCONTENT>**') {					
						tabs.children("#tab" + componentId + "-5").fadeIn();
					    previewbox.children("#preview" + componentId + "-5").html("<div class='preview-div'>" + data + "</div>");    
			    	}
				  });
		     PreviewTabsContent.getFiguresAndTablesText(componentId, link, 6, function(data) {
					if (data != '' && data != '**<NOCONTENT>**') {					
						tabs.children("#tab" + componentId + "-6").fadeIn();
					    previewbox.children("#preview" + componentId + "-6").html("<div class='preview-div'>" + data + "</div>");    	
			    	}
				  });
	   	}
		
		//alert(previewtab.children("ul#previewtabs"+componentId).children("li").eq(3).children("a").attr("id"));
		//previewtab.children("ul#previewtabs"+componentId).children("li").eq(3).children("a").click(displayPreviewTabs);
		
		displayPreviewTabs(previewtab.children("ul#previewtabs"+componentId).children("li").eq(0),previewbox);
		displayPreviewTabs(previewtab.children("ul#previewtabs"+componentId).children("li").eq(1),previewbox);
		displayPreviewTabs(previewtab.children("ul#previewtabs"+componentId).children("li").eq(2),previewbox);
		displayPreviewTabs(previewtab.children("ul#previewtabs"+componentId).children("li").eq(3),previewbox);
		displayPreviewTabs(previewtab.children("ul#previewtabs"+componentId).children("li").eq(4),previewbox);
		displayPreviewTabs(previewtab.children("ul#previewtabs"+componentId).children("li").eq(5),previewbox);
		displayPreviewTabs(previewtab.children("ul#previewtabs"+componentId).children("li").eq(6),previewbox);
		
		/*previewtab.children("ul#previewtabs"+componentId).children("li").click(function(){
			var rel = jQuery(this).children("a").attr("rel");
			alert(rel);
			var tab = rel.replace("preview","tab");
			jQuery(this).children("a").removeClass("active");
			//previewtab.children("ul#previewtabs"+componentId).children("li").children("a").removeClass("active");
			jQuery(this).children("a#"+tab).addClass("active");
			
			previewbox.children("div").hide();
			previewbox.children("div#"+rel).show();
			});		*/
		jQuery(this).parent().siblings("#cached"+componentId).html('true');
	}
	return false; 	
}

function displayPreviewTabs(previewTab,previewbox){
	previewTab.children("a").click(function(){
		var rel = jQuery(this).attr("rel");
		var tab = rel.replace("preview","tab");
		jQuery(this).removeClass("active");
		previewTab.children("a#"+tab).addClass("active");
		previewbox.children("div").hide();
		previewbox.children("div#"+rel).show();
	});
}

/**
 * Page refresh for CJO SSO
 */
function refreshPage() { 
	setTimeout(function() {
		location.reload(true);
	}, 4000);
};

/**
 * Update SSO Session
 */
function updateSession() { 
	setTimeout(function() {
		jQuery.get("/action/updateSession");
	}, 4000);
};

/**
  * Added for NLS
  */
function getStaticResource(key) {
	var value = "";
	
	jQuery.ajax({
		type	: "GET",
		url		: "/action/reloadMessages",
		data	: {type: "4", key: key},
		async	: false,
		cache	: false,
		success	: 
			function(result) {
				value = result;
			}
	});
	
	return value;
}
//added to remove unwanted js file dynamically
function removejscssfile(filename, filetype){
	 var targetelement=(filetype=="js")? "script" : (filetype=="css")? "link" : "none" //determine element type to create nodelist from
	 var targetattr=(filetype=="js")? "src" : (filetype=="css")? "href" : "none" //determine corresponding attribute to test for
	 var allsuspects=document.getElementsByTagName(targetelement)
	 for (var i=allsuspects.length; i>=0; i--){ //search backwards within nodelist for matching elements to remove
	  if (allsuspects[i] && allsuspects[i].getAttribute(targetattr)!=null && allsuspects[i].getAttribute(targetattr).indexOf(filename)!=-1)
	   allsuspects[i].parentNode.removeChild(allsuspects[i]) //remove element by calling parentNode.removeChild()
	 }
}
/**
 * This function should be used to attain the window.onload behavior. This is created to avoid conflict in multiple window.onload calls
 */
function addLoadEvent(func) {
	var oldonload = window.onload;
	if (typeof window.onload != 'function') {
		window.onload = func;
	} else {
		window.onload = function() {
	     if (oldonload) {
	        oldonload();
	      }
	      func();
	    }
	 }
}

function computePageNum(componentId, issueTitle, category, issueId, volumeId, seriesId, itemInfoURL, jid, journalTitle) {
	
	var totalPageNum = "";
	var itemPdfURL = "http://portal.sds.sheridanpress.local/CSR.aspx";
	
	jQuery.ajax({
		type	: "GET",
		url		: "/action/computePageNumber",
		data	: {jid:jid, volumeId:volumeId, issueId:issueId, seriesId:seriesId},
		async	: false,
		success	: 
			function(result) {
				totalPageNum = result;
			}
	});

	return AddToCart(componentId, issueTitle, category, '', '', issueId, volumeId, itemInfoURL, itemPdfURL, '', '', totalPageNum, journalTitle);
}

