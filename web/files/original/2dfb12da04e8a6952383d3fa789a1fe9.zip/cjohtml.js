function REF(refid, atitle, jtitle, vol, fpage, lpage, year) {  
	var urlcjo = '/jsp/cjo/common/urlResolver.jsp';
	urlcjo = urlcjo + '?param=genreCJOEQUEALarticleCJOSEPAatitleCJOEQUEAL' + atitle + 'CJOSEPAtitleCJOEQUEAL' + jtitle + 'CJOSEPAvolumeCJOEQUEAL' + vol + 'CJOSEPAspageCJOEQUEAL' + fpage + 'CJOSEPAepageCJOEQUEAL' + lpage + 'CJOSEPAdateCJOEQUEAL' + year   +'&refid='+refid;   
   	var hnd=window.open(urlcjo,refid,'alwaysRaised=0,dependent=0,toolbar=0,location=0,status=0,menubar=0,scrollbars=1,resizable=1,width=500, height=420');
} 

function FIGIMAGES(wid,graphic,label,caption) {
	var hnd;
	if(graphic.indexOf(".svg") != -1 || graphic.indexOf(".png") != -1) {
		hnd = window.open('', wid, 'alwaysRaised=0,dependent=0,toolbar=1,location=0,status=1,menubar=1,scrollbars=1,resizable=1,width=1070,height=1000');
	} else {
		hnd = window.open('', wid, 'alwaysRaised=0,dependent=0,toolbar=1,location=0,status=1,menubar=1,scrollbars=1,resizable=1,width=700,height=500');
	}
   	var altText = "";
   	
   	if(graphic.indexOf("p.") != -1) {
   		altText = "Low resolution image";
   	} else if(graphic.indexOf("g.") != -1) {
   		altText = "High resolution image";
   	}
   	
  	hnd.document.write('<html><body><form method="submit"><table border="0"><tr><td><table cellpadding="2"><tr valign="top" align="center"><td style="border: 0">');
  	hnd.document.write('<div>' + label + " " + caption + '</div>');

   	if(graphic.indexOf(".svg") != -1) {
		if(navigator.userAgent.indexOf("Firefox") > -1) {
			hnd.document.write('<embed src="' + graphic + '" alt-text="' + altText + '" title="'+ altText +'" type="images/svg+xml"  max-width="640px" width="100%"  border="0"/></td></tr>');
		} else {
			hnd.document.write('<img src="' + graphic + '" alt-text="' + altText + '" title="'+ altText +'" type="gif" border="0"/></td></tr>');
		}
   	} else {
   		hnd.document.write('<img src="' + graphic + '" alt-text="' + altText + '" title="'+ altText +'" type="gif" border="0"/></td></tr>');
   	}
   	
   	hnd.document.write('<tr><td style="font-family:verdana,arial,sans-serif;font-size:10pt">');                                                        
   	hnd.document.write('</td></tr>');
   	hnd.document.write('<tr valign="bottom"><td align="center"><input type="Button" onClick="window.close()" value="close"/></td></tr></table></td></tr></table></form></body></html>');
	hnd.document.close();
}

function OPENDEXTER2(wid,graphic) {
	var filepath = tokenize(graphic, '/');
	var len = filepath.length;
	var dexterurl = '/action/dexterApplet?jid='+filepath[1]+ '&vid='+filepath[2]+ '&img=' + filepath[3];
	window.open(dexterurl,'dexter');
}

function replaceWithTex(id,alt) {
	var spanid = "span_" + id;
	document.getElementById(spanid).innerHTML = alt;
}

function DOWNLOADMEDIA(mimetype, media) {
	MM_goToURL("parent","/action/downloadMedia?path=" + media + "&fileType=" + mimetype);
}

function VIDEOMEDIA(mimetype, media) {
	var hnd = window.open('alwaysRaised=yes,modal=yes,dependent=no,toolbar=yes,location=no,status=yes,menubar=yes,scrollbars=yes,resizable=yes,width=1280,height=800,left=0,top=0');
	hnd.document.write('<html><body><form method="submit"><table border="1"><tr><td>');
	hnd.document.write('<embed  type="application/x-vlc-plugin" src="' + media + '" width="700" height="700" pluginspage="http://www.videolan.org" version="VideoLAN.VLCPlugin.2" id="vlc" >');
	hnd.document.write('<table cellpadding="2" style="display:none"><tr><td style="font-family:verdana,arial,sans-serif;font-size:10pt">');                                                        
	hnd.document.write('</td></tr>');
	hnd.document.write('<tr><td style="font-family:verdana,arial,sans-serif;font-size:10pt">');                                                        
	hnd.document.write(' ');
	hnd.document.write('</td></tr>');
	hnd.document.write('<tr><td style="font-family:verdana,arial,sans-serif;font-size:10pt">');                                                        
	hnd.document.write(' ');
	hnd.document.write('</td></tr>');
	hnd.document.write('<tr valign="bottom"><td style = "font-family:verdana,arial,sans-serif;font-size:10pt"> </td></tr>');
	hnd.document.write('<tr valign="bottom"><td align="center"><input type="Button" onClick="window.close()" value="close"/></td></tr></table></td></tr></table></form></body></html>');
	hnd.document.close();
}

function AUDIOMEDIA(mimetype, media, transcript) {
	var hnd = window.open('alwaysRaised=yes,modal=yes,dependent=no,toolbar=yes,location=no,status=yes,menubar=yes,scrollbars=yes,resizable=yes,width=700,height=500,left=0,top=0');
	hnd.document.write('<html><body><form method="submit"><table border="1">');
	hnd.document.write('<tr valign="top" align="center">');
	hnd.document.write('<td> <embed  type="application/x-vlc-plugin" src="' + media + '" width="400" height="100" pluginspage="http://www.videolan.org" version="VideoLAN.VLCPlugin.2" id="vlc" > </td>');
	hnd.document.write('<tr><td style="font-family:verdana,arial,sans-serif;font-size:10pt">');                                                        
	hnd.document.write(' ' + transcript);
	hnd.document.write('</td></tr>');
	hnd.document.write('<tr valign="bottom"><td align="center"><input type="Button" onClick="window.close()" value="close"/></td></tr></td></tr></table></form></body></html>');
	hnd.document.close();
}