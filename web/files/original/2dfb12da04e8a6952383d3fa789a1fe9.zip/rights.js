
function RightslinkPopUp ( atitle,pubId,pub_online_date,author,doi ,spage,epage,evolumeNum,eissueNum,copyrightHolder,copyrightYear,headerFileRef, aComponentId)        {    
        																																	//JOU - 11148 :: ndomingo : for retrieval from 
        																																	// file of copyright just in case
     //var url = "http://test100.copyright.com/AppDispatchServlet"; 
	
     //JOU-11148 : ndomingo : controlled default on GetRightsLinkWorker
    // var copyright="Cambridge University Press 2011";
     
     if(copyrightHolder == null || copyrightHolder == ''){
    	 ///copyright="Cambridge University Press 2011";
    	 jQuery.get('/action/getRightsLink',{'componentId':aComponentId, 'headerFileRef':headerFileRef},
    			 function(data){
    		 		var copyright = data.copyright;
    		 		
    		 		RightslinkPopUpOpen(atitle,pubId,pub_online_date,author,doi ,spage,epage,evolumeNum,eissueNum,copyright);
    	 		 }
    	 
    	 );
     
     
     
     }else {
    	 copyright =copyrightHolder+" "+copyrightYear;
    	 RightslinkPopUpOpen(atitle,pubId,pub_online_date,author,doi ,spage,epage,evolumeNum,eissueNum,copyright);
     }
    
    
     /*
     var location = url 
			+ "?publisherName=" + encodeURI ('CUP')
			+ "&publication=" + encodeURI (pubId)
			+ "&title=" + encodeURI (atitle) 
			+ "&publicationDate=" + encodeURI (pub_online_date) 
			+ "&author=" + encodeURI (author)
			+ "&copyright=" + encodeURI (copyright) 
			+ "&contentID=" + encodeURI (doi)
			+ "&startPage=" + encodeURI(spage)
			+ "&endPage=" + encodeURI(epage)
  	 	    + "&orderBeanReset=" + encodeURI('True')
  	 	    + "&volumeNum=" + encodeURI(evolumeNum)
			+ "&issueNum=" + encodeURI(eissueNum)
  	 	    ;
  	 	//  alert(location);
         var h= window.open( location,'Rightslink','location=no,toolbar=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=650,height=550');
        */  
}

  
 //JOU - 11148 :: ndomingo separate function to allow async get execute
function RightslinkPopUpOpen(atitle,pubId,pub_online_date,author,doi ,spage,epage,evolumeNum,eissueNum,copyright){
	
	var url = "https://s100.copyright.com/AppDispatchServlet";
	
    var location = url 
			+ "?publisherName=" + encodeURI ('CUP')
			+ "&publication=" + encodeURI (pubId)
			+ "&title=" + encodeURI (atitle) 
			+ "&publicationDate=" + encodeURI (pub_online_date) 
			+ "&author=" + encodeURI (author)
			+ "&copyright=" + encodeURI (copyright) 
			+ "&contentID=" + encodeURI (doi)
			+ "&startPage=" + encodeURI(spage)
			+ "&endPage=" + encodeURI(epage)
 	 	    + "&orderBeanReset=" + encodeURI('True')
 	 	    + "&volumeNum=" + encodeURI(evolumeNum)
			+ "&issueNum=" + encodeURI(eissueNum)
 	 	    ;
 	 	//  alert(location);
        var h= window.open( location,'Rightslink','location=no,toolbar=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=650,height=550');
       	
}