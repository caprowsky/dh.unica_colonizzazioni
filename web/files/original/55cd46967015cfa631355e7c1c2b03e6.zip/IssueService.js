// Provide a default path to dwr.engine
if (dwr == null) var dwr = {};
if (dwr.engine == null) dwr.engine = {};
if (DWREngine == null) var DWREngine = dwr.engine;
if (IssueService == null) var IssueService = {};
IssueService._path = '/dwr';
IssueService.getContextualTagsPool = function(p0, callback) {
  dwr.engine._execute(IssueService._path, 'IssueService', 'getContextualTagsPool', p0, callback);
}
IssueService.getMessage = function(p1, callback) {
  dwr.engine._execute(IssueService._path, 'IssueService', 'getMessage', false, p1, callback);
}
IssueService.getTxTemplate = function(callback) {
  dwr.engine._execute(IssueService._path, 'IssueService', 'getTxTemplate', callback);
}
IssueService.setTxTemplate = function(p0, callback) {
  dwr.engine._execute(IssueService._path, 'IssueService', 'setTxTemplate', p0, callback);
}
IssueService.getUserTransaction = function(callback) {
  dwr.engine._execute(IssueService._path, 'IssueService', 'getUserTransaction', callback);
}
