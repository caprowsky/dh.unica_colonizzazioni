// Provide a default path to dwr.engine
if (dwr == null) var dwr = {};
if (dwr.engine == null) dwr.engine = {};
if (DWREngine == null) var DWREngine = dwr.engine;
if (UserService == null) var UserService = {};
UserService._path = '/dwr';
UserService.saveBookmarks = function(p0, p1, p2, callback) {
  dwr.engine._execute(UserService._path, 'UserService', 'saveBookmarks', p0, p1, p2, callback);
}
UserService.getListBookmarkFolder = function(callback) {
  dwr.engine._execute(UserService._path, 'UserService', 'getListBookmarkFolder', callback);
}
UserService.saveRss = function(p0, callback) {
  dwr.engine._execute(UserService._path, 'UserService', 'saveRss', p0, callback);
}
UserService.getDisplayGPS = function(callback) {
  dwr.engine._execute(UserService._path, 'UserService', 'getDisplayGPS', callback);
}
UserService.getDisplayGroup = function(callback) {
  dwr.engine._execute(UserService._path, 'UserService', 'getDisplayGroup', callback);
}
UserService.getDisplayHistory = function(callback) {
  dwr.engine._execute(UserService._path, 'UserService', 'getDisplayHistory', callback);
}
UserService.getDisplayFullHistory = function(callback) {
  dwr.engine._execute(UserService._path, 'UserService', 'getDisplayFullHistory', callback);
}
UserService.getLastPeriod = function(callback) {
  dwr.engine._execute(UserService._path, 'UserService', 'getLastPeriod', callback);
}
UserService.setLastPeriod = function(p0, callback) {
  dwr.engine._execute(UserService._path, 'UserService', 'setLastPeriod', p0, callback);
}
UserService.getLastFond = function(callback) {
  dwr.engine._execute(UserService._path, 'UserService', 'getLastFond', callback);
}
UserService.setLastFond = function(p0, callback) {
  dwr.engine._execute(UserService._path, 'UserService', 'setLastFond', p0, callback);
}
UserService.getLastIssueScreen = function(callback) {
  dwr.engine._execute(UserService._path, 'UserService', 'getLastIssueScreen', callback);
}
UserService.setLastIssueScreen = function(p0, callback) {
  dwr.engine._execute(UserService._path, 'UserService', 'setLastIssueScreen', p0, callback);
}
UserService.removeHistoryItem = function(p0, callback) {
  dwr.engine._execute(UserService._path, 'UserService', 'removeHistoryItem', p0, callback);
}
UserService.getDisplayNotes = function(callback) {
  dwr.engine._execute(UserService._path, 'UserService', 'getDisplayNotes', callback);
}
UserService.getNotesListHtml = function(p0, p1, callback) {
  dwr.engine._execute(UserService._path, 'UserService', 'getNotesListHtml', p0, p1, callback);
}
UserService.getNoteContent = function(p0, p1, callback) {
  dwr.engine._execute(UserService._path, 'UserService', 'getNoteContent', p0, p1, callback);
}
UserService.deleteNote = function(p0, p1, callback) {
  dwr.engine._execute(UserService._path, 'UserService', 'deleteNote', p0, p1, callback);
}
UserService.saveNote = function(p0, p1, p2, callback) {
  dwr.engine._execute(UserService._path, 'UserService', 'saveNote', p0, p1, p2, callback);
}
UserService.getMessage = function(p1, callback) {
  dwr.engine._execute(UserService._path, 'UserService', 'getMessage', false, p1, callback);
}
UserService.getTxTemplate = function(callback) {
  dwr.engine._execute(UserService._path, 'UserService', 'getTxTemplate', callback);
}
UserService.setTxTemplate = function(p0, callback) {
  dwr.engine._execute(UserService._path, 'UserService', 'setTxTemplate', p0, callback);
}
UserService.getUserTransaction = function(callback) {
  dwr.engine._execute(UserService._path, 'UserService', 'getUserTransaction', callback);
}
