// Provide a default path to dwr.engine
if (dwr == null) var dwr = {};
if (dwr.engine == null) dwr.engine = {};
if (DWREngine == null) var DWREngine = dwr.engine;
if (SearchService == null) var SearchService = {};
SearchService._path = '/dwr';
SearchService.saveSearch = function(p0, p1, p2, p3, p4, callback) {
  dwr.engine._execute(SearchService._path, 'SearchService', 'saveSearch', p0, p1, p2, p3, p4, callback);
}
SearchService.getSavedSearch = function(p0, p1, p2, p3, p4, callback) {
  dwr.engine._execute(SearchService._path, 'SearchService', 'getSavedSearch', p0, p1, p2, p3, p4, callback);
}
SearchService.getSearchRss = function(p0, p1, p2, callback) {
  dwr.engine._execute(SearchService._path, 'SearchService', 'getSearchRss', p0, p1, p2, callback);
}
SearchService.getMessage = function(p1, callback) {
  dwr.engine._execute(SearchService._path, 'SearchService', 'getMessage', false, p1, callback);
}
SearchService.getTxTemplate = function(callback) {
  dwr.engine._execute(SearchService._path, 'SearchService', 'getTxTemplate', callback);
}
SearchService.setTxTemplate = function(p0, callback) {
  dwr.engine._execute(SearchService._path, 'SearchService', 'setTxTemplate', p0, callback);
}
SearchService.getUserTransaction = function(callback) {
  dwr.engine._execute(SearchService._path, 'SearchService', 'getUserTransaction', callback);
}
