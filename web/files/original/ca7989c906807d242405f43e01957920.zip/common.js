$(document).ready(function(){
	

	/* MENU' TOPNAV */

	

	index=$("ul#topnav li").index($("ul#topnav a.active").parent());

	if(index==-1){index=$("ul#topnav li").index($("ul#topnav a.active").parent().parent());main=index;}else{main=index;}

	$("ul#topnav li:eq("+main+")").css({ 'background' : '#333333 url(http://images.treccani.it/enc/media/images/menuRoll.gif) repeat-x bottom center'});

	$("ul#topnav li:eq("+main+") a").css({ 'color' : '#bf4b34'});

    $("ul#topnav li:eq("+main+") span a").css({ 'color' : '#333'});

    $("ul#topnav li:eq("+main+") span a.active").css({ 'color' : '#bf4b34'});

	$("ul#topnav li:eq("+main+")").find("span").show(); //Show the subnav

	$("ul#topnav li").hover(

		function() { //Hover over event on list item

			$("ul#topnav li:eq("+main+")").css({ 'background' : 'none'}); //Ditch the background

			$("ul#topnav li:eq("+main+")").find("span").hide(); //Hide the subnav

			$(this).css({ 'background' : '#333333 url(http://images.treccani.it/enc/media/images/menuRoll.gif) repeat-x bottom center'}); //Add background color + image on hovered list item

			$(this).find("span").show(); //Show the subnav

		},

		function(){ //on hover out...

			$(this).css({ 'background' : 'none'}); //Ditch the background

			$(this).find("span").hide(); //Hide the subnav

			$("ul#topnav li:eq("+main+")").css({ 'background' : '#333333 url(http://images.treccani.it/enc/media/images/menuRoll.gif) repeat-x bottom center'}); //Add background color + image on hovered list item

			$("ul#topnav li:eq("+main+")").find("span").show(); //Show the subnav

		}

	);

	

	/* TAB DELLA SEARCH - accendi/spegni, scatena la search */

	$(".ct a").click(
		
		function(){
        	if ($(this).attr('rel')!=$('#search_where').attr('value')) {
            	
				$('#search_where').attr('value',$(this).attr('rel'));
				$('.ct a.on').removeClass('on');
                $(this).addClass('on');
				if ($('#search_what').attr('value') != '') {
					$('#go_search').submit();
				} else {
					$('#search_what').focus();
				}
               	return false;
				
			}
		}
	);


	if($.fancybox){
		/* MODALE BETA MESS */
		$(".beta").fancybox({
			'titlePosition': 'inside',
			'transitionIn': 'none',
			'transitionOut': 'none',
			'scrolling': 'no',
			'showCloseButton': false
		});
		window.top.jQuery('.fbclose').live('click',
			function(){
				window.top.jQuery.fancybox.close();
				return false;
			}
		);
	}



	/* SCATENA LA SEARCH */

    $('#go_search').submit(

    	function() {
		
	    	var where = $('#search_where').attr('value');

			var what = $('#search_what').attr('value');

			what = what.replace(/ /gi,'-');

            var go = '';

            switch (where) {

	        	case 'en':

    	        	go = '/enciclopedia/tag/'+what+'/';

        	    	break;

				case 'vo':

                	go = '/vocabolario/tag/'+what+'/';

					break;

                        case 'db':
    	        	go = '/enciclopedia/tag/'+what+'/Dizionario_Biografico/';
        	    	break;
                        case 'sin':
    	        	go = '/vocabolario/ricerca/'+what+'/Sinonimi_e_Contrari/';
        	    	break;


			}
			if (what != '') {
				location.href = go;
			}
            return false;

		}

	);




});
