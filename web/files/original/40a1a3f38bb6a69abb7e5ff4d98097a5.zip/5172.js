CE2 = undefined;
/* No active snapshots */