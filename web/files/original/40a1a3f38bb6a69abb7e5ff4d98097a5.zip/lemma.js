/* variabili slider foto */ 
var nPannelli = 0;
var curPanel = 1;
var pos = -660;
var gap = 660;
var moving = 0;
/* variabili dimensione testo */
var defP = 16;
var defPLH = 24;
var defHeading1 = 17;
var defHeading2 = 18;
var curP = defP;
var curHeading1 = defHeading1;
var curHeading2 = defHeading2;
var curPLH = defPLH;
var MinP = 12;
var MaxP = 20; 
/* variabili tendina */
var altezzatendina = 0;
var altezzatendina_approfondimenti = 0;
var selInit1 = 0; 
var selInit2 = 0; 
/* variabili indice mobile */
var mobIndex = 0;
var mobile = false;
/* CHIUDE LA TENDINA AL CLICK FUORI DALLA TENDINA - associato a <body> */
function hidemenu(){
	if (selInit1 == 1) {
    	if ($('#tendina').css('height') != altezzatendina) {
			$('#tendina').css('height', altezzatendina);
			$('.selected').removeClass('open');
			selInit1 = 0
		}
	}
	if (selInit2 == 1) {
		if ($('#tendina-approfondimenti').css('height') != altezzatendina_approfondimenti) {
 			$('#tendina-approfondimenti').css('height', altezzatendina_approfondimenti);
  			$('.selected-approfondimenti').removeClass('open');
		 	selInit2 = 0;
		}
	}
}

function fnSelect(objId) {
   fnDeSelect();
   if (document.selection) 
   {
      var range = document.body.createTextRange();
      range.moveToElementText(document.getElementById(objId));
      range.select();
   }
   else if (window.getSelection) 
   {
      var range = document.createRange();
      range.selectNode(document.getElementById(objId));
      window.getSelection().addRange(range);
   }
}

function fnDeSelect() {
   if (document.selection)
             document.selection.empty();
   else if (window.getSelection)
              window.getSelection().removeAllRanges();
} 

$(document).ready(function(){

	/* SLIDER FOTO*/
	
	/* clono primo ed ultimo pannello per creare l'effetto loop */
	$('<div id="panel0" class="imgpanel"></div>').html($('#panel' + nPannelli).html()).prependTo($('#slider'));
	$('<div id="panel' + (nPannelli + 1) + '" class="imgpanel"></div>').html($('#panel1').html()).appendTo($('#slider'));

	/* next */
	$('#nPanel').click(function(){
		if (moving == 0) {
			moving = 1;
			$('#slider').animate({
				left: pos - gap
			}, 800, function(){
				if (curPanel == nPannelli) {
					$('#slider').css('left', '-660px');
					curPanel = 1;
					pos = -660;
				}
				else {
					curPanel++;
					pos = pos - gap;
				}
				moving = 0;
			});
		} else {
			// non fare niente mentre lo slider sta scivolando			
		}
		return false;
	});

	/* prev */
	$('#pPanel').click(function(){
		if (moving == 0) {
			moving = 1;
			$('#slider').animate({
				left: pos + gap
			}, 800, function(){
				if (curPanel == 1) {
					var newPos = (gap * nPannelli) * -1;
					$('#slider').css('left', newPos);
					curPanel = nPannelli;
					pos = newPos;
				}
				else {
					curPanel--;
					pos = pos + gap;
				}
				moving = 0;
			});
		} else {
			// non fare niente mentre lo slider sta scivolando			
		}
		return false;
	});
	
	/* DIMENSIONI DEL TESTO */
	$('.biggertxt').click(function(){
		if (curP < MaxP) {
			curP++;
			curPLH++;
			curHeading1++;
			curHeading2++;
			$('.spiega p').css({
				'font-size': curP,
				'line-height': curPLH + 'px'
			});
			$('.spiega .sc-paragraph').css('font-size', curHeading1);
			$('.spiega h4').css('font-size', curHeading2);
		}
		return false;
	});

	$('.smallertxt').click(function(){
		if (curP > MinP) {
			curP--;
			curPLH--;
			curHeading1--;
			curHeading2--;
			$('.spiega p').css({
				'font-size': curP,
				'line-height': curPLH + 'px'
			});
			$('.spiega .sc-paragraph').css('font-size', curHeading1);
			$('.spiega h4').css('font-size', curHeading2);
		}
		return false;
	});

	/* FANCYBOX - Modali per gallery e form invio lemma via mail */
	$("a.imgitem").fancybox();
	$(".html").fancybox({
		ajax : {
		    type	: "POST"
			
		},
		'showCloseButton'	: false
	});	

	/* ARGOMENTI CORRELATI - Caricamento contenuti e animazione */

	var curPanel = 1; 

  if (typeof panelNum === 'undefined') {
    //panleNum non è definito
  } else {
  	if (panelNum>1) {
  		$('#npanel').css('display','inline-block');
  	}
  }

	$('#ppanel').css('display','none');

	$('#ppanel').click(

		function() {
			curPanel--;
			var itemsH = parseInt($('#ac-items-cont').css('height'));
			$('#ac-items').animate(
				{
					opacity: 0
				},
				500
			);

			$('#ac-items-cont').animate(
				{
					height: itemsH
				}, 
				500,
				function() {
					$('#ac-items').load(
						panelBase+curPanel+'/',
						function() {
							
							if (curPanel == 1) $('#ppanel').hide();
							if (curPanel == panelNum-1) $('#npanel').css('display','inline-block');
							try { // google
								_gaq.push(['_trackPageview']);
							} 
							catch (e) {}
							var newItemsH = parseInt($('#ac-items').css('height'));
							if (newItemsH>itemsH) {
								var diff = '+='+(newItemsH-itemsH);
							}
							if (newItemsH<itemsH) {
								var diff = '-='+(itemsH-newItemsH);
							}
							if (newItemsH==itemsH) {
								var diff = '+='+0;
							}
							$('#ac-items-cont').animate(
								{
									height: diff
								},
								500,
								function() {
									$('#ac-items').animate(
									{
										opacity: 100
									},
									500,
									function() {
										if(jQuery.browser.msie) {
 					                               			this.style.removeAttribute('filter');
		                						} 
									}
									);
								}
							);
						}
					);
				}
			);
			return false;
	    }
	);


	$('#npanel').click(
	       	function() {
			curPanel++;
			if (curPanel>panelNum) curPanel = 1;				
			var itemsH = parseInt($('#ac-items-cont').css('height'));
			$('#ac-items').animate(
				{
					opacity: 0
				},
				500
			);
			$('#ac-items-cont').animate(
				{
					height: itemsH
				}, 
				500,
				function() {
					$('#ac-items').load(
						panelBase+curPanel+'/',
						function() {
							
							if (curPanel == panelNum) $('#npanel').hide();
							if (curPanel == 2) $('#ppanel').css('display','inline-block');
							try { // google
								_gaq.push(['_trackPageview']);
							} 
							catch (e) {}
							var newItemsH = parseInt($('#ac-items').css('height'));
							if (newItemsH>itemsH) {
								var diff = '+='+(newItemsH-itemsH);
							}
							if (newItemsH<itemsH) {
								var diff = '-='+(itemsH-newItemsH);
							}
							if (newItemsH==itemsH) {
								var diff = '+='+0;
							}	
							$('#ac-items-cont').animate(
								{
									height: diff
								},
								500,
								function() {
									$('#ac-items').animate(
										{
											opacity: 100
										},
										500,
										function() {
											if(jQuery.browser.msie) {
				                                this.style.removeAttribute('filter');
		                					} 
										}
									);
								}
							);
						}
					);
				}
			);
			return false;
		}
	);

	if (jQuery.browser.msie) {
		$('.imglink').css('white-space','nowrap');
	}
	
	$('#resetmailfields').click(
		function() {
			
			$('#invia-nome').val('Il tuo nome');
			$('#invia-email').val('Indirizzo E-mail');
			$('#invia-dest').val('Indirizzo E-mail destinatario');
			$('#invia-oggetto').val('Oggetto messaggio');
			$('#invia-messaggio').val('Scrivi messaggio');
			
			return false;
		}
	);	
	
	$('#sendmail').click(
		function() {
			
			return false;
		}
	);
	
	$('.selected-approfondimenti').click(
		function() {
		if (selInit2 == 0) {
        	selInit2=1;
			altezzatendina_approfondimenti = $('#tendina-approfondimenti').css('height');
			$('#tendina-approfondimenti').css('height', 'auto');
			$(this).addClass('open');
		} else {
			$('#tendina-approfondimenti').css('height', altezzatendina_approfondimenti);
			$(this).removeClass('open');
			selInit2 = 0;
		}
		return false;
		}
	); 	
	
	$('#apricategorie').click(
		function() {
			$("#morecategories").slideDown('fast',
				function() {
					$('.apricategorie').hide();
					$('.chiudicategorie').show();								
				}
			);
			return false;			
		}
		
	);
	
	$('#chiudicategorie').click(
		function() {
			$("#morecategories").slideUp('fast',
				function() {
					$('.chiudicategorie').hide();
					$('.apricategorie').show();								
				}
			);
			return false;			
		}
		
	);	
	
	if ( $('.txt-img ul.prima').css('display') == 'none' )  mobile = true;
	if ( $('.txtonly ul.prima').css('display') == 'none' )  mobile = true;
	var primaH = $('.txt-img ul.prima').height();
	
	$('.txt-img h6').click(
		function() {
			if (mobile) {
				if (mobIndex==1) {
					$('.txt-img ul.prima').animate(
						{height:0},
						250,
						function() {
							$('.txt-img h6').removeClass('open');
							mobIndex=0;							
						}
					);
				} else {
					$('.txt-img ul.prima').css({'height':'0','overflow':'hidden'}).show().animate(
						{height:primaH},
						250,
						function() {
							$('.txt-img h6').addClass('open')
							mobIndex=1;							
						}
					);
				}
			}
		}
	);
	var primaaH = $('.txtonly ul.prima').height();
	$('.txtonly h6').click(
		function() {
			if (mobile) {
				if (mobIndex==1) {
					$('.txtonly ul.prima').animate(
						{height:0},
						250,
						function() {
							$('.txtonly h6').removeClass('open');
							mobIndex=0;							
						}
					);
				} else {
					$('.txtonly ul.prima').css({'height':'0','overflow':'hidden'}).show().animate(
						{height:primaaH},
						250,
						function() {
							$('.txtonly h6').addClass('open')
							mobIndex=1;							
						}
					);
				}
			}
		}
	);	

});
