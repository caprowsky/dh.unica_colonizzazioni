// Provide a default path to dwr.engine
if (dwr == null) var dwr = {};
if (dwr.engine == null) dwr.engine = {};
if (DWREngine == null) var DWREngine = dwr.engine;
if (FavorisService == null) var FavorisService = {};
FavorisService._path = '/dwr';
FavorisService.saveFavoris = function(p0, p1, p2, p3, p4, p5, callback) {
  dwr.engine._execute(FavorisService._path, 'FavorisService', 'saveFavoris', p0, p1, p2, p3, p4, p5, callback);
}
FavorisService.deleteFavoris = function(p0, p1, callback) {
  dwr.engine._execute(FavorisService._path, 'FavorisService', 'deleteFavoris', p0, p1, callback);
}
FavorisService.getFavoris = function(p0, p1, p2, p3, p4, callback) {
  dwr.engine._execute(FavorisService._path, 'FavorisService', 'getFavoris', p0, p1, p2, p3, p4, callback);
}
FavorisService.getMessage = function(p1, callback) {
  dwr.engine._execute(FavorisService._path, 'FavorisService', 'getMessage', false, p1, callback);
}
FavorisService.getTxTemplate = function(callback) {
  dwr.engine._execute(FavorisService._path, 'FavorisService', 'getTxTemplate', callback);
}
FavorisService.setTxTemplate = function(p0, callback) {
  dwr.engine._execute(FavorisService._path, 'FavorisService', 'setTxTemplate', p0, callback);
}
FavorisService.getUserTransaction = function(callback) {
  dwr.engine._execute(FavorisService._path, 'FavorisService', 'getUserTransaction', callback);
}
