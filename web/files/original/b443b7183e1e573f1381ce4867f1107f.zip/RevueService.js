// Provide a default path to dwr.engine
if (dwr == null) var dwr = {};
if (dwr.engine == null) dwr.engine = {};
if (DWREngine == null) var DWREngine = dwr.engine;
if (RevueService == null) var RevueService = {};
RevueService._path = '/dwr';
RevueService.getContextualTagsPool = function(p0, callback) {
  dwr.engine._execute(RevueService._path, 'RevueService', 'getContextualTagsPool', p0, callback);
}
RevueService.setRevueI18nValue = function(p0, p1, p2, p3, callback) {
  dwr.engine._execute(RevueService._path, 'RevueService', 'setRevueI18nValue', p0, p1, p2, p3, callback);
}
RevueService.getRevueI18nValue = function(p0, p1, p2, p3, callback) {
  dwr.engine._execute(RevueService._path, 'RevueService', 'getRevueI18nValue', p0, p1, p2, p3, callback);
}
RevueService.getMessage = function(p1, callback) {
  dwr.engine._execute(RevueService._path, 'RevueService', 'getMessage', false, p1, callback);
}
RevueService.getTxTemplate = function(callback) {
  dwr.engine._execute(RevueService._path, 'RevueService', 'getTxTemplate', callback);
}
RevueService.setTxTemplate = function(p0, callback) {
  dwr.engine._execute(RevueService._path, 'RevueService', 'setTxTemplate', p0, callback);
}
RevueService.getUserTransaction = function(callback) {
  dwr.engine._execute(RevueService._path, 'RevueService', 'getUserTransaction', callback);
}
