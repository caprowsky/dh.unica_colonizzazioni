// checkAllRecords.
// take a FORM object as an argument, and set all the checkbox objects
// in that form to "checked", return false

// for ACLSfront media files
var fileWindow;
function popupMediaWindow(URLstr)
{      
  if (fileWindow) {
    // for some reason, window.focus() isn't working so we close it only to reopen it again 
    fileWindow.close();
    fileWindow = open( URLstr, "aclsmedia", "scrollbars=1,resizable=1,width=650,height=450");
  } else {
    fileWindow = open( URLstr, "aclsmedia", "scrollbars=1,resizable=1,width=650,height=450");
  }
}


function popupMediaWindowtest(URLstr)
{
  if (fileWindow) {
    // for some reason, window.focus() isn't working so we close it only to reopen it again 
    fileWindow.close();
    fileWindow = open( URLstr, "aclsmedia", "scrollbars=1,resizable=1,width=650,height=450");
  } else {
    fileWindow = open( URLstr, "aclsmedia", "scrollbars=1,resizable=1,width=650,height=450");
  }
}

function popupFlashWindow(object,rend) {
//  alert(object);

  var winstring = rend.replace(/:/g,"=");
  var winvariables = winstring.split(";",3);

  var quality = winvariables[0].replace(/quality=/,"");
//  document-write(quality);
  var width_orig = winvariables[1].replace(/width=/,"");
//  document.write(width)
    var width = eval(width_orig)+100;
  var height_orig = winvariables[2].replace(/height=/,"");
//  document.write(height);
    var height = eval(height_orig)+60;


//  document.write(winvariables[0] + "," + winvariables[1] + winvariables[2]);
  myWin= open("", "displayWindow","width=" + width + ",height=" + height + ",status=yes,toolbar=yes,menubar=yes,left=100,top=50");

  // open document for further output
  myWin.document.open();

  // create document
  myWin.document.write("<html><head><title>Flash Movie");
  myWin.document.write("</title><link rel=\"stylesheet\" href=\"/a/acls/textclass-specific.css\" type=\"text/css\"></head><body style=\"background-color:#000\">");
  myWin.document.write("<div id=\"flash\"><object type=\"application/x-shockwave-flash\" data=\""+ object + "\" ");
  myWin.document.write("quality=\"" + quality + "\" width=\"" + width_orig + "\" height=" + height_orig + "\"></center>");
  myWin.document.write("<embed src=\"" + object + "\" " +  "\" width=\"" + width_orig + "\" height=" + height_orig + "\"></embed>");
  myWin.document.write("<param name=\"movie\" value=\"" + object + "\">");
  myWin.document.write("</object></div>");
  myWin.document.write("</body></html>");

  // close the document - (not the window!)
  myWin.document.close();
}

function checkAllRecords(theform)
{

  var ele = "";

  for (var i = 0; i < theform.elements.length; i++)
  {
    ele = theform.elements[i];

    if (ele.type == "checkbox")
    {
      ele.checked = true;
    }
  }

  return false;
}
/* ##################################### */
function saveRecordsToBookbag(theform)
{
  theform.submit();
  
  return false;
}
/* ##################################### */
var notesWindow = 0;

function popupNotesWindow( URLstr )
{
    
		//notesWindow = window.open( '', "targetWindow", "scrollbars=1,resizable=1,width=800,height=480" );
    notesWindow = window.open( '', "targetWindow", "scrollbars=1,resizable=1,width=650,height=450" );
		notesWindow.name = 'targetWindow';

        notesWindow.document.location = URLstr;
}
/* ##################################### */
// for ACLSfront notes section window
// var targetWindow = 0;
// function gotoNotesSectionWindow( URLstr )
// {
//     document.location = URLstr;
//     if ( targetWindow ){ targetWindow.close(); }
// 
// }



/* ##################################### */
var mapWindow = 0;

function popupMapWindow( URLstr )
{

		mapWindow = window.open( '', "targetWindow", "scrollbars=1,resizable=1,width=650,height=450" );
		mapWindow.name = 'targetWindow';

        mapWindow.document.location = URLstr;
}




/* ##################################### */
// for related titles
var relatedWindow = 0;
function popupRelatedWindow( URLstr )
{
    relatedWindow = window.open( '', "targetWindow", "scrollbars=1,resizable=1,width=650,height=450" );

    relatedWindow.document.location = URLstr;
}
/* ##################################### */
// for ic images
function popupImageClassWindow( URLstr )
{    
    window.open( URLstr, "", "scrollbars=1,resizable=1,width=650,height=450");
}
/* ##################################### */

// for ACLSfront figs
var imagesWindow = 0;
function popupImagesWindow( URLstr, IMGwidth, IMGheight )
{
	// numberify the width and height
	var winwidth = Number(IMGwidth) + 30;
	var winheight = Number(IMGheight) + 30; 
 
    var WinFeatures =
        'width='        + winwidth +
        ',height='      + winheight +
        ',menubar='     + "no" +
        ',scrollbars='  + "yes" +
        ',resizable='   + "yes";  
        
    var winHtml =
    '<html>\n<head><title>ACLS Humanities E-Book: [image]</title>\n' +
    '<link rel="stylesheet" href="/a/acls/textclass-specific.css" type="text/css"><head>\n' +
    '<script type="text/javascript" language="javascript">\n' +
    '<!-- window.name = "aclsfigure"; -->\n' +
    '</script>\n' +
    '<body bgcolor="#ffffff">\n<div align="center" class="imagewindow">\n' +
    '<img src="' + 
    URLstr + 
    '" width="' + 
    IMGwidth + 
    '" height="' + 
    IMGheight + '" border="0" alt="click to close window" onclick="window.close()">' +
    '\n</div>\n</body>\n</html>';        
           
    if ( imagesWindow && ( ! imagesWindow.closed ) )
    {
		imagesWindow.window.resizeTo( winwidth,winheight);
		imagesWindow.focus();
    }
    else
    {
        imagesWindow = window.open( '', "aclsfigure", WinFeatures );
    }
    
    imagesWindow.document.open();
    imagesWindow.document.write( winHtml );
    imagesWindow.document.close();
}


/* ##################################### */		

function reviews_window( url ) 
{
    var winOptions = 'alwaysraised=1,toolbar=1,location=1,directories=1,status=1,' +
                     'menubar=1,scrollbars=1,resizeable=1,resizable=1,width=650,height=450';
    
    if (url !== '') 
    {  // if the value of the selected is not empty
        special=window.open(url, "review", winOptions);
    }
}


// For Custom WAYF (loginoptions, accessoptions)
function goto_page(url) {
    if (url != "" ) {
	if (url == "0" ) {
	    alert("Please select your institution");
	}
	else {
	    window.location.href = url;
	}
    }
    return false;
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
$(document).ready(function() {

  // since dlxs now requires jquery for pdf handling, make use of jquery

  $(window).load(function() {
    if ( $('select[name=q2]').val() ) {
      check_series_pulldown( $('select[name=q2]').val() );
    }
  });
  $('select[name=q2]').change(function() {
    check_series_pulldown( $('select[name=q2]').val() );
  });


});
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */ 

// function check_series_pulldown(series) {}

