$(document).ready(function() {
  prepareSearchTypeForSearchPage();
});

$(window).load(function() {
  headerMinHeight();
});

// - - - - - - - - - - - - - - - - - - - - - - - - -
function headerMinHeight() {

  // Set .content_top to minimum height equal to cover image
  var content_top  = $('.content-top');
  var cover        = $('#cover-image-wrapper img');
  if ( $(content_top).length > 0 && $(cover).length > 0 ) {
    var height = $(cover).attr('height');
    height += 30; // So ~10px "padding" on top & bottom
    $(content_top).css('min-height', height + 'px');
  }

  // Set height of cover-image-header to match header 
  // (so that text is consistently left aligned)
  var header  = $('#header');
  var cover_w = $('#cover-image-wrapper');
  if ( $(header).length > 0 && $(cover_w).length > 0 ) {
    var height = $(header).css('height');
    $(cover_w).css('height', height);
  }

}

// - - - - - - - - - - - - - - - - - - - - - - - - -
function prepareSearchTypeForSearchPage() {
  // On "Basic Search" page...
  if( $('#search').length && $('input[name=rgn2]').val() === 'series' ) {

    // If series is 'ACLS Humanities E-Book', type is 'simple'
    // Otherwise, type is 'bib'.
    //
    // This is done so that most searches (across all of HEB)
    // will be sorted by frequency (which is what rgn 'simple'
    // accomplishes).
    var rgn      = $('input[name=type]');
    var dropdown = $('#q2.selectmenu');
    var sort     = $('input[name=sort]');

    $(dropdown).change(function() {
      if ( $(dropdown).val() == $(dropdown).find('option:first-child') ) {
        $(rgn ).attr('value','simple');
        $(sort).attr('value','freq');
      } else {
        $(rgn ).attr('value','bib');
        $(sort).attr('value','title');
      }
    });
  }
}
