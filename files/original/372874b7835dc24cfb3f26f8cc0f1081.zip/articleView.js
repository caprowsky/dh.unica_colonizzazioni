<!DOCTYPE html>



<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="it"
      lang="it">

<head>
	<meta charset="utf-8" />
<title>Forum Editrice &mdash; Forum Editrice</title>

    
	  
	<base href="http://www.forumeditrice.it/" />
	  
	

<link href="/favicon.ico" rel="icon" />

      
        
            
                <script type="text/javascript"
                        src="http://www.forumeditrice.it/portal_javascripts/Plone%20Default/ploneScripts3197.js">
                </script>
                
            
        
    
    



        
            
                
                    <link rel="stylesheet" type="text/css"
                          media="print"
                          href="http://www.forumeditrice.it/portal_css/Plone%20Default/ploneStyles4778.css" />
                    
                    
                
            
            
                
                    <link rel="stylesheet" type="text/css"
                          href="http://www.forumeditrice.it/portal_css/Plone%20Default/ploneStyles3147.css" />
                    
                    
                
            
        
    







    
    
    
    



</head>
<body>


<div id="portal-top">
	<div id="portal-header">


<ul id="topmenu">
	<li style="width:103px"><a href="http://www.forumeditrice.it/informazioni"><img
    alt="Informazioni" title=""
    src="http://www.forumeditrice.it/img/informazioni.gif" /></a></li>
	<li style="width:71px"><a href="http://www.forumeditrice.it/ricerca"><img
    alt="Ricerca" title=""
    src="http://www.forumeditrice.it/img/ricerca.gif" /></a></li>
	<li style="width:78px"><a href="http://www.forumeditrice.it/carrello"><img
    alt="Acquisti" title=""
    src="http://www.forumeditrice.it/img/acquisti.gif" /></a></li>
	<li style="width:66px"><a href="http://www.forumeditrice.it/agora"><img
    alt="Agorà" title=""
    src="http://www.forumeditrice.it/img/agora.gif" /></a></li>
	<li style="width:113px"><a href="http://www.forumeditrice.it/recensioni"><img
    alt="Recensioni" title=""
    src="http://www.forumeditrice.it/img/recensioni.gif" /></a></li>
	<li style="width:121px"><a href="http://www.forumeditrice.it/appuntamenti"><img
    alt="Appuntamenti" title=""
    src="http://www.forumeditrice.it/img/appuntamenti.gif" /></a></li>
	<li style="width:208px"><img alt="In primo piano" title=""
    src="http://www.forumeditrice.it/img/in-primo-piano.gif" /></li>
</ul>

<div id="top-percorsi">
<h3><a href="http://www.forumeditrice.it/percorsi/"><img
    alt="Percorsi"
    src="http://www.forumeditrice.it/img/percorsi.gif" /></a></h3>
<ul>
  <li><a href="http://www.forumeditrice.it/percorsi/lingua-e-letteratura"><img
    src="/img/lingua-e-letteratura.gif"
    alt="Lingua e letteratura" /></a></li>
  <li><a href="http://www.forumeditrice.it/percorsi/storia-e-societa"><img
    src="/img/storia-e-societa.gif" alt="Storia e società" /></a></li>
  <li><a href="http://www.forumeditrice.it/percorsi/arte"><img
    src="/img/arte.gif" alt="Arte e spettacolo" /></a></li>
  <li><a href="http://www.forumeditrice.it/percorsi/forum-fvg"><img
    src="/img/forum-fvg.gif" alt="Forum FVG" /></a></li>
  <li><a href="http://www.forumeditrice.it/percorsi/ejournal"><img
    src="/img/ejournal.gif" alt="E-journal" /></a></li>
  <li><a href="http://www.forumeditrice.it/percorsi/scienze-bibliografiche"><img
    src="/img/scienze-bibliografiche.gif"
    alt="Scienze bibliografiche" /></a></li>
  <li><a href="http://www.forumeditrice.it/percorsi/scienza-e-tecnica"><img
    src="/img/scienza-e-tecnica.gif" alt="Scienza e tecnica" /></a></li>
  <li><a href="http://www.forumeditrice.it/percorsi/didattica"><img
    src="/img/didattica.gif" alt="Didattica" /></a></li>
</ul>
</div>


<div id="avvisi">

	<a href="http://www.forumeditrice.it/appuntamenti">UDINE, "GENIUS LOCI"</a>
	Udine, Libreria Friuli<br />
<br />
<span style="font-weight: bold;">22.11.2013 18.00h</span>


</div>

</div>
	<div id="portal-breadcrumbs">
    <strong><a href="http://www.forumeditrice.it">Home</a></strong>

</div>
	









</div>
<div id="container" class="bicol">
	  
	

	  

	<a name="documentContent"></a>



    



	

<div id="colsx">
<a href="http://www.forumeditrice.it"><img
    alt="Forum Editrice"
    src="http://www.forumeditrice.it/img/logo-mini.gif" /></a>
	
</div>


	

<img id="logo_grande" src="img/forum_ed.gif" alt="Forum Editrice" />

<table id="home" cellspacing="0">

<tr id="big">

<td colspan="2">

A cura di Alberto Felice De Toni e Davide Zoletto
<h2><a href="http://www.forumeditrice.it/percorsi/storia-e-societa/multiverso/multiverso-12-2013-margine">Multiverso, 12/2013<br />
MARGINE</a></h2>


<p>Il margine, di per sè, implica sempre l'esistenza di un centro. Ma tanto più quest'ultimo ha una sua connotazione certa e conosciuta, tanto più il margine è invece indefinito, vago, sfumato, fino a diventare altro...
 <a class="fulltext"
    href="http://www.forumeditrice.it/percorsi/storia-e-societa/multiverso/multiverso-12-2013-margine">&gt;</a></p>
</td>

<td><a href="http://www.forumeditrice.it/percorsi/storia-e-societa/multiverso/multiverso-12-2013-margine"><img
    alt="Copertina" title=""
    src="http://www.forumeditrice.it/percorsi/storia-e-societa/multiverso/multiverso-12-2013-margine/copertina_medium" /></a></td>
</tr>

<tr class="small">
	<td>

	<a href="http://www.forumeditrice.it/percorsi/storia-e-societa/varia/noi-che-siamo-cosi-poveri-nel-dire"><img
    alt="Copertina" title=""
    src="http://www.forumeditrice.it/percorsi/storia-e-societa/varia/noi-che-siamo-cosi-poveri-nel-dire/copertina_mini"
    style="padding-bottom: -1px" /></a>

<h3><a href="http://www.forumeditrice.it/percorsi/storia-e-societa/varia/noi-che-siamo-cosi-poveri-nel-dire">Noi che siamo così poveri nel dire</a></h3>
Danilo De Marco



<p>Fotografo e giornalista indipendente da oltre vent'anni, Danilo De Marco ha camminato mezzo mondo: dal Tibet al Messico, dalle montagne dei Kurdi in Turchia e Iraq alle selve degli U'wa in Colombia, fino alle Ande dell'Equador... <a
    class="fulltext"
    href="http://www.forumeditrice.it/percorsi/storia-e-societa/varia/noi-che-siamo-cosi-poveri-nel-dire">&gt;</a></p>

</td>
	<td>

	<a href="http://www.forumeditrice.it/percorsi/forum-fvg/cultura-locale/udine-genius-loci"><img
    alt="Copertina" title=""
    src="http://www.forumeditrice.it/percorsi/forum-fvg/cultura-locale/udine-genius-loci/copertina_mini"
    style="padding-bottom: 5px" /></a>

<h3><a href="http://www.forumeditrice.it/percorsi/forum-fvg/cultura-locale/udine-genius-loci">Udine “Genius Loci”</a></h3>
Elena Commessatti



<p>Se avete intenzione di lasciare Udine e di trasferirvi altrove, fatelo ma prima mettete in valigia Udine Genius Loci di Elena Commessatti, perchè vi servirà quando la nostalgia si farà sentire e quando deciderete di ritornare... <a
    class="fulltext"
    href="http://www.forumeditrice.it/percorsi/forum-fvg/cultura-locale/udine-genius-loci">&gt;</a></p>

</td>
	<td>

	<a href="http://www.forumeditrice.it/percorsi/storia-e-societa/varia/belluno-storia-di-una-provincia-dolomitica"><img
    alt="Copertina" title=""
    src="http://www.forumeditrice.it/percorsi/storia-e-societa/varia/belluno-storia-di-una-provincia-dolomitica/copertina_mini"
    style="padding-bottom: 23px" /></a>

<h3><a href="http://www.forumeditrice.it/percorsi/storia-e-societa/varia/belluno-storia-di-una-provincia-dolomitica">Belluno. Storia di una provincia dolomitica</a></h3>


A cura di Paolo Conte

<p>L'opera, suddivisa in tre volumi raccolti in un cofanetto, ricostruisce la storia della provincia di Belluno dalle origini ai nostri giorni. Vengono proposti una serie di approfondimenti di carattere storiografico... <a
    class="fulltext"
    href="http://www.forumeditrice.it/percorsi/storia-e-societa/varia/belluno-storia-di-una-provincia-dolomitica">&gt;</a></p>

</td>
</tr>
</table>

<div id="inprimopiano">

<ul id="fotohome">
	<li class="first"><img alt="" src="img/home1.gif" /></li>
	<li><img alt="" src="img/home2.gif" /></li>
	<li><img alt="" src="img/home3.gif" /></li>
	<li><img alt="" src="img/home4.gif" /></li>
	<li><img alt="" src="img/home5.gif" /></li>
</ul>
	

		<div><a href="http://www.multiversoweb.it/"><img width="194" alt="" src="/testo-home-page/1multiversoweb.jpg/image_preview" /></a></div>
<div><span style="font-weight: normal;">Uno spazio libero e aperto di dibattito in cui discutere i problemi che inquietano la contemporaneità, per cercare risposte o nuove domande non scontate.</span></div>
<div>
<p class="MsoNormal"><span lang="EN-US" style="font-size: 10pt;"><span class="smaller"><a href="http://www.multiversoweb.it/"><br />
www.multiversoweb.it</a><br />
<a href="http://www.multiversoweb.it/contatti/">multiverso@multiversoweb.it<br />
</a></span></span></p>
<p style="font-weight: bold;"><a href="/percorsi/storia-e-societa/multiverso/"><span class="red">ORDINALA IN RETE </span></a></p>
<div class="hr"><hr /></div>
<a href="/university-press-italiane/"><img width="90" height="90" alt="UPI
logo -
JPG.jpg" src="/testo-home-page/upi_logo_-_jpg.jpg" /></a><br />
<span class="moz-txt-link-freetext">Visita il <span style="font-weight: bold;">sito delle UPI</span><br />
<a href="http://www.universitypressitaliane.com/"><span class="smaller">www.universitypressitaliane.com <br />
<br />
</span></a></span><span style="font-weight: normal;"><span style="font-weight: bold;"><span class="red">NEWS</span></span><br />
Protocollo d'intesa tra le University Press Italiane per la definizione dei criteri di scientificità delle pubblicazioni di alta divulgazione<br />
</span><br />
<span style="font-weight: normal;"><span style="font-weight: bold;"><a href="/university-press-italiane#Firmato" target="Firmato un Protocollo per la definizione dei criteri di scientificità delle pubblicazioni "><span class="red">Protocollo UPI 2013<br />
</span></a></span></span><div class="hr"><hr /></div>
<br />
<span style="font-weight: bold;"><a target="_blank" href="/testo-home-page/1forum_catalogo_2010.pdf"><br />
<br />
</a></span><span style="font-weight: bold;"><span style="font-weight: bold;">&nbsp; </span></span><span style="font-weight: bold;"><span style="font-weight: bold;"><span style="font-size:9.0pt;font-family:Verdana;mso-fareast-font-family:&quot;Times New Roman&quot;;
mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:IT;mso-fareast-language:
IT;mso-bidi-language:AR-SA"><span style="font-size:9.0pt;font-family:Verdana;mso-fareast-font-family:&quot;Times New Roman&quot;;
mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:IT;mso-fareast-language:
IT;mso-bidi-language:AR-SA"><span style="font-size:9.0pt;font-family:Verdana;mso-fareast-font-family:&quot;Times New Roman&quot;;
mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:IT;mso-fareast-language:
IT;mso-bidi-language:AR-SA"><br style="mso-special-character:line-break" />
<br style="mso-special-character:line-break" />
</span></span></span></span></span></div>
	
</div>



	

	  


</div>
<div id="footer">
<address>
Forum Editrice Universitaria Udinese S.r.l.<br />
via Larga, 38 - 33100 Udine<br />
Tel +39 0432 26001 / Fax +39 0432 296756<br />
e-mail <a href="mailto:forum@forumeditrice.it">forum@forumeditrice.it</a><br />
C.F. e P.IVA 01896560305


</address>




<script>
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-1813714-1']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = 'http://www.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>

</div>
</body>
</html>
