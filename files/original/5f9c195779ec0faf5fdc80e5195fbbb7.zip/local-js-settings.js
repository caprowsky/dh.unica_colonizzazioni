
/* 
################################################################## 
## 
##   THIS IS A GENERATED FILE. 
## 
##   ANY CHANGES YOU MAKE DIRECTLY TO THIS FILE WILL BE OVERWRITTEN 
##   AND LOST THE NEXT TIME THIS FILE IS GENERATED. 
## 
##  (This file last generated: Sep 04, 2013, 11:40 A.M.) 
## 
################################################################## 
 */

/* ##### BELOW added by: file:/mayshare02/shared/webapp/modules/spehq/resources/shared/build/local-js-settings.base.xml ##### */


  

	/*
	#####################################################################################
    #
    # IMPORTANT: This file won't be used until you put:
    #
    # <gen:var name="use-local-js-settings">yes</gen:var>
    #
	# into your build.xsl or similar file. That's because this file will be blank for the
    # vast majority of sites, and it's wasted calls for browsers. 
    #
    #####################################################################################
	
	*/


  


/* ##### END OF ADDED BLOCK ##### */
