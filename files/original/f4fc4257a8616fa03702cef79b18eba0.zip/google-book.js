var PageContener = {	
maxWidth:0,
maxHeight:0,
resolution:710,
padding:20,
border:1,
currentZoom:0,
zoom:[500,650,710,800,950,1100,2000],
urn:null,
words:null,
init: function(resolution,maxWidth,maxHeight,urn,words){
this.words      = words;
this.maxWidth  = maxWidth;
this.maxHeight = maxHeight;
this.resolution = resolution;
this.urn        = urn;
        this.zoom[this.zoom.length-1] = maxWidth;
for(var i = 0; i<this.zoom.length ;i++){
if(this.zoom[i]==this.resolution){
this.currentZoom = i;
break;
}
}
},
loadDiv:   function(pageDiv,pageNumber,page){
    pageDiv.addClass("pageImgLoading")
    	   .height(this.getHeight()+"px")
       .width(this.getWidth(page.angle)+"px")
 	   .css({position:'absolute',padding:this.padding,top:pageNumber*this.getHeight()+"px"})
 	   .attr({id:"pageNum-"+pageNumber});
this.preload(pageDiv, page);
return pageDiv;
},
preload : function(pageDiv, page){
pageDiv.append(jQuery("<img/>").addClass("pageImg")
.attr({src:themeDisplay.getURLHome()+"/renderPage/"+this.urn+"/"+page.angle+"/"+ this.resolution +"/"+page.pageId+".jpg"})
.load(function() {
PageContener.appendRects(pageDiv, page);
pageDiv.removeClass("pageImgLoading");
jQuery(this).unbind().fadeIn("slow");
   				 }).each(function(){
                        if (this.complete || this.complete == undefined){ this.src = this.src; }
   				 }).css('display','none') );
},
 appendRects : function(pageDiv,page){
 	pageDiv.find(".searchWords").remove();
 	if(this.words!=null && this.words.length>0){
 	ArticleService.listWords(this.urn,page.pageId,this.words,
 	function(rects){
 		if(rects!=null){
 			var zoomFactor = (PageContener.resolution/page.width);
 		for(var i=0;i<rects.length;i++){ 
 			var size = PageContener.translate(rects[i].width,rects[i].height,page.angle,zoomFactor);
 			var pos =  PageContener.translatePos(rects[i],page,zoomFactor);
 			pageDiv.append( jQuery("<div/>")
 			.height(size.y+"px")
 		.width(size.x+"px")
 		.css({position:'absolute',top:(pos.y+PageContener.border+PageContener.padding)+"px",left:(pos.x+PageContener.border+PageContener.padding)+"px",'background-color':rects[i].color,'z-index':99})
 		.addClass("searchWords"));		
 		}
 		}
 	});
 	}
 },
zoomIn : function(){
if((this.currentZoom+1)<this.zoom.length){
this.currentZoom++;
this.resolution = this.zoom[this.currentZoom];
return true;
}
return false;
},
zoomOut : function(){
if((this.currentZoom-1)>0){
this.currentZoom--;
this.resolution = this.zoom[this.currentZoom];
return true;
} 
return false;
},
 getHeight : function(){
 	return this.translate(this.maxWidth,this.maxHeight,0,this.getZoomFactor()).y+2*(this.padding+this.border);
 },
 getWidth : function(angle){
 	return this.translate(this.maxWidth,this.maxHeight,angle,this.getZoomFactor()).x;
 },
 getZoomFactor : function(){
 	return  this.resolution / this.maxWidth;
 },
 translate : function(vx,vy,angle,zoomFactor){
 	return {
 		x:parseInt(Math.abs(vx*zoomFactor*Math.cos(angle*Math.PI/180) + vy*zoomFactor*Math.sin(angle*Math.PI/180))),
 		y:parseInt(Math.abs(vx*zoomFactor*Math.sin(angle*Math.PI/180) + vy*zoomFactor*Math.cos(angle*Math.PI/180)))
 	};
 },
 translatePos : function(rect,page,zoomFactor){
 var nbiter = page.angle/90;
if(nbiter<0){
 nbiter+=4;
}
var x=rect.x,y=rect.y;
var w = rect.width, h=rect.height;
for(var i=0; i<nbiter;i++){
 var tmp = y;
 y = -x + Math.abs(Math.cos(i*Math.PI/2)*page.width+Math.sin(i*Math.PI/2)*page.height) 
 	 - Math.abs(Math.cos(i*Math.PI/2)*w+Math.sin(i*Math.PI/2)*h) ;
 x = tmp ;
  }
return {x:x*zoomFactor,y:y*zoomFactor};
 }
 
 
}
var ScrollImageContener = {
contener:null,
scrollContener:null,
currentPage:0,
prevPage:0,
offset:1,
rotateFactor:90,
pageSequence:null,
sizeNorm: 0, 
waitFinish: false,
init: function(el,pageId,sequence,resolution,urn,words){
    this.pageSequence = sequence;
var isCurrentPageOk = false;
for(var i=0;i<this.pageSequence.length-1;i++){
if(this.pageSequence[i].pageId==pageId){
this.currentPage=i;
isCurrentPageOk = true;
break;
}
}
if(!isCurrentPageOk){
this.currentPage = 0;
} 
this.prevPage = this.currentPage;
PageContener.init(
resolution,this.pageSequence[this.pageSequence.length-1].width,
this.pageSequence[this.pageSequence.length-1].height,urn,words);
this.contener = jQuery("<div/>");
this.scrollContener = jQuery("#scrollConteneur");
this.scrollContener.append(this.contener);
this.scrollContener.bind('scroll',ScrollImageContener.scrollEventHandler);
this.sizeNorm = this.scrollContener.width();
this.scrollContener.width(this.sizeNorm);
this.pageUpdate();
PaginationContener.update();
},
scrollEventHandler : function (){
jQuery(this).unbind('scroll');
var scrollOffset =  ScrollImageContener.scrollContener.scrollTop();
 ScrollImageContener.currentPage = (scrollOffset - scrollOffset%PageContener.getHeight() )/PageContener.getHeight();
 PaginationContener.update();
 if(Math.abs(ScrollImageContener.prevPage - ScrollImageContener.currentPage )>1){
ScrollImageContener.pageUpdate();
ScrollImageContener.prevPage = ScrollImageContener.currentPage;
 } else {
 if(ScrollImageContener.currentPage>ScrollImageContener.offset
  	 && ScrollImageContener.currentPage<((ScrollImageContener.pageSequence.length-1)-(ScrollImageContener.offset+1))){
if(ScrollImageContener.prevPage>ScrollImageContener.currentPage ){
ScrollImageContener.onScrollUp();
ScrollImageContener.prevPage = ScrollImageContener.currentPage;
} else  if(ScrollImageContener.prevPage<ScrollImageContener.currentPage ){
 ScrollImageContener.onScrollDown();
 ScrollImageContener.prevPage = ScrollImageContener.currentPage;
}
  }
 }
 jQuery(this).bind('scroll',ScrollImageContener.scrollEventHandler);
},
onScrollUp: function(){
var page = this.contener.find('div.pageDiv:last-child').empty();
var index = this.currentPage-(this.offset);
this.contener.prepend(PageContener.loadDiv(page,index,this.pageSequence[index]));
},
onScrollDown: function(){
var page = this.contener.find('div.pageDiv:first-child').empty();
var index = this.currentPage+(this.offset+1);
this.contener.append(PageContener.loadDiv(page,index,this.pageSequence[index]));
},
zoomIn : function(){
if(PageContener.zoomIn()){
this.pageUpdate();
}
},	
zoomOut : function(){
if(PageContener.zoomOut()){
this.pageUpdate();
}
},
pageUpdate : function(){		
this.contener.height(PageContener.getHeight()*(this.pageSequence.length-1));
this.contener.empty();
var start = Math.max(this.currentPage-(this.offset),0);
var end = Math.min(this.pageSequence.length-1,start+((this.offset+1)*2));
DWREngine.beginBatch();
for(var i=start;i<end;i++){
var page = jQuery("<div/>").addClass("pageDiv");
   page = PageContener.loadDiv(page,i,this.pageSequence[i]);
this.contener.append(page);
}
DWREngine.endBatch();
jQuery("#scrollConteneur").scrollTop(PageContener.getHeight()*(this.currentPage));
},
next: function(){
if(this.currentPage+1<(this.pageSequence.length-1)){
 	 jQuery("#scrollConteneur").scrollTop(PageContener.getHeight()*(this.currentPage+1));
}
},
prev : function(){
if(this.currentPage>0){
 jQuery("#scrollConteneur").scrollTop(PageContener.getHeight()*(this.currentPage-1));
} 
},
jump : function(pageNum) {
for(var i=0;i<(this.pageSequence.length-1);i++){
if(this.pageSequence[i].pageNumber==pageNum){
this.currentPage=i;
this.pageUpdate();
return;
}
}
},
jumpToPageId : function(pageId) {
for(var i=0;i<(this.pageSequence.length-1);i++){
if(this.pageSequence[i].pageId==pageId){
this.currentPage=i;
this.pageUpdate();
return;
}
}
},
rotateLeft : function(){
var index = this.currentPage;
var page = this.contener.find("#pageNum-"+index).empty();
this.pageSequence[index].angle +=this.rotateFactor; 
 	this.pageSequence[index].angle = this.pageSequence[index].angle%360;
 	page = PageContener.loadDiv(page,index,this.pageSequence[index]);
},
rotateRight : function(){
var index = this.currentPage;
var page = this.contener.find("#pageNum-"+index).empty();
this.pageSequence[index].angle -=this.rotateFactor; 
 	this.pageSequence[index].angle = this.pageSequence[index].angle%360;
page = PageContener.loadDiv(page,index,this.pageSequence[index]);
},
    refreshCurrentPage : function(){
var index = this.currentPage;
var page = this.contener.find("#pageNum-"+index).empty();
page = PageContener.loadDiv(page,index,this.pageSequence[index]);
},
   fullscreenMono : function(){
if(jQuery("#fullscreen_google").is(".fullscreen_google")){
ScrollImageContener.zoomOut();
jQuery("#mainContentLeft").removeClass("displayNone");
jQuery("#mainContentLeft").addClass("displayBlock");
jQuery("#scrollConteneur").width(ScrollImageContener.sizeNorm);
} else {
ScrollImageContener.zoomIn();
jQuery("#mainContentLeft").removeClass("displayBlock");
jQuery("#mainContentLeft").addClass("displayNone");
}
jQuery("#fullscreen_google").toggleClass("fullscreen_google");
if (jQuery("#fullscreen_google").is(".fullscreen_google")) {
jQuery("#scrollConteneur").width(ScrollImageContener.getScrollContainerParentWidth(".fullscreen_google"));
} else {
jQuery("#scrollConteneur").width(ScrollImageContener.getScrollContainerParentWidth("#fullscreen_google"));
}
},
fullscreen : function(){
if(jQuery("#fullscreen").is(".fullscreen")){
ScrollImageContener.zoomOut();
jQuery("#mainContentLeft").removeClass("displayNone");
jQuery("#mainContentLeft").addClass("displayBlock");
jQuery("#scrollConteneur").width(ScrollImageContener.sizeNorm);
} else {
ScrollImageContener.zoomIn();
jQuery("#mainContentLeft").removeClass("displayBlock");
jQuery("#mainContentLeft").addClass("displayNone");
}
jQuery("#fullscreen").toggleClass("fullscreen");
if (jQuery("#fullscreen").is(".fullscreen")) {
jQuery("#scrollConteneur").width(ScrollImageContener.getScrollContainerParentWidth(".fullscreen"));
} else {
jQuery("#scrollConteneur").width(ScrollImageContener.getScrollContainerParentWidth("#fullscreen"));
}
},
getScrollContainerParentWidth : function(containerParent) {
return jQuery(containerParent).width();
},
copypaste : function(urn){
ArticleService.getCopyPasteTerms(urn,this.pageSequence[this.currentPage].pageId,
function(terms){
var contents ="";
if(terms!=null && terms.length>0){
for(var i=0;i<terms.length;i++){
contents+="<p>"+terms[i]+"</p>";
}
} else {
contents = Liferay.Language.get("jsp.portlet.no-copy-paste");
}
 		this.popup = Liferay.Popup({
width: 600,
noCenter: true,
modal: false,
title: Liferay.Language.get("jsp.portlet.title.copy-paste"),
message:contents
});
});
}
};
var PaginationContener = {
listElId   : new ArrayList(),
update : function(){
for (i=0; i<PaginationContener.listElId.size(); i++) {
              elTmpId = PaginationContener.listElId.get(i);
              if (jQuery('#'+elTmpId).attr("class") == "zoneCitation displayBlock") {                    
                  jQuery('#'+elTmpId).removeClass("zoneCitation displayBlock");
                  jQuery('#'+elTmpId).addClass("zoneCitation displayNone");
              }
}
if(ScrollImageContener.currentPage>0){
if(
jQuery('#'+ScrollImageContener.pageSequence[ScrollImageContener.currentPage].pageId).attr("class") == "zoneCitation displayNone") {
jQuery('#'+ScrollImageContener.pageSequence[ScrollImageContener.currentPage].pageId).removeClass("zoneCitation displayNone");
    jQuery('#'+ScrollImageContener.pageSequence[ScrollImageContener.currentPage].pageId).addClass("zoneCitation displayBlock");
    
    
    PaginationContener.listElId.add(ScrollImageContener.pageSequence[ScrollImageContener.currentPage].pageId); 
}
}
if(ScrollImageContener.currentPage>0){
 	jQuery('#paginationArrowLeft').show();
 	jQuery('#paginationPageLeft').html(ScrollImageContener.pageSequence[ScrollImageContener.currentPage-1].pageNumber);
} else {
jQuery('#paginationArrowLeft').hide();
jQuery('#paginationPageLeft').html("&nbsp;&nbsp;");
}
if(ScrollImageContener.currentPage+1<(ScrollImageContener.pageSequence.length-1)){
jQuery('#paginationArrowRight').show();
jQuery('#paginationPageRight').html(ScrollImageContener.pageSequence[ScrollImageContener.currentPage+1].pageNumber);
} else {
jQuery('#paginationArrowRight').hide();
jQuery('#paginationPageRight').html("&nbsp;&nbsp;");
}
jQuery('#paginationCurrentPage').attr({value:ScrollImageContener.pageSequence[ScrollImageContener.currentPage].pageNumber});
}
};
