
									if ((navigator.userAgent.match(/iPhone/i)) || (navigator.userAgent.match(/iPod/i))) {
										jQuery("head").append('<meta name="apple-itunes-app" content="app-id=509469951">" />')
									} 
								
									if (navigator.userAgent.match(/iPad/i)) {
										jQuery("head").append('<meta name="apple-itunes-app" content="app-id=509469951">" />')
									}
								