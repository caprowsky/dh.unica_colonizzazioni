(function($) {
    "use strict";
    $(function() {
        if(typeof jstor == "undefined") {
            return false;
        }
        if(window.location.hostname === 'www.jstor.org'){
            if(typeof Cookies.s_tagEnv == "undefined" || Cookies.s_tagEnv != "live") {
            	Cookies.create('s_tagEnv','live',1);
            }
        }
        else if(typeof Cookies.s_tagEnv == "undefined" || Cookies.s_tagEnv != "dev"){
        	Cookies.create('s_tagEnv','dev',1);
        }
        var defaultProperties = {server : window.location.hostname},
            dataMap = {
                eventsMap : {
                    'PageView'                      : 'event1',
                    'RegistrationBegin'             : 'event2',
                    'RegistrationComplete'          : 'event3',
                    'InternalSearch'                : 'event4',
                    'SearchByItemType'              : 'event5',
                    'SearchByDateRange'             : 'event6',
                    'SearchByLanguage'              : 'event7',
                    'SearchByPubTitle'              : 'event8',
                    'SearchByISBN'                  : 'event9',
                    'SearchByDiscipline'            : 'event10',
                    'ZeroSearchResults'             : 'event11',
                    'Browse'                        : 'event12',
                    'ContentView'                   : 'event13',
                    'CitationSaved'                 : 'event14',
                    'CitationViewed'                : 'event15',
                    'CitationTracked'               : 'event16',
                    'eTOCSignup'                    : 'event17',
                    'LogIn'                         : 'event18',
                    'LogOut'                        : 'event19',
                    'CommunicationsSignup'          : 'event20',
                    'BetaSearch'                    : 'event21',
                    'DownloadPDF'                   : 'event22',
                    'SavedSearch'                   : 'event23',
                    'RecentSearch'                  : 'event24',
                    'InfoIconClicked'               : 'event25',
                    'RightRailAdClicked'            : 'event26',
                    'InstitutionLogin'				: 'event28',
                    'AddToShelf'					: 'event29'
                },
                eVarsMap:  {
                    'AuthenticationStatus'          : 'eVar1',
                    'AuthorizationStatus'           : 'eVar2',
                    'AutheNAuthZ'                   : 'eVar3',
                    'PageName'                      : 'eVar4',
                    'PreviousPageName'              : 'eVar5',
                    'Subject'                       : 'eVar6',
                    'Discipline'                    : 'eVar7',
                    'JournalName'                   : 'eVar8',
                    'ArticleTitle'                  : 'eVar9',
                    'Publisher'                     : 'eVar10',
                    'Issue'                         : 'eVar11',
                    'InternalSearchKeywords'        : 'eVar12',
                    'InternalSearchFromHomepage'    : 'eVar13',
                    'InternalSearchResultsOrder'    : 'eVar14',
                    'InternalSearchScope'           : 'eVar15',
                    'BrowseMethod'                  : 'eVar16',
                    'ContentType'                   : 'eVar17',
                    'Title'                         : 'eVar18',
                    'Author'                        : 'eVar19',
                    'PubDate'                       : 'eVar20',
                    'Volume:Issue'                  : 'eVar21',
                    'DOI'                           : 'eVar22',
                    'ISBN'                          : 'eVar23',
                    'ISSN'                          : 'eVar24',
                    'ArticleAvailability'           : 'eVar25',
                    'Volume'                        : 'eVar26',
                    'InstitutionalOrIndividualUser' : 'eVar27',
                    'TypeOfInstitution'             : 'eVar28',
                    'NameOfInstitution'             : 'eVar29',
                    'ContentFormat'                 : 'eVar30',
                    'SearchResultPageNumber'        : 'eVar31',
                    'DocumentRankInPage'            : 'eVar32',
                    'LinkLocation'                  : 'eVar33',
                    'MyJstorStatus'                 : 'eVar34',
                    'InfoIconLocation'              : 'eVar35',
                    'ErrorType'	                    : 'eVar36',
                    'ExternalLoginEntry'			: 'eVar37',
                    'AdvancedSearchButtonLocation'	: 'eVar38',
                    'BookTitle'						: 'eVar39',
                    'BookSeries'					: 'eVar40',
                    'LoginPageActivity'				: 'eVar41',
                    'ChapterTitle'					: 'eVar42',
                    'MyJstorLoginResult'			: 'eVar43',
                    'Pamphlet'						: 'eVar44'
                },
                propsMap: {
                    'Discipline'                    : 'prop1',
                    'Journal'                       : 'prop2',
                    'ArticleTitle'                  : 'prop3',
                    'Publisher'                     : 'prop4',
                    'Issue'                         : 'prop5',
                    'ContentType'                   : 'prop6',
                    'PageNameFromCustomLink'        : 'prop19',
                    'EventName'						: 'prop21',
                    'OmnitureVersion'               : 'prop50'
                }
            },
            jstorSiteCatalyst = new JstorSiteCatalystHelper(defaultProperties,dataMap),
            windowURL = document.URL,
            scData = $('#SCData').length ? $('#SCData').data() : ""; //Represents the data attributes assigned on the SCData div hidden in pages
        
        if(scData !== "" && scData.hasOwnProperty("pagename")) {
            switch(scData.pagename) {
                case "front door":
                    jstorSiteCatalyst.buildRequestForSC({
                        props: {
                            pageName : "Front Door Article View",
                            channel : "Front Door"
                        },
						eVars: {
							"AuthenticationStatus" : scData.authenticate,
							"AuthorizationStatus" : scData.authorize
						}
                    });
                    
                    /*User clicked Add To Shelf Button*/
                   if($('a[href^="/action/showShelf?candidate"]').length) {
	                   	jstorSiteCatalyst.link($('a[href^="/action/showShelf?candidate"]'),"click", {
	                   		events: "AddToShelf",
	                   		props: {
	                   			EventName: "Add to Shelf",
	                   			PageNameFromCustomLink: s.pageName
	                   		}, 
	                   		title: "Add to Shelf",
	                   		linkType: "o"
	                   	}, false);
                   	}
                    break;
                    
                default:
                    break;
            }
        }
        
        //PROP ADDED TO EVERY REQUEST
        if(scData !== "") {
            jstorSiteCatalyst.buildRequestForSC({
                props: {
                    OmnitureVersion: "H.25.4T"
                }
            });
        }

        s.t();
    });
})(jQuery);
