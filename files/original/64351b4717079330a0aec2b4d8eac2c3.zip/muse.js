

/* sliding the sidebars boxes */
jQuery('.box-nav').live('click',function () {
	jQuery(this).toggleClass("open");
	jQuery('#'+this.id+'-box').slideToggle();
 
	return false; 
 });


jQuery('.plus-minus').live('click',function () {
	jQuery(this).toggleClass("open");
	jQuery('#'+this.id+'-extra').slideToggle();

	var ttt ;
	if (jQuery(this).hasClass('open')) {
        this.src = '/template2011/images/plus.gif';
	} else {
        this.src = '/template2011/images/minus.gif';
	}

	return false; 
 
});



jQuery('.expand').live('click', function () {
	jQuery(this).toggleClass("closed");
//	jQuery('#'+this.id+'-more').slideToggle();
	jQuery('#'+this.id+'-more').show();

	return false; 
});

