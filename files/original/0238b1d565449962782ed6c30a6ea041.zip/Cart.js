﻿dojo.provide("dojo.enabu");
dojo.provide("dojo.enabu.shop");
    
dojo.declare("dojo.enabu.shop.Cart", null, {
    _redirectUrl : '',
    
    constructor: function(){
    },    		
		
    setRedirectUrl : function(redirectUrl) {
    	this._redirectUrl = redirectUrl;
    },
    
    updateProductQty : function(idProduct) {
    	var textElement = dojo.byId('qtyText_' + idProduct);
    	if(textElement != null) {
            // Si prepara l'oggetto contenente i dati da inviare al controller
            var paramsObject = new Object();
            paramsObject['idProduct'] = idProduct;
            paramsObject['qty'] = textElement.value;
            paramsObject['redirectUrl'] = this._redirectUrl;
            var jsonString = dojo.toJson(paramsObject);
            var params = '?params=' + encodeURIComponent(jsonString);

            // Si esegue la chiamata passando come parametri i 2 metodi di gestione delle risposte
            var url = dojo.enabu.main.baseUrl + 'shop/cart/update';
            window.location = url + params;
    	}
    },

    removeProduct : function(idProduct) {
        // Si prepara l'oggetto contenente i dati da inviare al controller
        var paramsObject = new Object();
        paramsObject['idProduct'] = idProduct;
        paramsObject['redirectUrl'] = this._redirectUrl;
        var jsonString = dojo.toJson(paramsObject);
        var params = '?params=' + encodeURIComponent(jsonString);

        // Si esegue la chiamata passando come parametri i 2 metodi di gestione delle risposte
        var url = dojo.enabu.main.baseUrl + 'shop/cart/remove';
        window.location = url + params;
    },

    addProduct : function(idProduct) {
    	// Si prepara l'oggetto contenente i dati da inviare al controller
    	var paramsObject = new Object();
    	paramsObject['idProduct'] = idProduct;
    	paramsObject['redirectUrl'] = this._redirectUrl;
    	var jsonString = dojo.toJson(paramsObject);
    	var params = '?params=' + encodeURIComponent(jsonString);
    	
    	// Si esegue la chiamata passando come parametri i 2 metodi di gestione delle risposte
    	var url = dojo.enabu.main.baseUrl + 'shop/cart/add';
    	window.location = url + params;
    },
    
    emptyCart : function() {
    	alert('Svuoto il carrello');
    },
    
    submitOrder: function() {
    	window.location = dojo.enabu.main.baseUrl + 'shop/cart/sendorder';
    }, 
    
    goToPayChoice: function() {
    	window.location = dojo.enabu.main.baseUrl + 'shop/cart/paychoice';
    },
    
    goToCustomerInfo: function() {
    	window.location = dojo.enabu.main.baseUrl + 'shop/cart/customerinfo';
    }
});
