jQuery(function($){
    function biblioClose(not) {
        if (not)
            $('.formated_bibl_container').not(not).removeClass('on');
        else
            $('.formated_bibl_container').removeClass('on');
        $(document).unbind('.biblio');
    }
    $(".open_bibl").bind('click', function() {
        var $ref = $(this).parents('.formated_bibl_container');
        if ($ref.hasClass('on')) {
            biblioClose(false);
        } else {
            biblioClose($ref.attr('id'));
            $ref.addClass('on');
            $(document).bind('mousedown.biblio', function(e){
// 				console.log(e.target);
                var parents = $(e.target).parents('.formated_bibl_container');
                if (parents.length == 0)
                    biblioClose(false);
            });
            $(document).bind('keypress.biblio', function(e){
// 				console.log(e);
                if (e.keyCode == 27)
                    biblioClose(false);
            });
        }
    });
    $('.close_bibl').bind('click', function(){
        biblioClose(false);
    });
    $('.format.other').bind('click', function(){
        var $celuila = $(this);
        var parents = $celuila.parents('.formated_bibl_container');
        $('.formated_ref', parents).removeClass('on');
        $('.format.other', parents).removeClass('on');
        $('#'+$celuila.attr("id")+'_container').addClass('on');
        $celuila.addClass('on');
    });
});
