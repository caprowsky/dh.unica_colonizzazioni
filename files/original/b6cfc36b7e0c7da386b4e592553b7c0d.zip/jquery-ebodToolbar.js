(function($) {
	var iframeAttrs = ' frameborder="0" scrolling="no" marginwidth="0" marginheight="0" hspace="0" vspace="0" bordercolor="#000000" align="top" scrolling="No" ';
	var settings = undefined;
	var isEnabled = function() {
		/* return window.location.href.indexOf("demoebook") != -1; */
		return true;
	};
	var toolbarHeight = 64;
	var fixPosition = function() {
		var iPadPosition = window.innerHeight + window.pageYOffset - toolbarHeight;
		$("#ebodFullWpr").css("top", iPadPosition);
	};
	var methods = {
		lite : function(options) {
			if (isEnabled() && $("#ebodLiteIfr").length == 0) {
				var breadcrumbsEl = $(".breadcrumbs");
				if (breadcrumbsEl.length > 0 && $("#ebodLiteIfr").length == 0) {
					breadcrumbsEl.css("position", "relative");
					var wrapperStyles = "width=96px;height=42px;position:absolute;bottom:1px;right:1px;display:block;";
					var toolbarIframe = '<iframe id="ebodLiteIfr" src="/ebod/resources/toolbar-lite.html" width="96" height="42" ' + iframeAttrs + '></iframe>';
					breadcrumbsEl.html('<div class="breadcrumbspath">' + breadcrumbsEl.html() + '</div><div style="' + wrapperStyles + '">' + toolbarIframe + '</div>');
				}
			}
		},
		full : function() {
			if (isEnabled() && $("#ebodFullIfr").length == 0) {
				var title, subtitle;
				if (!settings || !settings.title) {
					title = encodeURIComponent($.trim($(".lemma .intro h1").text()));
					if (!title || title.length == 0) {
						title = encodeURIComponent($.trim($("html head title").text()));
					}
				} else {
					title = encodeURIComponent(settings.title);
				}
				if (!settings || !settings.subtitle) {
					subtitle = encodeURIComponent($.trim($(".lemma .intro span.oo").text()));
				} else {
					subtitle = encodeURIComponent(settings.subtitle);
				}
				var url = encodeURIComponent(location.href);
				$(".footer").css("height", ($(".footer").height() + toolbarHeight) + "px");
				var wrapperStyles = "width:100%;height:" + toolbarHeight + "px;position:fixed;bottom:0;left:0;display:block;z-index:100;";
				$("body").append(
						'<div id="ebodFullWpr" style="' + wrapperStyles + '"><iframe id="ebodFullIfr" src="/ebod/resources/toolbar-full.html?t=' + title + '&s=' + subtitle + '&u=' + url
								+ '" width="100%" height="' + toolbarHeight + '" ' + iframeAttrs + '></iframe></div>');
				if (/Android|iPhone OS 4/i.test(navigator.userAgent)) {
					$("#ebodFullWpr").css("position", "absolute").css("bottom", "");
					fixPosition();
					window.onscroll = fixPosition;
				}
			}
		}
	};
	$.ebodToolbar = function(method, options) {
		if (!method) {
			method = "lite";
		}
		settings = $.extend({
			"title" : undefined,
			"subtitle" : undefined
		}, options);
		if (methods[method]) {
			return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
		} else if (typeof method === "object" || !method) {
			return methods.init.apply(this, arguments);
		} else {
			$.error('Method ' + method + ' does not exist on jQuery.ebodToolbar');
		}
	};
})(jQuery);