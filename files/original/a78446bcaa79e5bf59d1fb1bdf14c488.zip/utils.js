/*
 * C. Allen - MediaAndMe javascript library
 * http://www.mediaandme.be/
 */

if(!console){var console={log:function(val){}}};
var CEDjs = {};

function $i(val){return document.getElementById(val);};

function $t(elemType,o){if(!o)o=document;return o.getElementsByTagName(elemType);};

function $c(elemType,cssClass,o){
	if(!o)o=document;
	var listLcl = $t(elemType,o);
	var list2return = new Array();
	for(var i=0;i<listLcl.length;i++){
		if(listLcl[i].className.indexOf(cssClass+" ")>-1 || listLcl[i].className.indexOf(" "+cssClass)>-1 || listLcl[i].className == cssClass)
			list2return.push(listLcl[i]);
	};
	return list2return;
};
function $t1L(elemType,o){
	var lstLcl = [];
	for(var i=0;i<o.childNodes.length;i++){
		if(o.childNodes[i].tagName && o.childNodes[i].tagName.toLowerCase()==elemType){lstLcl.push(o.childNodes[i]);};
	};
	return lstLcl;
};

function $dc(e){return document.createElement(e);};

/*-- unobstructive additionnal events --*/
CEDjs.addEvent=function(o,type,fct){
	var old = o[type];
	if(typeof o[type]!='function'){
		o[type] = fct;
	}
	else{
		o[type] = function(){
			old();
			fct();
		};
	};
};

CEDjs.addOnloadEvent=function(fct){if(CEDjs.loaded){fct();}else{CEDjs.addEvent(window,"onload",fct);}};
CEDjs.addOnloadEvent(function(){CEDjs.loaded=true;});
CEDjs.addOnresizeEvent=function(fct){CEDjs.addEvent(window,"onresize",fct);};
CEDjs.addOnscrollEvent=function(fct){CEDjs.addEvent(window,"onscroll",fct);};
CEDjs.addOnMouseMoveEvent=function(fct){CEDjs.addEvent(document,"onmousemove",fct);};

/*------------------------------------*/

CEDjs.IE = navigator.appVersion.split('MSIE ')[1]!=null;
CEDjs.IE6 = navigator.appVersion.split('MSIE ')[1] && parseInt(navigator.appVersion.split('MSIE ')[1].substr(0,1))<7;
CEDjs.getBody = function(){
	if(!CEDjs.body)CEDjs.body=$t1L("body",document.documentElement)[0];
	return CEDjs.body;
};

CEDjs.IE6pngFix = function(o,forceIE,scale){
	if(CEDjs.IE6 || (CEDjs.IE && forceIE)){
		o=o?o:document;
		var imgs = $t("img",o);
		var s = CEDjs.IE6pngFix.arguments[2];s=s?s:0;
		for(var i=0;i<imgs.length;i++){
			if(imgs[i].src.indexOf(".png")>-1 &&  imgs[i].className.indexOf("noIEfix")==-1){
				var d = $dc("DIV");
				d.style.filter = "progid:DXImageTransform.Microsoft.AlphaImageLoader(enabled=true,sizingMethod="+(scale?"scale":"crop")+",src="+imgs[i].src+")";
				var w=imgs[i].offsetWidth;
				var h=imgs[i].offsetHeight;
				if(w>0)w+="px";else w=imgs[i].style.width;
				if(h>0)h+="px";else h=imgs[i].style.height;
				d.style.width = w;
				d.style.height = h;
				d.className=imgs[i].className;
				iPar = imgs[i].parentNode;
				iPar.insertBefore(d,imgs[i]);
				iPar.removeChild(imgs[i]);
				var o1=o,fIE=forceIE,i1=i;
				setTimeout(function(){CEDjs.IE6pngFix(o1,fIE,i1);},7);
				break;
			};
		};
	};
};


/*------------------------------------*/

CEDjs.wrSWFindex=0;
CEDjs.wrSWF = function(o){
	/* o.trg : DOM target
	 * o.w
	 * o.h
	 * o.src
	 * o.wmode : boolean
	 */
	var WR="";
	if(CEDjs.IE){
		WR+='<object id="swf_'+CEDjs.wrSWFindex+'" width="'+o.w+'" height="'+o.h+'" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0">';
		WR+='<param name="movie" value="'+o.src+'"></param>';
		WR+='<param name="allowFullScreen" value="true"></param>';
		WR+='<param name="allowScriptAccess" value="always"></param>';
		if(o.wmode)WR+='<param name="wmode" value="transparent"></param>';
		WR+='</object>';
	}else{
		WR+='<object id="swf_'+CEDjs.wrSWFindex+'" type="application/x-shockwave-flash" width="'+o.w+'" height="'+o.h+'" data="'+o.src+'">';
		WR+='<param name="allowFullScreen" value="true"></param>';
		WR+='<param name="allowScriptAccess" value="always"></param>';
		if(o.wmode)WR+='<param name="wmode" value="transparent"></param>';
		WR+='</object>';
	};
	if(o.trg){
		o.trg.innerHTML = WR;
		return 'swf_'+CEDjs.wrSWFindex;
	}else{
		document.write(WR);
	}
};
