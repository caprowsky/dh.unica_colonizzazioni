if(!rootPath)rootPath="";

var cairn={};

cairn.expandMonCairn = function(o){
	if(!o.trg){
		o.trg=$t("div", o.parentNode)[1];
		$t("div",o.trg)[0].onclick=function(){
			this.parentNode.style.display="none";
		};
		o.trg.bg = $dc("DIV");
		o.trg.bg.className="bg";
		o.trg.appendChild(o.trg.bg);
		o.trg.bot = $c("div","bottom",o.trg)[0];
	};
	o.trg.style.display="block";
	o.trg.bg.style.height=(o.trg.bot.offsetTop-25)+"px";
};

cairn.focusInput=function(o){
	if(!o.isInit){
		o.isInit=true;
		o.value="";
	};
};


cairn.toolboxPos = function(){
	if(CEDjs.IE6){
		var top = ($i("toolbox").top+document.documentElement.scrollTop);
		if (document.documentElement.scrollHeight - document.documentElement.scrollTop < 860) {
			$i("toolbox").style.top = ($i("footer").offsetTop - ($i("toolbox").offsetHeight+10))+"px";
		}else{
			$i("toolbox").style.top = top + "px";
		}
	}else{
		var scrollDoc = (document.documentElement.scrollTop==0)?CEDjs.getBody():document.documentElement;
		if(scrollDoc.scrollHeight-scrollDoc.scrollTop<860){
			$i("toolbox").style.position="absolute";
			$i("toolbox").style.top=($i("footer").offsetTop - ($i("toolbox").offsetHeight+10))+"px";
		}else if(scrollDoc.scrollTop<40){
			$i("toolbox").style.position="absolute";
			$i("toolbox").style.top="320px";
		}else{
			$i("toolbox").style.position="fixed";
			$i("toolbox").style.top=$i("toolbox").top+"px";					
		};
	};
};

cairn.initToolbox=function(){
	if($i("toolbox")){
		var top = $dc("IMG"),bot = $dc("IMG");
		top.className="top";
		bot.className="bot";
		top.src=rootPath+"img/tools_top.png";
		bot.src=rootPath+"img/tools_bot.png";
		$i("toolbox").appendChild(top);
		$i("toolbox").appendChild(bot);

		$i("toolbox").top = $i("toolbox").offsetTop; 
		/* CEDjs.addOnscrollEvent(cairn.toolboxPos); */
		
		CEDjs.IE6pngFix($i("toolbox"));
		
		/* cairn.toolboxPos(); */
	};
};

cairn.zoomValue = 100;
cairn.zoomContent=function(o){
	cairn.zoomValue+=(o.className=="Aplus"?20:-20);
	while(o && o.className!="content")o=o.parentNode;
	if(o){
		if(cairn.zoomValue>=200)cairn.zoomValue=200;
		if(cairn.zoomValue<=100)cairn.zoomValue=100;
		o.style.fontSize = cairn.zoomValue + "%";
	}else{
		cairn.zoomValue=100;
	};
};

cairn.initBigLetter=function(){
	var bL = $c("p","bigLetter",$i("cnt_1"));
	for(var i=0;i<bL.length;i++){
		var txt = bL[i].innerHTML;
		var s=0;
		while(txt.charAt(s)=="\r" || txt.charAt(s)=="\t" || txt.charAt(s)=="\n" || txt.charAt(s)==" ")s++;
		bL[i].innerHTML="<span class='firstChar'>"+txt.charAt(s)+"</span>"+txt.substr(s+1,txt.length);
	};
};

cairn.initExpandContent=function(){
	var eC = $c("div","expandableContent");
	for(var i=0;i<eC.length;i++){
		$t1L("span",eC[i])[0].onclick=function(){
			if(this.parentNode.className.indexOf("opened")>-1){
				this.parentNode.className = this.parentNode.className.replace(/opened/g,"");
			}else{
				this.parentNode.className += " opened";
			};
		};
	};
};

cairn.initSearchBox=function(){
	var sBx = $c("div","searchBox",$i("areaLeft1"));
	for(var i=0;i<sBx.length;i++){
		sBx[i].exp = $t1L("div",sBx[i])[0];
		sBx[i].onclick=function(){
			if(this.isExp){
				this.exp.style.display="none";
				this.isExp=false;
			}else{
				this.exp.style.display="block";	
				this.isExp=true;
			};			
			if(!this.isInit){
				this.tp=$dc("div"),this.md=$dc("div"),this.bt=$dc("div");
				this.tp.innerHTML = '<img src="'+rootPath+'img/boxLeft_2_searchExp1.png" width="155" height="25"/>';
				this.bt.innerHTML = '<img src="'+rootPath+'img/boxLeft_2_searchExp3.png" width="155" height="25"/>';
				this.md.innerHTML = '<img src="'+rootPath+'img/boxLeft_2_searchExp2.png" width="155" height="'+(this.exp.offsetHeight-10)+'"/>';
				this.tp.className="searchBox-exp-tp";
				this.md.className="searchBox-exp-md";
				this.bt.className="searchBox-exp-bt";
				this.appendChild(this.tp);
				this.appendChild(this.md);
				this.appendChild(this.bt);
				this.bt.style.top = this.md.offsetTop+(this.exp.offsetHeight-10)+"px";
				this.isInit=true;
				CEDjs.IE6pngFix(this.tp);
				CEDjs.IE6pngFix(this.md,false,true);
				CEDjs.IE6pngFix(this.bt);
			};
			if(!this.isExp){
				this.tp.style.display="none";
				this.md.style.display="none";
				this.bt.style.display="none";
			}else{
				this.tp.style.display="block";
				this.md.style.display="block";
				this.bt.style.display="block";
			};			
		};
	};
};

cairn.legend = function(o,txt){
	if(!o.legend){
		o.legend=$dc("div");
		o.style.position="relative";
		o.legend.style.position="absolute";
		o.legend.style.top="3px";
		o.legend.style.left="65px";
		o.legend.innerHTML='<div style="position:absolute;top:0px;left:-22px;"><img src="'+rootPath+'img/tools_exp_1.png" style="width:22px;height:26px;"/></div>';
		o.legend.innerHTML+='<div style="line-height:24px;height:30px;background:url('+rootPath+'img/tools_exp_2.png) no-repeat 0 0;color:#FFFFFF;white-space:nowrap;">'+txt+'</div>';
		o.legend.innerHTML+='<div style="position:absolute;top:0px;right:-9px;"><img src="'+rootPath+'img/tools_exp_3.png" style="width:9px;height:26px;"/></div>';
		o.appendChild(o.legend);
		o.onmouseout=function(){
			this.legend.style.display="none";
		}
		CEDjs.IE6pngFix(o.legend);
	}
	o.legend.style.display="block";
};

cairn.expCombo=function(o){
	if (!o.exp) {
		o.exp = $t1L("span", o)[0];
		o.onmouseout = function(){
			this.exp.style.display = "none";
		};
	};
	o.exp.style.display="block";
};

cairn.legendAlt = function(o,txt){
	if(!o.legend){
		o.legend=$dc("div");
		o.style.position="relative";
		o.legend.style.position="absolute";
		o.legend.style.top="20px";
		o.legend.style.left="-130px";
		o.legend.innerHTML='<div style="position:absolute;top:0px;left:-9px;"><img src="'+rootPath+'img/tools_exp_alt_1.png" style="width:9px;height:26px;"/></div>';
		o.legend.innerHTML+='<div style="line-height:24px;height:30px;background:url('+rootPath+'img/tools_exp_2.png) no-repeat 0 0;color:#FFFFFF;white-space:nowrap;">&#160;&#160;'+txt+'&#160;&#160;&#160;&#160;</div>';
		o.legend.innerHTML+='<div style="position:absolute;top:0px;right:-9px;"><img src="'+rootPath+'img/tools_exp_3.png" style="width:9px;height:26px;"/></div>';
		o.appendChild(o.legend);
		o.onmouseout=function(){
			this.legend.style.display="none";
		}
		CEDjs.IE6pngFix(o.legend);
	}
	o.legend.style.display="block";
};



cairn.lBox={};
cairn.lBox.close = function(){
	cairn.lBox.BG.style.display="none";
	cairn.lBox.CNT.style.display="none";
};
cairn.lightBox=function(o,top,left){
	if(!cairn.lBox.BR){
		cairn.lBox.BR = $dc("div");
		cairn.lBox.BG = $dc("div");
		cairn.lBox.CNT = $dc("div");
		cairn.lBox.BR.className = "LbBR";
		cairn.lBox.BG.className = "LbBG";
		cairn.lBox.CNT.className = "LbCNT";
		CEDjs.getBody().appendChild(cairn.lBox.BR);
		CEDjs.getBody().appendChild(cairn.lBox.BG);
		CEDjs.getBody().appendChild(cairn.lBox.CNT);
	}
	
	cairn.lBox.BG.style.width=(cairn.lBox.BR.offsetLeft+cairn.lBox.BR.offsetWidth)+"px";
	cairn.lBox.BG.style.height=$i("mainContent").offsetHeight+"px";
	cairn.lBox.BG.style.display="block";
	cairn.lBox.BG.onclick=cairn.lBox.close;
	
	cairn.lBox.CNT.style.display="block";
	cairn.lBox.CNT.style.top=top+"px";
	cairn.lBox.CNT.style.left=left+"px";
	
	var iHTML = '';
		iHTML+= '<div class="bg">';
		iHTML+= '	<div class="cnt">';
		iHTML+= $c("span","lightboxContent",o)[0].innerHTML;
		iHTML+= '	</div>';
		iHTML+= '</div>';
		iHTML+= '<div class="c1"><img src="'+rootPath+'img/lbox1.png"/></div>';
		iHTML+= '<div class="c2"'+(CEDjs.IE6?' style="bottom:-3px;"':'')+'><img src="'+rootPath+'img/lbox2.png"/></div>';
		iHTML+= '<div class="c3"'+(CEDjs.IE6?' style="bottom:-3px;"':'')+'><img src="'+rootPath+'img/lbox3.png"/></div>';
		iHTML+= '<div class="c4" onclick="cairn.lBox.close();"><img src="'+rootPath+'img/lbox4.png"/></div>';
	
	cairn.lBox.CNT.innerHTML = iHTML;
	CEDjs.IE6pngFix(cairn.lBox.CNT);
};

cairn.initReferences=function(){
	var cnt = $i("cnt_1");
	var refs = $c("span","reference",$i("cnt_1"));
	var lastTop = 0;

var toptop = 800;
var p = 0;

	for(var i=0;i<refs.length;i++){
		var absTop = 0; 
		var o = refs[i];
		while(o!=cnt){
			absTop+=o.offsetTop;
			o=o.parentNode;
		};

		if(absTop<lastTop){
			refs[i].style.top=(refs[i].offsetTop+10+(lastTop-absTop))+"px";
			lastTop+=refs[i].offsetHeight+10;
p=lastTop;
		}else{
			lastTop=absTop + refs[i].offsetHeight;
		};
		
	};


};
cairn.initReferences1=function(){
	var cnt = $i("cnt_1");
	var refs = $c("span","reference1",$i("cnt_1"));
	var lastTop = 0;

var toptop = 800;
var p = 0;
for(var i=0;i<refs.length;i++){
		var absTop = 0; 
		var o = refs[i];
	refs[i].style.width="135px";
	refs[i].style.fontSize="12px";
		};
   

	for(var i=0;i<refs.length;i++){
		var absTop = 0; 
		var o = refs[i];
	refs[i].style.width="135px";
	refs[i].style.fontSize="12px";
		while(o!=cnt){
			absTop+=o.offsetTop;
			o=o.parentNode;
		};

		if(absTop<lastTop && (lastTop-absTop)<15000){
			refs[i].style.top=(refs[i].offsetTop+10+(lastTop-absTop))+"px";


			lastTop+=refs[i].offsetHeight+10;
p=lastTop;
		}else{
			lastTop=absTop + refs[i].offsetHeight;
		};
	refs[i].style.width="135px";
	refs[i].style.fontSize="12px";

	};

};




cairn.initRefauteur=function(){
	var cnt = $i("cnt_1");
	var refs = $c("span","refauteur",$i("cnt_1"));
	var lastTop = 0;

	for(var i=0;i<refs.length;i++){
		var absTop = 0; 
		var o = refs[i];
		while(o!=cnt){
			absTop+=o.offsetTop;
			o=o.parentNode;
		};
		if(absTop<lastTop){
			refs[i].style.top=(refs[i].offsetTop+10+(lastTop-absTop))+"px";
			toptop=(refs[i].offsetTop+10+(lastTop-absTop));
			lastTop+=refs[i].offsetHeight+10;
			
		}else{
			lastTop=absTop + refs[i].offsetHeight;
		};
		
	};


			
			



};




CEDjs.addOnloadEvent(function(){
	cairn.initToolbox();
	cairn.initBigLetter(); 
	cairn.initExpandContent();
	cairn.initSearchBox();
	cairn.initReferences();
	cairn.initReferences1();
	cairn.initRefauteur();


});




function fileAjax (fichier) {
	if(window.XMLHttpRequest) {
		xhr_object = new XMLHttpRequest();
	} else if(window.ActiveXObject) {
		xhr_object = new ActiveXObject("Microsoft.XMLHTTP");
	} else {
		return(false);
	}
	xhr_object.open("GET", fichier, false);
	xhr_object.send(null);

	if(xhr_object.readyState == 4) {
		return(xhr_object.responseText);
	} else {
		return(false);
	}
}

function UpdateDivAjax (url,id,id2) {

	document.getElementById(id).style.display="none";
	var texte = "";
	texte = fileAjax (url);
	document.getElementById(id).innerHTML = texte;
	document.getElementById(id).style.display="block";
	document.getElementById(id2).style.display="none";

}

