
	// Test if Query Parameter exists
	
	function isQPExist(parameterName) {
		if ( _tag.DCS.dcsqry ) {
			if ( _tag.DCS.dcsqry.indexOf(parameterName + "=") != -1) {
				return 1;
			}
		}
		return 0;
	}
	
	// Collect Search phrase in case of advanced search
	
	function getAdvancedSearchTerms(_tag) {
		var result = "";		
		
		// Get keywords
		myRegex  = /(etou[0-9]*=([^&]*)&)?larech[0-9]*=([^&]*)/g;
		groups = myRegex.exec(_tag.DCS.dcsqry);

		while( groups != null) {
			if ( groups[3] != "" ) {
				if ( groups[2] != undefined) {
 	result += " " + unescape(groups[2]) + " " + unescape(groups[3]);
				} else {
					 result = unescape(groups[3]);
				}
			}
			groups = myRegex.exec(_tag.DCS.dcsqry);
		}
		_tag.WT.oss = result;
		
		// Get Types 
		result = "";
		separator = "";
		myRegex  = /&(chk_[a-z|A-Z]*)=on/g;
		groups = myRegex.exec(_tag.DCS.dcsqry);
		
		while( groups != null) { 
			result += separator + docTypes[groups[1]];
			groups = myRegex.exec(_tag.DCS.dcsqry);
			separator = ";";
		}
		_tag.DCSext.oss_content = result;
		
		// Get Editor
		
		myRegex  = /editeur=([^&]*).*/g;
		groups = myRegex.exec(_tag.DCS.dcsqry);
		_tag.DCSext.oss_publisher = groups[1];
		
		// Get Revue and Collection
		myRegex  = /revmag=([^&]*)&recol=([^&]*)/g;
		groups = myRegex.exec(_tag.DCS.dcsqry);
		
		_tag.DCSext.oss_revue = groups[1];
		_tag.DCSext.oss_coll = groups[2];
		
		// Get years
		myRegex  = /&annee1=([^&]*)&annee2=([^&]*)/g;
		groups = myRegex.exec(_tag.DCS.dcsqry);
		
		_tag.DCSext.oss_yearFrom = groups[1];
		_tag.DCSext.oss_yearTo = groups[2];
	}
	
	// Get Discipline ifrom select Menu
	
	function populateDiscipline() {
		if ( _tag.DCS.dcsuri == "/Disc_OuvragesCollectifs.php" ) {
			var index = _tag.dcsQP("POS");
			if ( index != "" ) {
				var elt = document.getElementById("POS");
				if ( elt != null && elt.options[index] != null ) {
					_tag.DCSext.ct_disc1 = elt.options[index].text;
				}
			}
		}
	}
	

	
	
	

function init(_tag) {

	// Get Discipline if issued from select element in Disc_OuvragesCollectifs.php page
	
	populateDiscipline();
	
	// Acces by Author or Title or Pays
	
	var accValue = "";
	if ( (accValue = _tag.dcsQP("TITRE")) != "" ) {
		_tag.DCSext.ct_accby	=  "Par titre";
		_tag.DCSext.ct_accval	=  accValue;
	} else if ( (accValue = _tag.dcsQP("AUTEUR")) != "") { 
		_tag.DCSext.ct_accby	=  "Par auteur";
		_tag.DCSext.ct_accval	=  accValue;
	} else if ( (accValue = _tag.dcsQP("PAYS")) != "") { 
		_tag.DCSext.ct_accby	=  "Par pays";
		_tag.DCSext.ct_accval	=  accValue;
	} else if ( (accValue1 = _tag.DCSext.ct_disc1) != undefined ) {
		_tag.DCSext.ct_accby	=  "Par discipline";
		if ( (accValue2 = _tag.DCSext.ct_disc2) != undefined ) {
			_tag.DCSext.ct_accval	=  accValue2;	
		 } else {
			_tag.DCSext.ct_accval	=  accValue1;	
		 }
	}
		
		
	// Collect Institution Information
	
	_tag.DCSext.id_inst = _tag.dcsGetCookie("ID_INSTIT");
	

	// Collect Product Information
	
	// SKU details
	
	if ( _tag.WT.pn_id == "undefined" || _tag.WT.pn_id == "" ) {
		_tag.WT.pn_id = ( (val = getMetaTagContent("citation_title")) != null) ? val : "";
	}

	if ( _tag.WT.pn_gr == "undefined" || _tag.WT.pn_gr == "" ) {
		_tag.WT.pn_gr = ( (val = getMetaTagContent("citation_journal_title")) != null) ? val : "";
	}

	if ( _tag.WT.pn_ma == "undefined" || _tag.WT.pn_ma == "" ) {
		_tag.WT.pn_ma = ( (val = getMetaTagContent("citation_publisher")) != null) ? val : "";
	}

	if ( _tag.DCSext.authors == "undefined" || _tag.DCSext.authors == "" ) {
		_tag.DCSext.authors = ( (val = getMetaTagContent("citation_authors")) != null) ? val : "";
	}		
	

	// Onsite Search
	
	if ( _tag.DCS.dcsuri.indexOf("resultats_recherche.php" ) ) {  

		var phrase;
		if ( isQPExist("searchTerm") ) {

 _tag.WT.oss    = unescape(_tag.dcsQP("searchTerm"));


			_tag.DCSext.oss_type 	= "Simple";
		} else if ( isQPExist("larech1") ) {
			getAdvancedSearchTerms(_tag);
			_tag.DCSext.oss_type 	= "Avanc\351";
		}
		
		// Capture filter (facette) and position
		
		if ( isQPExist("filter") ) {
			var currFilter = _tag.dcsQP("filter");

			if ( document.referrer != "" && document.referrer.indexOf("resultats_recherche.php") ) {
				var oldFilter = _tag.dcsGetCookie("FILTER");
				
				if ( oldFilter != null ) {
					if ( oldFilter.indexOf(currFilter) == -1 ) {
						newFilter = oldFilter + ":" + currFilter;
					} else {
						newFilter = oldFilter;
					}	
				} else {
					newFilter = currFilter;
				}
			} else {
				newFilter = currFilter;
			}
			document.cookie 		= "FILTER=" + newFilter;
			_tag.DCSext.oss_filter	= newFilter;
			_tag.DCSext.MOV			= 0;
		} else {
			_tag.DCSext.MOV			= ((val = _tag.dcsQP("MOV")) == undefined )? 0 : val;
		}
		
		
		
	}
	
	
	// Collect campaign ID from query parameter cid
	var cmpid;
	if ( (cmpid = _tag.dcsQP("cid")) != "" ) {
		_tag.WT.mc_id = cmpid;
	}

}
	
docTypes = {"chk_revue" : "Revue", 
			"chk_ouvcol" : "Ouvrage Collectif", 
			"chk_edm" : "Etat du monde", 
			"chk_ouvref" : "Ouvrage de r\351f\351rence",
			"chk_mag" : "Magazine"
			};
	
	



		
	
	
