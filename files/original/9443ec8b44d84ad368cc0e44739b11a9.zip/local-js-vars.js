
/* 
################################################################## 
## 
##   THIS IS A GENERATED FILE. 
## 
##   ANY CHANGES YOU MAKE DIRECTLY TO THIS FILE WILL BE OVERWRITTEN 
##   AND LOST THE NEXT TIME THIS FILE IS GENERATED. 
## 
##  (This file last generated: Feb 13, 2013, 10:42 A.M.) 
## 
################################################################## 
 */

/* ##### BELOW added by: file:/highwire/webapps/ereh/resources/publisher/build/local-js-vars.base.xml ##### */



var gJournalVars = {};



var gJournalVars = {  
  jnlID: 'ereh',
   copy: "European Historical Economics Society",
   issn: '1361-4916',
  eissn: '1474-0044',
  oupcode: 'ereh',
  urlPrefix: 'ereh'
};
 





    var manuscript = false;



 



	var CollapsibleTocs = false;




/* ##### END OF ADDED BLOCK ##### */
