		var domain = "http://global.oup.com";
		var cookieWsUrl = domain+"/cookiealert";
		var cookiePolicyUrl = domain+"/cookiepolicy/";
		var version = "/0";
		var cookieDate = "/01-01-2000";
		var preferredLanguage = "";
		var cookieName = "oup-cookie";
		var databaseVersion = "0";
		var cookieOlderThanSpecificDays = true;

		var ie6Message = "<div id=\"oupcookiepolicy_message\" class=\"cookiepolicyimplied\"><div class=\"cookiepolicytext\">We use cookies to enhance your experience on our website. By clicking 'continue' or by continuing to use our website, you are agreeing to our use of cookies. You can change your cookie settings at any time.</div><ul class=\"cookiepolicylinks\"><li><a href=\"#\" onClick=\"window.location.reload( true );\" class=\"cookiepolicycontinue\" title=\"Close this message\">Continue</a></li><li><a href=\"http://global.oup.com/cookiepolicy/\" target=\"_blank\" class=\"cookiepolicymore\" title=\"How we use cookies on this site\">Find out more</a></li></ul><div class=\"cookiepolicyend\"></div></div>";

		try{
			var _cookiepolicy = jQuery;                     
		}catch(e){
		try{
			var _cookiepolicy = $;                         
		}catch(e){
			}
		}      
		//alert(' variable conflict. =====>  :'+_cookiepolicy +'    cookiePolicyUrl :'+cookiePolicyUrl+'   oupcookiepolicy_messagetype :'+oupcookiepolicy_messagetype);

		// uncomment the below line for testing with implied consent.

		//oupcookiepolicy_messagetype='explicit';

		_cookiepolicy(document).ready(function() {

		writeTheElements();
		getTheCookie();

		if(oupcookiepolicy_messagetype == 'explicit'){

			if (typeof _cookiepolicy.oupcookiepolicy_fancybox == 'function') {
				//alert('allready loaded');
				_cookiepolicy("a#cookiepolicy_link").oupcookiepolicy_fancybox({
					'hideOnContentClick': false,
					'hideOnOverlayClick':false
				});
				_cookiepolicy("a.group").oupcookiepolicy_fancybox({
					'transitionIn'	:	'elastic',
					'transitionOut'	:	'elastic',
					'speedIn'		:	600, 
					'speedOut'		:	200, 
					'overlayShow'	:	false
				});							
			}
			else
			{
				//alert('fancybox object not available.');
			}
		}

			try{
				if(cookieOlderThanSpecificDays){
					checkForAlertMessage();
				}else{
					
				}
			}catch(e){
				var keyword= '/cookiepolicy/';
				alertMessageToDisplay=htmlDecode(ie6Message);
				if(alertMessageToDisplay.indexOf(keyword) != -1){
						var alertMessageToDisplay1= alertMessageToDisplay.substring(0, alertMessageToDisplay.indexOf(keyword));
						var alertMessageToDisplay2= alertMessageToDisplay.substring(alertMessageToDisplay.indexOf(keyword)+keyword.length, alertMessageToDisplay.length);
						alertMessageToDisplay = alertMessageToDisplay1+keyword+"?siteid="+oupcookiepolicy_siteid+alertMessageToDisplay2;
					}
						var p = document.createElement("div");
						p.innerHTML = alertMessageToDisplay;
						document.body.insertBefore(p, document.body.firstChild);
						saveCookie(1);
			}
		});	
		
		function writeTheElements(){
			var element = document.createElement("div");
			element.innerHTML = "<div id=\"cookiepolicy_div\"><a id=\"cookiepolicy_link\" href=\"#cookiepolicy_data\"></a><div id=\"cookiepolicy_parent\"style=\"display:none\"><div id=\"cookiepolicy_data\"></div></div></div>";
			document.body.insertBefore(element, document.body.firstChild);
		}
		
		
		function getTheCookie(){
			var  browserLanguage = window.navigator.userLanguage;
			if(browserLanguage==undefined){
				browserLanguage = window.navigator.language;
			}		
			browserLanguage = browserLanguage.substring(0,2); 
			preferredLanguage = "/"+browserLanguage;
			
			var allcookies = document.cookie; 
//alert('The Cookies ' + allcookies);
			cookiearray  = allcookies.split(';');
		    for(var i=0; i<cookiearray.length; i++){				  
				var name = cookiearray[i].split('=')[0];
				var value = cookiearray[i].split('=')[1];
				if(name.indexOf(cookieName) != -1)
				{	
					if(value.split('_')[0] == ""){
						version = "/0";
					}else{
					version = "/"+ value.split('_')[0]; 
					}
					var deviceCookieDate = value.split('_')[1];
					var deviceCookieDateString = constructDateString(deviceCookieDate); 
					var deviceDate = new Date(deviceCookieDateString);
					var currentDate = new Date(); 
					var difference = currentDate - deviceDate; 
					if(difference > 90*24*60*60*1000){						
						cookieOlderThanSpecificDays = true;
					}else{										
						cookieOlderThanSpecificDays = false;
					}
					cookieDate = "/"+ value.split('_')[1];
				}
		   }
		}
		
		
		function constructDateString(date){
			try{
				var day = date.split('-')[0];
				var month = date.split('-')[1];
				var year = date.split('-')[2];
				return (year+","+month+","+day);
			}catch(e){
				
			}
		}
		
		
		function checkForAlertMessage(){
				//alert('checkForAlertMessage');
				var request1 = null;
				var wsresponse = false;
				request1 = createCORSRequest("GET",cookieWsUrl + preferredLanguage + version + cookieDate,true);
				
				if (typeof XDomainRequest != "undefined"){
					request1.onload=function()
					{
							wsresponse = request1.responseText;
							if(wsresponse == 'true'){
								getAlertMessage();						
							}else{
							}
					};
				}else{
					request1.onreadystatechange=function()
					{
						if (request1.readyState==4 && request1.status== 200 )
						{
							wsresponse = request1.responseText;
							if(wsresponse == 'true'){
								getAlertMessage();						
							}else{
							}
						}
					};
				}	
				request1.send();		
		}
		
		function getAlertMessage(){	
			var request2 = null;
			var response = "";
			var isMessagePrinted= false;
			request2 = createCORSRequest("GET",cookieWsUrl + preferredLanguage +"/"+ oupcookiepolicy_messagetype ,true);
			
			if (typeof XDomainRequest != "undefined"){
				request2.onload = function()
				{
					if (!isMessagePrinted)
					{
						isMessagePrinted = true;
						response = request2.responseText;
						generateAlertMessage(response);
					}
				};
				request2.send();
			}else{
				request2.onreadystatechange=function()
				{
					if (request2.readyState==4 && request2.status == 200 && !isMessagePrinted)
					{
						isMessagePrinted = true;
						response = request2.responseText;
						generateAlertMessage(response);
					}
				};
				request2.send();
			}
		}
		
		// The funciton to generate CROS request
		function createCORSRequest(method, url){
			//alert('Creating request for ' + url);
			var xhr = new XMLHttpRequest();
			if ("withCredentials" in xhr){	// For Chrome/ Firefox
				xhr.open(method, url, true);
			} else if (typeof XDomainRequest != "undefined"){
				try{
					xhr = new XDomainRequest();
					xhr.open(method, url);
				}catch(e){	
					xhr = new XMLHttpRequest();	
					xhr.open(method, url, true);
				}
			} else {
				xhr = new XMLHttpRequest();
			}
			return xhr;
		}
		
		// The funciton to display Alert Message to the Browser
		function generateAlertMessage(alertMessage){
			var keyword= '/cookiepolicy/';
			var dbCookieVersion = alertMessage.substring(0, alertMessage.indexOf('|')); 
			if(dbCookieVersion == '' || dbCookieVersion ==' '){
				dbCookieVersion = '1';
			}
			var alertMessageToDisplay  = alertMessage.substring(alertMessage.indexOf('|')+1, alertMessage.length );

//alert('generateAlertMessage '+ alertMessage);
			if(alertMessage.length && alertMessage.length > 0){
				if(alertMessageToDisplay.indexOf(keyword) != -1){
					var alertMessageToDisplay1= alertMessageToDisplay.substring(0, alertMessageToDisplay.indexOf(keyword));
					var alertMessageToDisplay2= alertMessageToDisplay.substring(alertMessageToDisplay.indexOf(keyword)+keyword.length, alertMessageToDisplay.length);
					alertMessageToDisplay = alertMessageToDisplay1+keyword+"?siteid="+oupcookiepolicy_siteid+alertMessageToDisplay2;
				}
				if(oupcookiepolicy_messagetype == 'implied'){
					alertMessageToDisplay=htmlDecode(alertMessageToDisplay);
					var p = document.createElement("div");
					p.innerHTML = alertMessageToDisplay;
					document.body.insertBefore(p, document.body.firstChild);
					saveCookie(dbCookieVersion);
				}else{
					alertMessageToDisplay = alertMessageToDisplay+"<a id='cookie_accpt_button' href='javascript:saveCookie("+dbCookieVersion+")'>I accept</a>";
					document.getElementById('cookiepolicy_data').innerHTML = alertMessageToDisplay;
					try{
						document.getElementById('cookiepolicy_link').click();							
					}catch(e){
						_cookiepolicy('#cookiepolicy_link').click();
					}
					
					//CASE I - for Fancybox style display 
					//-----------------------------------
				/*	if(oupcookiepolicy_style == 'desktop'){
						document.getElementById('cookiepolicy_data').innerHTML = alertMessageToDisplay;
						try{
							document.getElementById('cookiepolicy_link').click();							
						}catch(e){
							_cookiepolicy('#cookiepolicy_link').click();
						}
					}
					// CASE II - for Generic display - for Mobile
					//-----------------------------------
					if(oupcookiepolicy_style == 'mobile'){
						var p = document.createElement("div");
						p.innerHTML = alertMessageToDisplay;
						document.body.insertBefore(p, document.body.firstChild);
					}
				*/
				}
			}
		}
		
		
		
		function cookiePolicy(){
			var cookieWindow = window.open(cookiePolicyUrl,'_blank');
		}
		
		function saveCookie(version){
			var currentDate = new Date(); 
			var expiryDate = new Date();
			expiryDate.setDate( expiryDate.getDate() +365 );
			var savedDate = currentDate.getDate()+"-"+(currentDate.getMonth()+1)+"-"+currentDate.getFullYear();
			var expiryDateUtc = expiryDate.toGMTString();
			
		//	var cookieToSave = cookieName+","+version+","+savedDate+", expires="+expiryDateUtc;
		//	var cookieToSave = "name="+cookieName+"; value= version:"+version+",date:"+savedDate+"; expires="+expiryDateUtc;
			var cookieToSave = cookieName+"="+version+"_"+savedDate+"; expires="+expiryDateUtc+"; path="+oupcookiepolicy_documentroot ;
			var domainName = document.domain;

			if(oupcookiepolicy_siteid != null && oupcookiepolicy_siteid !='' && oupcookiepolicy_siteid =='journals')
			{
				if(domainName != null  && domainName != 'undefine' && domainName != '')
				{
					var containsDot =".";
					var firstPart='';
					var secondPart='';
					var domainToSetCookie='';
					//alert(domainName);
					if(domainName.indexOf(containsDot) !=  -1)
					{
						var str_array = domainName.split(containsDot);
						if(str_array.length > 2)
						{
							domainToSetCookie = '.'+str_array[str_array.length-2] +'.'+str_array[str_array.length-1]
						}
						//alert('contains dot '+domainToSetCookie);
						cookieToSave = cookieToSave +"; "+"domain="+domainToSetCookie;				
					} else {
						//alert('does not contains.');	
					}				
				}
			}
			document.cookie=cookieToSave;
			//alert(_cookiepolicy.oupcookiepolicy_fancybox);
			if(_cookiepolicy.oupcookiepolicy_fancybox){
				//alert('close it :'+_cookiepolicy.oupcookiepolicy_fancybox);
				_cookiepolicy.oupcookiepolicy_fancybox.close();
			}
			/*
			if(oupcookiepolicy_style == 'desktop'){
				_cookiepolicy.oupcookiepolicy_fancybox.close();
			}
			if(oupcookiepolicy_style == 'mobile'){
				document.location.reload(true);
			}
			*/
		}
		
		function closeImplied(){
			document.location.reload(true);
		}	
		
		_cookiepolicy(document).keydown(function(e) {
			if (e.keyCode == 27) {
			if (e.keyCode == 27 && !e.disableEscape) {
			//alert('inside');
			return false;
				//$(document).unbind("keydown");
		}}});
		
		// Start Decode Functions
		function htmlDecode(s){
			var c,m,d = s;		
			if(this.isEmpty(d)) return "";

			// convert HTML entites back to numerical entites first
			d = this.HTML2Numerical(d);
		
			// look for numerical entities &#34;
			arr=d.match(/&#[0-9]{1,5};/g);			
			// if no matches found in string then skip
			if(arr!=null){
				for(var x=0;x<arr.length;x++){
					m = arr[x];
					c = m.substring(2,m.length-1); //get numeric part which is refernce to unicode character
					// if its a valid number we can decode
					if(c >= -32768 && c <= 65535){
						// decode every single match within string
						d = d.replace(m, String.fromCharCode(c));
					}else{
						d = d.replace(m, ""); //invalid so replace with nada
					}
				}			
			}	
			return d;
		}
		
		function isEmpty  (val){
			if(val){
				return ((val===null) || val.length==0 || /^\s+$/.test(val));
			}else{
				return true;
			}
		}
		
		function HTML2Numerical(s){
			return swapArrayVals(s,this.arr1,this.arr2);
		}
		
		// arrays for conversion from HTML Entities to Numerical values
		var arr1 = ['&nbsp;','&iexcl;','&cent;','&pound;','&curren;','&yen;','&brvbar;','&sect;','&uml;','&copy;','&ordf;','&laquo;','&not;','&shy;','&reg;','&macr;','&deg;','&plusmn;','&sup2;','&sup3;','&acute;','&micro;','&para;','&middot;','&cedil;','&sup1;','&ordm;','&raquo;','&frac14;','&frac12;','&frac34;','&iquest;','&Agrave;','&Aacute;','&Acirc;','&Atilde;','&Auml;','&Aring;','&AElig;','&Ccedil;','&Egrave;','&Eacute;','&Ecirc;','&Euml;','&Igrave;','&Iacute;','&Icirc;','&Iuml;','&ETH;','&Ntilde;','&Ograve;','&Oacute;','&Ocirc;','&Otilde;','&Ouml;','&times;','&Oslash;','&Ugrave;','&Uacute;','&Ucirc;','&Uuml;','&Yacute;','&THORN;','&szlig;','&agrave;','&aacute;','&acirc;','&atilde;','&auml;','&aring;','&aelig;','&ccedil;','&egrave;','&eacute;','&ecirc;','&euml;','&igrave;','&iacute;','&icirc;','&iuml;','&eth;','&ntilde;','&ograve;','&oacute;','&ocirc;','&otilde;','&ouml;','&divide;','&oslash;','&ugrave;','&uacute;','&ucirc;','&uuml;','&yacute;','&thorn;','&yuml;','&quot;','&amp;','&lt;','&gt;','&OElig;','&oelig;','&Scaron;','&scaron;','&Yuml;','&circ;','&tilde;','&ensp;','&emsp;','&thinsp;','&zwnj;','&zwj;','&lrm;','&rlm;','&ndash;','&mdash;','&lsquo;','&rsquo;','&sbquo;','&ldquo;','&rdquo;','&bdquo;','&dagger;','&Dagger;','&permil;','&lsaquo;','&rsaquo;','&euro;','&fnof;','&Alpha;','&Beta;','&Gamma;','&Delta;','&Epsilon;','&Zeta;','&Eta;','&Theta;','&Iota;','&Kappa;','&Lambda;','&Mu;','&Nu;','&Xi;','&Omicron;','&Pi;','&Rho;','&Sigma;','&Tau;','&Upsilon;','&Phi;','&Chi;','&Psi;','&Omega;','&alpha;','&beta;','&gamma;','&delta;','&epsilon;','&zeta;','&eta;','&theta;','&iota;','&kappa;','&lambda;','&mu;','&nu;','&xi;','&omicron;','&pi;','&rho;','&sigmaf;','&sigma;','&tau;','&upsilon;','&phi;','&chi;','&psi;','&omega;','&thetasym;','&upsih;','&piv;','&bull;','&hellip;','&prime;','&Prime;','&oline;','&frasl;','&weierp;','&image;','&real;','&trade;','&alefsym;','&larr;','&uarr;','&rarr;','&darr;','&harr;','&crarr;','&lArr;','&uArr;','&rArr;','&dArr;','&hArr;','&forall;','&part;','&exist;','&empty;','&nabla;','&isin;','&notin;','&ni;','&prod;','&sum;','&minus;','&lowast;','&radic;','&prop;','&infin;','&ang;','&and;','&or;','&cap;','&cup;','&int;','&there4;','&sim;','&cong;','&asymp;','&ne;','&equiv;','&le;','&ge;','&sub;','&sup;','&nsub;','&sube;','&supe;','&oplus;','&otimes;','&perp;','&sdot;','&lceil;','&rceil;','&lfloor;','&rfloor;','&lang;','&rang;','&loz;','&spades;','&clubs;','&hearts;','&diams;'];
		var arr2 = ['&#160;','&#161;','&#162;','&#163;','&#164;','&#165;','&#166;','&#167;','&#168;','&#169;','&#170;','&#171;','&#172;','&#173;','&#174;','&#175;','&#176;','&#177;','&#178;','&#179;','&#180;','&#181;','&#182;','&#183;','&#184;','&#185;','&#186;','&#187;','&#188;','&#189;','&#190;','&#191;','&#192;','&#193;','&#194;','&#195;','&#196;','&#197;','&#198;','&#199;','&#200;','&#201;','&#202;','&#203;','&#204;','&#205;','&#206;','&#207;','&#208;','&#209;','&#210;','&#211;','&#212;','&#213;','&#214;','&#215;','&#216;','&#217;','&#218;','&#219;','&#220;','&#221;','&#222;','&#223;','&#224;','&#225;','&#226;','&#227;','&#228;','&#229;','&#230;','&#231;','&#232;','&#233;','&#234;','&#235;','&#236;','&#237;','&#238;','&#239;','&#240;','&#241;','&#242;','&#243;','&#244;','&#245;','&#246;','&#247;','&#248;','&#249;','&#250;','&#251;','&#252;','&#253;','&#254;','&#255;','&#34;','&#38;','&#60;','&#62;','&#338;','&#339;','&#352;','&#353;','&#376;','&#710;','&#732;','&#8194;','&#8195;','&#8201;','&#8204;','&#8205;','&#8206;','&#8207;','&#8211;','&#8212;','&#8216;','&#8217;','&#8218;','&#8220;','&#8221;','&#8222;','&#8224;','&#8225;','&#8240;','&#8249;','&#8250;','&#8364;','&#402;','&#913;','&#914;','&#915;','&#916;','&#917;','&#918;','&#919;','&#920;','&#921;','&#922;','&#923;','&#924;','&#925;','&#926;','&#927;','&#928;','&#929;','&#931;','&#932;','&#933;','&#934;','&#935;','&#936;','&#937;','&#945;','&#946;','&#947;','&#948;','&#949;','&#950;','&#951;','&#952;','&#953;','&#954;','&#955;','&#956;','&#957;','&#958;','&#959;','&#960;','&#961;','&#962;','&#963;','&#964;','&#965;','&#966;','&#967;','&#968;','&#969;','&#977;','&#978;','&#982;','&#8226;','&#8230;','&#8242;','&#8243;','&#8254;','&#8260;','&#8472;','&#8465;','&#8476;','&#8482;','&#8501;','&#8592;','&#8593;','&#8594;','&#8595;','&#8596;','&#8629;','&#8656;','&#8657;','&#8658;','&#8659;','&#8660;','&#8704;','&#8706;','&#8707;','&#8709;','&#8711;','&#8712;','&#8713;','&#8715;','&#8719;','&#8721;','&#8722;','&#8727;','&#8730;','&#8733;','&#8734;','&#8736;','&#8743;','&#8744;','&#8745;','&#8746;','&#8747;','&#8756;','&#8764;','&#8773;','&#8776;','&#8800;','&#8801;','&#8804;','&#8805;','&#8834;','&#8835;','&#8836;','&#8838;','&#8839;','&#8853;','&#8855;','&#8869;','&#8901;','&#8968;','&#8969;','&#8970;','&#8971;','&#9001;','&#9002;','&#9674;','&#9824;','&#9827;','&#9829;','&#9830;'];

		
		function swapArrayVals (s,arr1,arr2){
		if(this.isEmpty(s)) return "";
		var re;
		if(arr1 && arr2){
				//ShowDebug("in swapArrayVals arr1.length = " + arr1.length + " arr2.length = " + arr2.length)
				// array lengths must match
				if(arr1.length == arr2.length){
					for(var x=0,i=arr1.length;x<i;x++){
						re = new RegExp(arr1[x], 'g');
						s = s.replace(re,arr2[x]); //swap arr1 item with matching item from arr2	
					}
				}
			}
		return s;
		}
		
		// End Decode Functions
