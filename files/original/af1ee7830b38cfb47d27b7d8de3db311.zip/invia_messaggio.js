var messaggioObj = {

//	toUpdate : false,

	openPopup : function(tipoMessaggio, subject) {
		jQuery
				.get(
						'/system/modules/it.banzai.treccani.portale/elements/invia_messaggio.jsp?tipoMessaggio='
								+ tipoMessaggio+((subject != null && subject != '')?'&subject='+encodeURI(subject):''), function(data) {
							var contentDiv = data;
							jQuery.fancybox(contentDiv, {
								'titlePosition' : 'inside',
								'transitionIn' : 'none',
								'transitionOut' : 'none',
								'showCloseButton' : false,
								'scrolling' : 'no'
							});
							jQuery("#fancybox-content").css("background-color",
									"#ffffff").width("750px");
							jQuery(window.top).resize();
							jQuery("#formMessaggio input").keydown(function(e) {
								var ev = e || event;
								if (ev.keyCode == 13) {
									window.top.messaggioObj.doInvia();
									return false;
								}
							});
//							jQuery(contentDiv).append(jQuery('<div class="waitAjax" style="display: none;"><img src="../images/ajax-loader.gif" /></div>'))
						});

	},
	cleanField : function(elem) {
		var el = jQuery(elem);
		if (el.hasClass('campovuoto')) {
			el.val('');
			el.removeClass('campovuoto');
		}
	},
	doInvia : function() {
		messaggioObj.showWait();
		var data = jQuery('#formMessaggio .obbligatorio');
		for ( var i = 0; i < data.length; i++) {
			var el = jQuery(data[i]);
			if (!(el.val()) || el.hasClass('campovuoto')) {
				jQuery('#messaggioMsgIncomp').show();
				messaggioObj.hideWait();
				return;
			}
		}
		if (jQuery('#messaggioMsgIncomp').is(":visible")) {
			jQuery('#messaggioMsgIncomp').hide();
		}
		if (jQuery('#captchaError').is(":visible")) {
			jQuery('#captchaError').hide();
		}

		jQuery.ajax({
			type : "POST",
			url : jQuery('#formMessaggio').attr('action'),
			data : jQuery('#formMessaggio').serialize(),
			dataType : "application/json",
			dataFilter : messaggioObj.parseData,
			success : messaggioObj.proceed
		});
	},

	proceed : function(data, text, jqhxl) {
		messaggioObj.hideWait();
		if (data != null) {
			if (data.error == 'none') {
				jQuery.fancybox.close();
			} else {
				jQuery('#captchaError').html(data.error);
				jQuery('#captchaError').show();
				messaggioObj.updateCaptcha();
			}
		} else {
			jQuery('#captchaError').html('Errore captcha già utilizzato')
					.show();
			messaggioObj.updateCaptcha();
		}
	},

	parseData : function(data, type) {
		return jQuery.parseJSON(data);
	},

	updateCaptcha : function() {
		jQuery('#immagineCaptcha').remove();
		jQuery('#contenitoreCaptcha')
				.append(
						jQuery('<img id="immagineCaptcha" src="/jcaptcha?r='+Math.floor(Math.random()*100000000)+'" class="captcha"/>'));
	},
	
	showWait : function(){
		jQuery('.waitAjax').show();
		var t = ($(window).height()-jQuery(".waitAjax").height())/2+jQuery(window).scrollTop();
		var l = ($(window).width()-jQuery(".waitAjax").width())/2+jQuery(window).scrollLeft();
		jQuery(".waitAjax").offset({top:t,left:l});
	},
	hideWait : function(){
		jQuery('.waitAjax').hide();
	}
};
