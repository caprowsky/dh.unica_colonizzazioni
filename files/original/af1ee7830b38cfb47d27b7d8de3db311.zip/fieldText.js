var fieldText = {
	setText : function(oggetto, testoDefault){
		if (oggetto.value == ''){
			oggetto.value = testoDefault;
		}
	},
	removeText : function(oggetto, testoDefault){
		if (oggetto.value == testoDefault){
			oggetto.value = '';
		}
	}
};